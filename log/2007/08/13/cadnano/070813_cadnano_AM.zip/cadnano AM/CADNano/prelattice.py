"""
The prelattice.py module converts a I{design}_helix_lattice.txt file into
a properly numbered, and appropriately expanded, helix_lattice.txt file,
as explained below.

There are three major classes defined in this module:

        1. C{helix_marker} -- stores attributes of individual
            helices in the (design) helix lattice file
        
        2. C{helix_marker_array} -- stores and transforms 
            multiple representations of the helix lattice file

        3. C{HelixNumberingError(Exception)} -- an exception
            raised if there is a problem numbering a helix
            lattice in any of the slices in the I{design}_helix_lattice.txt
            file

ASCII Representation of Helix Lattices
======================================

Cross-sections of folded monomers are input by the user
in the form of human-readable ASCII representations,
approximating honeycomb lattices. For example::

    ...   ...   ...   ...   ...   
       ...   ...   ...   ...   ...

       ...   AAA   AAA   AA0   ...
    ...   AA1   AAA   AAA   ...   

    ...   AA2   AAA   AAA   ...   
       ...   AAA   AAA   AA3   ...

       ...   ...   ...   ...   ...
    ...   ...   ...   ...   ...   


Each double-helix is represented by a unique 3-digit code.  The first
letter always defines the scaffold identity [A-Z,a-z].  By default,
the second and third positions should also match first letter.  However,
those positions can also be integers used to define ordered waypoints 
through which the scaffold passes as it traverses the structure.

NOTE: If waypoints are specified, they must begin with the AA0 waypoint
and increase in increments of one: AA0, AA1, AA2...

NOTE: The AA0 waypoint will always be taken as the initial (zero) helix
in a given slice, if waypoints are specified. If no waypoints are specified,
an arbitrary helix will be chosen as the initial helix. This may result in
a C{HelixNumberingError} because an inappropriate starting helix was arbitrarily
chosen by the algorithm. To avoid this problem, it is best to include
AT LEAST the AA0 waypoint in any slice.

Note that when describing the nanostructure in three dimensions, the
left-to-right direction in the lattice file is the "x direction",
the top-to-bottom direction is the "y direction", and the view into
the screen is the z direction.

The lattice also has "parity" constraints for where even and odd
helices can be po
sitioned.  The parity of any position is defined as
its row number plus its column number (using zero-based indexing).  
Note that the following is a single row, which takes up 2 separate 
lines in the ASCII file::

    ...   ...   ...   ...   ...   
       ...   ...   ...   ...   ...

The row above has 10 columns. Even-numbered helices must occupy 
even-parity lattice positions, and odd-numbered helices must occupy
odd-parity lattice positions.

NOTE: For the numbering algorithm defined by
C{prelattice.helix_marker_array.assign_numbers()} to run with
reasonable speed, multiple waypoints should be provided in any slice
containing more than ~50 helices. If the algorithm runs too slowly,
try adding additional waypoints, especailly on and around branches, and
near the beginning of the desired path.

File Input
==========
The input to this module, a I{design} helix lattice file, consists of a set of
I{slices} of the form::

    # [integer slice number]
    [ASCII representation of a monomer cross-section]

    or

    # [integer slice number]-[integer slice number]
    [ASCII representation of a monomer cross-section]

The latter form is used to denote groups of repeated (identical) slices.

For example, the following represents a valid I{design}_helix_lattice.txt file::

    # 0-1
    ...   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AA0   
       AA1   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AAA   ...

       AA2   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AAA   ...
    ...   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AAA   AA3

    # 2
    AA0   AAA   ...   ...   AAA   
       AAA   AAA   ...   AAA   ...

       ...   AAA   AAA   AAA   ...
    ...   AAA   ...   AAA   AAA   

    ...   AAA   ...   AAA   AAA   
       AAA   AAA   AAA   AAA   AAA

       AAA   AAA   AAA   AAA   AAA
    ...   ...   AAA   ...   AAA   


Processing Overview
===================
Taking as input a design helix lattice file
(called I{design}_helix_lattice.txt by default),
this module outputs a modified file (helix_lattice.txt), which expands
groups of repeated slices, and numbers the helix lattices in the individual
slices according to contraints of parity, and according to the user-defined
waypoints. For example, the above design helix lattice would be transformed to::

    # 0
    ...   A28   A26   A24   A22   A20   A18   A16   A14   A12   AA0   
       A29   A27   A25   A23   A21   A19   A17   A15   A13   A11   ...   

       A30   A32   A34   A36   A38   A40   A42   A44   A46   A48   ...   
    ...   A31   A33   A35   A37   A39   A41   A43   A45   A47   A59

    # 1
    ...   A28   A26   A24   A22   A20   A18   A16   A14   A12   AA0   
       A29   A27   A25   A23   A21   A19   A17   A15   A13   A11   ...   

       A30   A32   A34   A36   A38   A40   A42   A44   A46   A48   ...   
    ...   A31   A33   A35   A37   A39   A41   A43   A45   A47   A59

    # 2
    AA0   AA2   ...   ...   A24   
       AA1   AA3   ...   A23   ...   

       ...   AA4   A26   A22   ...   
    ...   AA5   ...   A25   A21   

    ...   AA6   ...   A14   A20   
       AA7   AA9   A13   A15   A19   

       AA8   A10   A12   A16   A18   
    ...   ...   A11   ...   A17

Error Reporting
===============
The module outputs a warning to the standard output if any slices have
branches containing an odd-number of helices. It also raises 
exceptions of type C{HelixNumberingError} if it encounters a problem
numbering a helix lattice in one of the individual slices.

Debugging
=========
The flag C{prelattice.print_debug} can be set to True to show the
progress of the helix numbering algorithm, so as to diagnose any
unexpected failures. The various classes defined
herein also contain printing functions that write convenient depictions of
their internal data structures to the standard output.

@todo: speed up the numbering algorithm for large inputs
"""

#!/usr/bin/python

import os
import re
import sys
import copy
import exceptions

from CADNano.exceptions import ParityError, LengthError

print_debug = False

def _parse_unnumbered_slice(lines):
    """
    Reads the I{design}_helix_lattice.txt file, and outputs an array
    representation of the design helix lattice suitable, which can be used to
    instantiate a C{helix_marker_array} object to represent the helix lattice.
    """
    
    row_ra = lines
    
    # Check to make sure each line is the same length
    length_violations = []
    length = len(row_ra[0])
    for row in row_ra:
        if len(row) != length and len(row) != 0:
            length_violations.append(row_ra.index(row))
    
    # Parse into pre helix array
    pre_helix_lattice_ra = []
    for row in row_ra:
        num_helices = len(row) / 3
        sub_pre_helix_lattice_ra = []
        for row_helix_num in range(num_helices):
            sub_pre_helix_lattice_ra.append(\
                row[row_helix_num * 3: \
                    row_helix_num * 3 + 3])
        if sub_pre_helix_lattice_ra != []:
            pre_helix_lattice_ra.append(\
                sub_pre_helix_lattice_ra)
    
    # Parse pre helix array into helix array
    num_rows = len(pre_helix_lattice_ra)/2
    num_helices = len(pre_helix_lattice_ra[0])
    helix_lattice_ra = [\
        ['.' for row_helix_num in range(\
            num_helices + num_helices % 2 + 2)]]
    for row_num in range(num_rows):
        sub_helix_lattice_ra = ['.']
        for row_helix_num in range(num_helices):
            pre_helix_string = pre_helix_lattice_ra[\
                row_num*2 + (row_helix_num + row_num) % 2][\
                    row_helix_num]
            if pre_helix_string == '...':
                helix = '.'
            else:
                helix=get_waypoint_number(pre_helix_string)
            sub_helix_lattice_ra.append(helix)
        sub_helix_lattice_ra.append('.')
        if num_helices % 2 == 1:
            sub_helix_lattice_ra.append('.')
        helix_lattice_ra.append(sub_helix_lattice_ra)
    
    helix_lattice_ra.append(['.' for row_helix_num in \
        range(num_helices + num_helices % 2 + 2)])

    return helix_lattice_ra
        
class HelixNumberingError(Exception):
    """
    Raised when C{Number Lattice} is unable to number the lattice.
    """
    pass

def get_waypoint_number(marker_string):
    """
    Returns an integer representing a strand
    marker's waypoint number in a lattice text
    file. Examples: AAA -> -1, AA1->1, A13->13
    """
    waypoint_exp = re.compile(r"(\D+)(\d+)")
    match = waypoint_exp.match(marker_string)
    if match == None:
        return (-1, marker_string[0])
    else:
        return (int(match.group(2)), marker_string[0])

class helix_marker():
    """
    Represents an individual helix in a helix lattice or design helix lattice.
    
    Attributes:
    
        1. is_blank -- a boolean indicating whether this helix marker 
        represents a placeholder helix as represented by a ... in the helix 
        lattice file, which is not part of the scaffold
        
        2. waypoint_number -- the waypoint value for this helix marker, as
        specified by the input design_helix_lattice.txt file
        
        3. number -- the strand number, as computed by the program
        
        4. array_coords -- a 2-tuple giving the coordinates of this helix 
        marker in the helix_marker_array

        5. neighbor_list -- a list of helix_marker objects representing this 
        marker's neighboring strands.  This neighbor list is constructed by 
        C{helix_marker_array}. note that blank neighbors are not included in
        the neighbor list, as generated by C{helix_marker_array}.
    """
    
    def __init__(self, array_coords, is_blank):
        self.is_blank = is_blank
        self.waypoint_number = -1
        self.number = -1
        self.array_coords = array_coords
        self.status = "NO_STATUS"
        self.symbol = "LLL"
        self.color = "White" #for checking branch lengths
    def set_waypoint_number(self, waypoint_number):
        self.waypoint_number = waypoint_number
    def get_waypoint_number(self):
        return self.waypoint_number;
    def set_neighbor_list(self, neighbor_list):
        self.neighbor_list = neighbor_list
    def set_number(self, number):
        self.number = number
    def get_number(self):
        return self.number
    def parity(self):
        return self.number % 2
    def parity_check(self):
        if self.number == -1:
            return True
        else:
            if self.number % 2 == (self.array_coords[0]\
                    +self.array_coords[1]) % 2:
                return True
            else:
                return False
    def set_symbol(self, s):
        self.symbol = str(s)

    def get_symbol(self):
        return self.symbol


class helix_marker_array():
    """
    C{helix_marker_array} provides a representation of a design helix lattice
    and transforms this representation into a representation of the
    corresponding, properly numbered, helix lattice. In general, a distinct
    helix_marker_array will be used to represent each lattice slice
    in a design_helix_lattice.txt or helix_lattice.txt file. This class uses
    C{helix_marker} objects to refer to the individual helices, and generates
    their C{helix_marker.neigbor_list} attributes to reflect the
    neighbor-relationships of the helices in the lattice. The input to
    this class is a I{helix_lattice_ra} as produced by
    C{prelattice._parse_unnumbered_slice()}. 
    
    Attributes:
        
        1. path -- an internal list used for generating the ordering of the
        helices. Once the correct ordering has been found using 
        C{prelattice.helix_marker_array.assign_numbers()}, the path gives a 
        properly ordered list of the helix marker objects corresponding to 
        the helices in the helix lattice
        
        2. number_helices -- the number of non-blank helices in the array
        
        3. helix_marker_ra -- the array of helix_marker objects representing
        the helix lattice
        
        4. start_helix -- a pointer to one of the helix_marker objects in the
        helix_marker_ra, which is used the the process of finding the correct
        ordering of helix lattice. this is NOT generally the initial (AA0)
        helix.
    """
    
    def __init__(self, helix_lattice_ra):
        """
        The input is a I{helix_lattice_ra} as produced by
        C{prelattice._parse_unnumbered_slice()}.
        """
        self.path = []
        self.number_helices = 0
        num_rows = len(helix_lattice_ra)
        row_len = len(helix_lattice_ra[0])
        self.helix_marker_ra = []
        self.wrong_paths = []
        self.back_through_zero = False
        #initialize the marker objects
        for row_num in range(num_rows):
            sub_helix_marker_ra = []
            for column_num in range(row_len):
                if helix_lattice_ra[row_num][column_num] == '.':
                    #Append a BLANK helix marker
                    marker = helix_marker(\
                        (row_num, column_num), True)
                else:
                    marker = helix_marker(\
                        (row_num, column_num), False)
                    info = helix_lattice_ra[row_num][column_num]
                    marker.set_waypoint_number(info[0])
                    marker.set_symbol(str(info[1]))
                sub_helix_marker_ra.append(marker)
            self.helix_marker_ra.append(sub_helix_marker_ra);

        #set the neighbor relationships
        for y in range(len(self.helix_marker_ra)):
            for x in range(len(self.helix_marker_ra[0])):
                if not self.helix_marker_ra[y][x].is_blank:

                    self.number_helices += 1
                                
                    neighbor_list = []
                    
                    even_offset_ra = [[ 0,  1], [ 0, -1], [-1, 0]]
                    odd_offset_ra  = [[ 0, -1], [ 0,  1], [ 1, 0]]
                    offset_ra = [even_offset_ra, odd_offset_ra]
                    for offset_coords in offset_ra[(x+y) % 2]:
                        if not self.helix_marker_ra[y+offset_coords[0]]\
                            [x+offset_coords[1]].is_blank:
                            neighbor_list.append(self.helix_marker_ra[\
                                y+offset_coords[0]][x+offset_coords[1]])
                    self.helix_marker_ra[y][x].set_neighbor_list(\
                        neighbor_list)


    def print_helix_marker_array(self):
        """
        Used for debugging the C{helix_marker_array} class.
        """
        sys.stdout.write('\nHELIX MARKER ARRAY\n')
        sys.stdout.write('\nNUMBER OF NONBLANK HELICES:'\
             +str(self.number_helices)+'\n')
       
        for y in range(len(self.helix_marker_ra)):
            even_row_string = ''
            odd_row_string = '   '
            for x in range(len(self.helix_marker_ra[0])):
                triple = self.helix_marker_ra[y][x].get_symbol()
                triple *= 3
                if self.helix_marker_ra[y][x].is_blank:
                    string_element = '.'
                else:
                    string_element = str(self.helix_marker_ra[y][\
                        x].get_number())
                if string_element == '.':
                    string_element += '..'
                if string_element == "-1":
                    string_element = triple
                else:
                    string_element = triple[:3 - len(string_element)] \
                        + string_element
                if x % 2 == 0:
                    even_row_string += string_element + '   '
                else:
                    odd_row_string += string_element + '   '
            if y % 2 == 0:
                sys.stdout.write(even_row_string + '\n')
                sys.stdout.write(odd_row_string + '\n')
            else:
                sys.stdout.write(odd_row_string + '\n')
                sys.stdout.write(even_row_string + '\n')
            sys.stdout.write('\n')
        sys.stdout.write('\n\n')

    def write_helix_marker_array_without_border(self, out_file):
        """
        Write the ASCII representation of the helix lattice
        corresponding to an individual lattice slice. Used for writing the
        helix_lattice.txt file.
        """
        y = 1
        x = 1
        while y < (len(self.helix_marker_ra)-1):
            x = 1
            even_row_string = ''
            odd_row_string = '   '
            while x< (len(self.helix_marker_ra[0])-1):
                triple = self.helix_marker_ra[y][x].get_symbol()
                triple *= 3
                if self.helix_marker_ra[y][x].is_blank:
                    string_element = '.'
                else:
                    string_element = str(self.helix_marker_ra[y][\
                        x].get_number())
                if string_element == '.':
                    string_element += '..'
                if string_element == "-1":
                    string_element = triple
                else:
                    string_element = triple[:3 - len(string_element)] \
                        + string_element
                if x % 2 == 1:
                    even_row_string += string_element + '   '
                else:
                    odd_row_string += string_element + '   '
                x += 1
                if x == (len(self.helix_marker_ra[0])-1) and x % 2 == 1:
                    odd_row_string = odd_row_string[:-3]
                
            if y % 2 == 1:
                out_file.write(even_row_string + '\n')
                out_file.write(odd_row_string + '\n')
            else:
                out_file.write(odd_row_string + '\n')
                out_file.write(even_row_string + '\n')
            y += 1
            if y != (len(self.helix_marker_ra)-1):
                out_file.write('\n')

    def assign_numbers(self):
        """
        Perform a depth-first search of possible ordered paths
        through the design helix lattice, for a path satisfying the parity and
        waypoint constraints. The recursive function used in performing the
        search is C{prelattice.run_numbering_loop()}. If a valid path is
        found, the C{helix_marker} objects in
        C{helix_marker_array.helix_marker_ra} will be numbered accordingly 
        and the path will be stored in C{helix_marker_array.path}. 
        """
        #choose a starting point
        found_a_starter = False
        for y in range(len(self.helix_marker_ra)):
            for x in range(len(self.helix_marker_ra[0])):
                if not self.helix_marker_ra[y][x].is_blank:
                    if not found_a_starter:
                        if self.helix_marker_ra[y][\
                            x].get_waypoint_number() == 0:
                            start_helix = self.helix_marker_ra[y][x]
                            #pick the AA0 waypoint as a starting place
                            found_a_starter = True
                        else:
                            #or if no AA0 is present, pick any non-blank helix
                            start_helix = self.helix_marker_ra[y][x]
                        self.start_helix = start_helix

        if not found_a_starter:
            print "WARNING: No zero waypoint specified. This may lead to a HelixNumberingError."
        self.path.append(self.start_helix)
        self.current_num = -1
        self.current_waypoint = -1
        self.start_helix.set_number(-1)

        result = self.run_numbering_loop()
        if result == "False":
            print "ERROR: CAN'T NUMBER THE HELICES GIVEN THE WAYPOINTS SPECIFIED"
            raise HelixNumberingError
            #clean up any damage in the event of an error
            for y in range(len(self.helix_marker_ra)):
                for x in range(len(self.helix_marker_ra[0])):
                    if self.helix_marker_ra[y][x].is_blank==False:
                        self.helix_marker_ra[y][x].set_number(-1)
            self.path=[]

    def run_numbering_loop(self):
        """
        The recursive procedure that forms the core of the number-assignment
        algorithm in C{prelattice.assign_numbers()}. 
        """
        #print "Numbering helices....."
        self.current_num += 1
        self.start_helix.set_number(self.current_num)
        if(print_debug):
            self.print_helix_marker_array()
        
        #BASE CASES
        
        #check parity
        if not self.start_helix.parity_check():
            self.wrong_paths.append(copy.copy(self.path))
            self.start_helix.set_number(-1)
            self.current_num -= 1
            self.path.pop()
            if self.path == []:#if the AA0 waypoint is on an odd-parity helix
                return "False"
            else:
                self.start_helix=self.path[-1]
            self.start_helix.status="NO STATUS"
            return "False"
        
        #check waypoints
        wp = self.start_helix.get_waypoint_number()
        if wp == self.current_waypoint + 1:
            self.current_waypoint += 1
        elif wp == -1:
            pass
        else:   #if the path has crossed an inappropriate waypoint
            self.wrong_paths.append(copy.copy(self.path))
            self.start_helix.set_number(-1)
            self.current_num -= 1
            self.path.pop()
            self.start_helix = self.path[-1]
            self.start_helix.status = "NO STATUS"
            return "False"
        
        if self.current_num + 1 == self.number_helices:
            return "True"
        
        free_neighbors=self.get_blank_neighbors()
        
        #check collisions
        if len(free_neighbors) == 0:
            if len(self.start_helix.neighbor_list) == 1:
                self.start_helix = self.path[self.path.index(\
                    self.start_helix)-1]
                self.start_helix.status = "Unknown"
            elif self.current_num + 1 != self.number_helices:
                self.wrong_paths.append(copy.copy(self.path))
                self.un_mark_backwards_along_path()
                self.start_helix.status = "NO STATUS"
                return "False"
            else:
                self.start_helix = self.path[self.path.index(\
                    self.start_helix)-1]
                self.start_helix.status = "Unknown"
        
        #NON-BASE CASES
        while True:
            if self.current_num + 1 == self.number_helices:
                return "True"
            
            free_neighbors = self.get_blank_neighbors()
            
            if len(free_neighbors) == 0 and \
                self.start_helix.status == "Unknown":
                
                if len(self.start_helix.neighbor_list) == 3:
                     self.start_helix = self.path[-1]
                     self.wrong_paths.append(copy.copy(self.path))
                     self.un_mark_backwards_along_path()
                     self.start_helix.status = "NO STATUS"
                     return "False"
                    
                self.start_helix = self.path[self.path.index(\
                    self.start_helix)-1]
                if self.start_helix.get_number() == 0:
                    self.start_helix.status = "NO STATUS"
                else:
                    self.start_helix.status = "Unknown"
            else:
                self.start_helix.status = "NO STATUS"
                next_paths = self.get_possible_next_paths()
                
                #Go one level down in the recursion
                if len(next_paths) == 0 and\
                   self.start_helix.get_number() == 0:
                    return "False"
                
                next_helix = next_paths[0][-1]
                self.path.append(next_helix)
                self.start_helix = next_helix
                result = self.run_numbering_loop()
                
                if result == "True":
                    return "True"
                if self.start_helix.status == "Unknown":
                    f_n = self.get_blank_neighbors()
                    if len(f_n) == 0:
                        #Move backwards along the path without un-marking 
                        self.start_helix = self.path[\
                            self.path.index(self.start_helix)-1]
                        self.start_helix.status = "Unknown"
                if result == "False":
                    next_paths = self.get_possible_next_paths()
                    remaining_steps_from_zero = \
                        self.get_remaining_steps_from_zero()
                    if len(next_paths) == 0:
                        if len(self.path) != 1:
                            if self.check_for_direct_path_to_zero():
                                if len(remaining_steps_from_zero)>0 \
                                   and len(self.path[0].neighbor_list) == 3:
                                    if len(self.path) == 2:
                                        self.wrong_paths.append(\
                                            copy.copy(self.path))
                                    self.un_mark_backwards_along_path()
                                    self.start_helix.status = "NO STATUS"
                                    return "Deleting"
                                if len(remaining_steps_from_zero) == 0\
                                 and self.back_through_zero == False:
                                    self.backed_through_zero = True
                                    f_n = [i for i in self.start_helix\
                                         .neighbor_list if\
                                             i.get_number() == -1]
                                    if len(f_n) == 0:
                                        self.start_helix = self.path[\
                                            self.path.index(\
                                                self.start_helix)-1]
                                        if self.start_helix\
                                           .get_number() == 0:
                                            self.start_helix\
                                                .status = "NO STATUS"
                                        else:
                                            self.start_helix\
                                                .status = "Unknown"
                                    else:
                                        return "False"
                                elif len(\
                                    remaining_steps_from_zero) == 0\
                                        and self.back_through_zero:
                                    return "False"
                                else:
                                    self.wrong_paths.append(\
                                        copy.copy(self.path))
                                    self.un_mark_backwards_along_path()
                                    self.start_helix.status = "NO STATUS"
                                    return "False"
                            else:
                                self.wrong_paths.append(\
                                    copy.copy(self.path))
                                self.un_mark_backwards_along_path()
                                self.start_helix.status = "NO STATUS"
                                return "False"
                if result == "Deleting":
                    next_paths = self.get_possible_next_paths()
                    if self.start_helix.get_number() == 0:
                        pass
                    elif len(next_paths) == 1 and not len(\
                        self.path) == 2:
                        self.un_mark_backwards_along_path()
                        self.start_helix.status="NO STATUS"
                        return "Deleting"
                    elif len(self.path) == 2:
                        self.wrong_paths.append(\
                            copy.copy(self.path))
                        self.un_mark_backwards_along_path()
                        self.start_helix.status="NO STATUS"
                        return "False"
    def check_for_direct_path_to_zero(self):
        """
        Determines whether the path, not including its last helix,
        is on a direct line to the intial helix (AA0 if waypoints are
        specified), i.e., whether there are no helices with three neighbors
        I{between} the current start_helix and the initial helix.
        """
        for i in self.path[:-1]:
            if len(i.neighbor_list) == 1:
                return False
            if len(i.neighbor_list) == 3 and i.get_number() != 0:
                return False
        return True

    def un_mark_backwards_along_path(self):
        """
        Moves the start_helix backwards along the path by one step,
        after deleting any number previously assigned to the start_helix.
        """
        self.start_helix.set_number(-1)
        self.current_num -= 1
        self.path.pop()
        wp = self.start_helix.get_waypoint_number()
        if wp != -1:
            self.current_waypoint -= 1
        self.start_helix = self.path[-1]

    def get_possible_next_paths(self):
        """
        Returns a list of the neigbors of the current start_helix
        which are I{not known} not to lead to the correct path through the
        helix lattice.
        """
        possible_next_paths = []
        for i in self.start_helix.neighbor_list:
            if i.get_number() == -1:
                possible_next_paths.append((self.path+[i]))
        return [i for i in possible_next_paths\
                if not i in self.wrong_paths]
    
    def get_remaining_steps_from_zero(self):
        """
        Returns a list of the neigbors of the initial helix
        (AA0 if waypoints are specified) which, at the current point in the
        search, are I{not known} not to lead to the correct path through the
        helix lattice.
        """
        return [[self.path[0], i] for i \
                in self.path[0].neighbor_list\
            if i.get_number() == -1 and\
                not [self.path[0], i] in self.wrong_paths]

    def get_blank_neighbors(self):
        """
        Returns the number of blank neighbors of the current start_helix.
        (Here "blank" means "un-numbered", not "non-existent"...)
        """
        return [i for \
                i in self.start_helix.neighbor_list if \
                   i.get_number() == -1]

    def check_branch_lengths_DFS(self, start_helix):
        """
        The recursive function utilized by C{check_branch_lengths()}.
        """
        
        self.searching_for_a_junction=False
        start_helix.color="Grey"
        
        for i in start_helix.neighbor_list:
            if i.color=="White":
                if self.searching_for_a_junction and\
                    len(start_helix.neighbor_list) == 3:
                    if self.branch_len % 2 != 0:
                        self.num_odd_branches += 1
                    self.searching_for_a_junction = False
                    self.branch_len = 0
                result= self.check_branch_lengths_DFS(i)
        
        if len(start_helix.neighbor_list) == 1 and\
            not self.searching_for_a_junction:
            self.searching_for_a_junction = True
        
        if self.searching_for_a_junction and\
           len(start_helix.neighbor_list) != 3:
            self.branch_len += 1
        
        if self.searching_for_a_junction and\
                    len(start_helix.neighbor_list) == 3:
                    if self.branch_len % 2 != 0:
                        self.num_odd_branches += 1
                    self.searching_for_a_junction = False
                    self.branch_len = 0
        start_helix.color = "Black"

    def check_branch_lengths(self):
        """
        Returns False if there is an odd-length branch in the helix lattice 
        and returns True if there are no odd-length branches in the helix 
        lattice. This function uses C{prelattice.check_branch_lengths_DFS()} 
        to perform a depth-first search of the helix lattice while noting if 
        any odd-length branches are encountered in the process.
        """
        self.num_odd_branches = 0
        self.branch_len = 0
        
        #check for a node with three non-blank neighbors
        found_a_starter = False
        three_way_junction_present = False
        for y in range(len(self.helix_marker_ra)):
            for x in range(len(self.helix_marker_ra[0])):
                if not self.helix_marker_ra[y][x].is_blank and\
                   len(self.helix_marker_ra[y][x].neighbor_list) == 3:
                     three_way_junction_present = True
        
        #choose a starting helix for the depth-first search
        for y in range(len(self.helix_marker_ra)):
            for x in range(len(self.helix_marker_ra[0])):
                if not self.helix_marker_ra[y][x].is_blank and\
                   len(self.helix_marker_ra[y][x].neighbor_list) != 1 and\
                     not (three_way_junction_present and\
                         not len(self.helix_marker_ra[y][x]\
                                 .neighbor_list) == 3):
                    if not found_a_starter:
                        start_helix = self.helix_marker_ra[y][x]
                        found_a_starter = True
        
        self.searching_for_a_junction = False
        self.check_branch_lengths_DFS(start_helix)
        if self.num_odd_branches > 0:
            return False
        else:
            return True
        
    def print_helix_marker_colors(self):
        """
        Used for debugging the code to check for odd-length branches.
        """
        sys.stdout.write('\nHELIX MARKER COLORS\n')
        sys.stdout.write('\nNUMBER OF NONBLANK HELICES:'\
             + str(self.number_helices) + '\n')
        
        for y in range(len(self.helix_marker_ra)):
            even_row_string = ''
            odd_row_string = '   '
            for x in range(len(self.helix_marker_ra[0])):
                triple = self.helix_marker_ra[y][x].get_symbol()
                triple *= 3
                if self.helix_marker_ra[y][x].is_blank:
                    string_element='...'
                else:
                    string_element = self.helix_marker_ra[y][x].color[:3]
                if x % 2 == 0:
                    even_row_string += string_element + '   '
                else:
                    odd_row_string += string_element + '   '
            if y % 2 == 0:
                sys.stdout.write(even_row_string + '\n')
                sys.stdout.write(odd_row_string + '\n')
            else:
                sys.stdout.write(odd_row_string + '\n')
                sys.stdout.write(even_row_string + '\n')
            sys.stdout.write('\n')
        sys.stdout.write('\n\n')

def read_helix_marker_array(filename):
    """
    Used for debugging the function C{helix_marker_array.__init__}.
    """
    # Read in file
    input_file = file(filename, 'r')
    lines = input_file.readlines()
    input_file.close()
    row_string_ra = [line[:-1] for line in lines]
    helix_marker_array(_parse_unnumbered_slice(\
        row_string_ra)).print_helix_marker_array()

def do_number_assignment(filename):
    """
    Used for debugging the function C{helix_marker_array.assign_numbers()}.
    """
    # Read in file
    input_file = file(filename, 'r')
    lines = input_file.readlines()
    input_file.close()
    row_string_ra = [line[:-1] for line in lines]
    array = helix_marker_array(_parse_unnumbered_slice(row_string_ra))
    branches_correct = str(array.check_branch_lengths())
    if(branches_correct=="False"):
        print "\nNOTE: A BRANCH IN THIS STRUCTURE CONTAINS AN ODD NUMBER OF HELICES"
    array.assign_numbers()
    array.print_helix_marker_array()

def write_helix_lattice_file(config):
    """
    The central function of the C{number_lattice} module:
    convert a I{design}_helix_lattice.txt file into a helix_lattice.txt file.
    """
    # get slices
    file_dict = config['file']
    phlfile = file_dict['pre_helix_lattice_file']
    input_file = file(phlfile, 'r')
    hlfile = file_dict['helix_lattice_file']
    
    # generate default lattice file only if necessary
    if  os.path.isfile(hlfile):
        return
    
    out_file = file(hlfile,'w')
    lines = input_file.readlines()
    line_group = []
    slices = []
    for line in lines:
        if line == '':
            pass
        elif line[0] == '#':
            if line_group:
                slices.append(line_group)
                line_group = [line[:-1]]
            else:
                line_group.append(line[:-1])
        else:
            line_group.append(line[:-1])
    slices.append(line_group)
    
    #process slices
    for i in slices:
        exp = re.compile(r"(#) (\d+)(-)(\d+)")
        match = exp.match(i[0])
        if match:
            lower_index = int(match.group(2))
            upper_index = int(match.group(4))
            index = lower_index
            while index <= upper_index:
                pre_ra = _parse_unnumbered_slice(i[1:])
                marker_ra = helix_marker_array(pre_ra)
                branches_correct = marker_ra.check_branch_lengths()
                if print_debug:
                    if not branches_correct:
                        print "FOUND ODD-LENGTH BRANCH IN #" + str(index)
                marker_ra.assign_numbers()
                out_file.write( "# " + str(index)+"\n")
                marker_ra.write_helix_marker_array_without_border(out_file)
                index += 1
        else:
            pre_ra = _parse_unnumbered_slice(i[1:])
            marker_ra = helix_marker_array(pre_ra)
            branches_correct = marker_ra.check_branch_lengths()
            if print_debug:
                if not branches_correct:
                    print "FOUND ODD-LENGTH BRANCH IN #" + str(i[0][2])
            marker_ra.assign_numbers()
            out_file.write(i[0] + "\n")
            marker_ra.write_helix_marker_array_without_border(out_file)

    #write back file
    input_file.close()
    out_file.close()

