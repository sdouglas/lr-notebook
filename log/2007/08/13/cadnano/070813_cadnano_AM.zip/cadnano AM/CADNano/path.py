"""Parses the scaffold path file to determine appropriate crossover locations.

File Input
==========

Processing Overview
===================

Output & Debugging
==================

@todo: write documentation
@todo: fix def _parse_path() so it raises exceptions upon input error.
@todo: automatically determine upper-left-most path token that gets visited.
"""
import os
import re
import sys
from file import get_lines, write_lines

class PathToken():
    """A C{PathToken} is used to store information about each scaffold
    segment.  The C{Path} class is used to store many C{PathToken}s 
    that comprise a complete scaffold path.
    """
    def __init__(self, helix, segment):
        self.helix = helix
        """@ivar: Helix number of the C{PathToken}.
           @type: C{int}
        """
        self.segment = segment
        """@ivar: Segment number of the C{PathToken}.
           @type: C{int}
        """
        self.length = 1
        """@ivar: Length, in bases, of the C{PathToken}.
           @type: C{int}
        """
        self.base = ' '
        """@ivar: DNA sequence of the C{PathToken}.
           @type: C{string}
        """
        self.next_token = None
        """@ivar: 5' pointer to next C{PathToken} in the scaffold path.
           @type: C{PathToken}
        """
        self.prev_token = None
        """@ivar: 3' pointer to previous C{PathToken} in the scaffold path.
           @type: C{PathToken}
        """
        self.rank = 0
        """@ivar: Stores the order in which a C{PathToken} was visited or
           generated; used for debugging purposes.
           @type: C{int}
        """
        self.visited = False
        """@ivar: Records whether or not a C{PathToken} has been visited when
           populating the tokens with scaffold sequence.
           @type: C{boolean}
        """
        
        self.assigned_scaffold_path = False
        """
        """
        self.assigned_debug_scaffold_path = False
        
        self.hairpin = False
        """@ivar: Records whether or not a C{PathToken} is part of a scaffold
           hairpin stretch.
           @type: C{boolean}
        """

class Path():
    """The C{Path} class is used to build a data structure containing
     C{PathToken} objects that are interconnected via pointers to each other.
     The arrangement of pointers defines the path of the scaffold through
     the DNA nanostructure monomer.
    """
    def __init__(self, config, lattice, domain):
        self.scaffold_path_file = config['file']['scaffold_path_file']
        """@ivar: Location of the path input file.
           @type: C{string}
        """
        self.lattice = lattice
        """@ivar: Link to the lattice object, used for extracting metadata
           such as C{slice_count} and C{all_helices}.
           @type: C{Lattice}
        """
        self.domain = domain
        """@ivar: Link to the domain object.
           @type: C{Domain}
        """
        self.path_array = []
        """@ivar: Stores the scaffold path in an array format, where each
           element is a list of C{PathTokens} corresponding to a helix.
           @type: C{List}
        """
        num_helices = len(lattice.all_helices)
        num_segments = lattice.slice_count
        
        self.scaffold_path_list = [] 
        """@ivar: Although a C{path} object by definition represents
            the path of a single scaffold, during early design stages it may be
            necessary for a single scaffold path file to define multiple, 
            diconnected paths that will be sewn together by the user into a 
            single path in the final design. C{scaffold_path_list} represents
            these paths as a list of lists of path tokens.
           @type: C{List}
        """
        
        # populate path_array with default tokens
        for helix in range(num_helices):
            path_segment = []
            for segment in range(num_segments+1):
                for i in range(21):
                    path_segment.extend([PathToken(helix,segment)])
            self.path_array.append(path_segment)
        
        # assign next and prev token pointers for even and odd helices
        for i in range(len(self.path_array)):
            row = self.path_array[i]
            if i % 2 == 0: # even tokens point upstream
                for j in range(len(row)-1):
                    row[j].next_token = row[j+1]
                for j in range(1,len(row)):
                    row[j].prev_token = row[j-1]
            else: # odd
                for j in range(1,len(row)):
                    row[j].next_token = row[j-1]
                for j in range(len(row)-1):
                    row[j].prev_token = row[j+1]
        
        # generate default path file if necessary
        if not os.path.isfile(self.scaffold_path_file):
             self._generate_path()
        # parse path file input
        self._parse_path()

    def choose_start_pos(self):
         """ Picks the position in the path array where the 
            scaffold base sequence begins.
         """    
         # choose the initial scaffold base pos: we need to automate this
         # for now setting specify_initial_position
         # to False will cause automation: start at upper-left-corner...
         # NOTE: we are no longer using the path.first_token variable !
         initial_path_position = [22, 119]
         specify_initial_position = False
         if specify_initial_position:
             # and if there is a single scaffold path (otherwise automate)
             if len(self.scaffold_path_list) == 1:
                 p = self.scaffold_path_list[0]
                 # find the desired starting point
                 index = 0
                 for token in p:
                     helix = initial_path_position[0]
                     pos = initial_path_position[1]
                     if token == self.path_array[helix][pos]:
                         index = p.index(token)
                 self.scaffold_path_list[0] = p[index:] + p[:index]
    
    def print_visited_tokens(self):
        """Debugging method to see C{PathToken}s that get visited."""
        for i in range(len(self.path_array)):
            line = []
            row = self.path_array[i]
            print "%02d" % i,
            for j in range(len(row)):
                if row[j].visited:
                    line.append("%04d" % row[j].rank)
                else:
                    line.append("____")
            for k in range(len(line)):
                if k % 7 == 0:
                    print "",
                print line[k],
            print "\n",
    
    def print_tokens(self):
        """Debugging method to print C{PathToken} contents."""
        for i in range(len(self.path_array)):
            row = self.path_array[i]
            print "%02d |" % i,
            if i % 2 == 0:
                for j in range(len(row)):
                    print "%02d" % row[j].helix,
                print "\n%02d |" % i,
                for j in range(len(row)):
                    if row[j].next_token != None:
                        print "%02d" % row[j].next_token.helix,
            else:
                for j in range(len(row)):
                    print "%02d" % row[j].helix,
                print "  ",
                print "\n%02d |" % i,
                for j in range(1, len(row)):
                    if row[j].next_token != None:
                        print "%02d" % row[j].next_token.helix,
            print "\n",
    
    def _parse_path(self):
        """Extracts path information from scaffold path file input and returns
           it in a nested C{dictionary} object.
        """
        path_array = self.path_array
        slices = self.lattice.LatticeSliceList
        filename = self.scaffold_path_file
        lines = get_lines(filename)
        scaf_xover_ptrs = []
        
        xover_offset = {'L':{2: 1, 0: 4, 1: 8}, 'R': {2: 11, 0: 15, 1: 18}}
        """@ivar: Provides the base position of left (L) and right (R)
           scaffold crossovers at each of the possible positions (P0, P1, P2).
           @type: C{dictionary}
        """
        
        for i in range(len(lines)):
            if lines[i].startswith('   '):  
                # skip x-boundaries for now
                continue
            else:
                # parse line using multiple splits
                s1 = lines[i].split('|')
                helix = int(s1[0])
                s2 = s1[1].split(':')[1:-1]
                for i in range(len(s2)):
                    
                    slice_indices = []
                    left_slice_index = i - 1
                    right_slice_index = i
                    
                    # edges only have one slice
                    if left_slice_index >= 0:
                        slice_indices.append(left_slice_index)
                    if right_slice_index < len(slices):
                        slice_indices.append(right_slice_index)
                    for slice in slice_indices:    
                        if slices[slice].helix_set.count(helix):
                    
                            seg = s2[i]
                            if len(seg) != 8:
                                print "problem at %d, %d" % (helix, i)
                                sys.exit(1)
                            if seg[0:4] != '    ':
                                lr = seg[0]
                                target = int(seg[1:4])
                                if slices[slice].helix_set.count(target):
                                    # xover_type can be P0, P1, or P2
                                    if slices[slice].neighbor_to_xover[helix]\
                                        .keys().count(target):
                                        xover_type = \
                                            slices[slice]\
                                            .neighbor_to_xover[helix][target]
                                        offset = (21 * i)\
                                         + xover_offset[lr][xover_type]
                                        if helix % 2 == 1: 
                                            # correct for odd strands
                                            offset = offset + 1
                                        if not scaf_xover_ptrs.count(\
                                            [[helix, offset],\
                                            [target, offset]]):
                                            scaf_xover_ptrs.append(\
                                            [[helix, offset],\
                                            [target, offset]])
                            if seg[4:8] != '    ':
                                lr = seg[4]
                                target = int(seg[5:8])
                                if slices[slice].helix_set.count(target):
                                    # xover_type can be P0, P1, or P2
                                    if slices[slice].neighbor_to_xover[helix]\
                                        .keys().count(target):
                                        xover_type = \
                                            slices[slice]\
                                            .neighbor_to_xover[helix][target]
                                        offset = (21 * i) \
                                        + xover_offset[lr][xover_type]
                                        if helix % 2 == 1: 
                                            # correct for odd strands
                                            offset = offset + 1
                                        if not scaf_xover_ptrs.count(\
                                            [[helix, offset],\
                                            [target, offset]]):
                                            scaf_xover_ptrs.append(\
                                            [[helix, offset],\
                                            [target, offset]])
 
        self.update_path(scaf_xover_ptrs)
                                
    def update_path(self, scaf_xover_ptrs):
        """Updates all parameters of C{Path} (e.g., after input from
            the svg diagram).
        """                                 
        # re-initialize to blank  
        num_helices = len(self.lattice.all_helices)
        num_segments = self.lattice.slice_count     
        
        self.path_array = []     
        self.scaffold_path_list = [] 
        # populate path_array with default tokens
        for helix in range(num_helices):
            path_segment = []
            for segment in range(num_segments+1):
                for i in range(21):
                    path_segment.extend([PathToken(helix,segment)])
            self.path_array.append(path_segment)
        
        # assign next and prev token pointers for even and odd helices
        for i in range(len(self.path_array)):
            row = self.path_array[i]
            if i % 2 == 0: # even tokens point upstream
                for j in range(len(row)-1):
                    row[j].next_token = row[j+1]
                for j in range(1,len(row)):
                    row[j].prev_token = row[j-1]
            else: # odd
                for j in range(1,len(row)):
                    row[j].next_token = row[j-1]
                for j in range(len(row)-1):
                    row[j].prev_token = row[j+1]
        
        # update based on data from svg
        for ptr in scaf_xover_ptrs:
            # previous and next token's positions and helices
            pp = ptr[0][1]
            ph = ptr[0][0]
            np = ptr[1][1]
            nh = ptr[1][0] 
            
            # test if this is a valid crossover
            slice_list = self.lattice.LatticeSliceList
            slice_count = self.lattice.slice_count
            slices = []
            left_segment_boundary = pp - (pp % 21)
            left_slice_index = left_segment_boundary / 21 - 1
            right_slice_index = left_slice_index + 1
            
            # edges only have one slice
            if left_slice_index >= 0:
                slices.append(slice_list[left_slice_index])
            if right_slice_index < slice_count:
                slices.append(slice_list[right_slice_index])
            # check that xover is in right pos to connect to this neighbor    
            offsets = {2:[2, 1, 12, 11], 0:[5, 4, 16, 15 ], 1:[9, 8, 19, 18]}    
            found_neighbor = False
            for slice in slices:
                if ph in slice.helix_set and \
                    nh in slice.neighbor_to_xover[ph].keys():
                    neighbor = slice.neighbor_to_xover[ph][nh]
                    if pp % 21 in offsets[neighbor]:
                        found_neighbor = True
                    
            if found_neighbor:     
                left_offsets = [1, 4, 8, 11, 15, 18]
                right_offsets = [h + 1 for h in left_offsets]
                left_partner_positions = {2:1, 12:11, 5:4, 16:15, 9:8, 19:18}
                right_partner_positions = {1:2, 11:12, 4:5, 15:16, 8:9, 18:19}
                 
                if ph % 2 == 0 and pp % 21 in right_offsets:
                    # a case that can come from svg reading
                    left_partner_xover = [[nh, right_slice_index*21\
                        + left_partner_positions[np % 21]],\
                        [ph, right_slice_index*21 \
                        + left_partner_positions[pp % 21]]]
                    if not left_partner_xover in scaf_xover_ptrs:
                        # clean up
                        self.path_array[ph][pp].prev_token.next_token = None
                        self.path_array[nh][np].next_token.prev_token = None
                        # flip the crossover
                        self.path_array[nh][np].next_token = \
                            self.path_array[ph][pp]
                        self.path_array[ph][pp].prev_token = \
                            self.path_array[nh][np] 
                elif ph % 2 == 1 and pp % 21 in left_offsets:
                    # a case that can come from svg reading
                    right_partner_xover = [[nh, right_slice_index*21\
                        + right_partner_positions[np % 21]],\
                        [ph, right_slice_index*21\
                        + right_partner_positions[pp % 21]]]
                    if not right_partner_xover in scaf_xover_ptrs:
                        # clean up
                        self.path_array[nh][np].next_token.prev_token = None 
                        self.path_array[ph][pp].prev_token.next_token = None
                        # flip the crossover
                        self.path_array[nh][np].next_token = \
                            self.path_array[ph][pp]
                        self.path_array[ph][pp].prev_token = \
                            self.path_array[nh][np]      
                else:
                    if pp % 21 in left_offsets:
                         right_partner_xover = [[nh, right_slice_index*21\
                            + right_partner_positions[np % 21]],\
                            [ph, right_slice_index*21\
                            + right_partner_positions[pp % 21]]]
                         if not right_partner_xover in scaf_xover_ptrs:
                             # clean up
                             self.path_array[ph][pp].next_token.prev_token = None 
                             self.path_array[nh][np].prev_token.next_token = None
                    elif pp % 21 in right_offsets:
                        left_partner_xover = [[nh, right_slice_index*21\
                            + left_partner_positions[np % 21]],\
                         [ph, right_slice_index*21\
                            + left_partner_positions[pp % 21]]]
                        if not left_partner_xover in scaf_xover_ptrs:
                            # clean up
                            self.path_array[ph][pp].next_token.prev_token = None
                            self.path_array[nh][np].prev_token.next_token = None
                                                    
                    # set the new xover
                    self.path_array[ph][pp].next_token = self.path_array[nh][np]
                    self.path_array[nh][np].prev_token = self.path_array[ph][pp]
            else:
                print "ERROR: Invalid scaffold crossover attempted", ph, pp,\
                                                                    "-->",\
                                                                     nh, np
                raise Exception
        self.write_path_file_from_path_array()
        self.get_scaffold_paths()
        self.choose_start_pos() 
        
    def get_scaffold_paths(self):
        """Finds all circular scaffold paths defined by the path array and
         stores each as an ordered list of C{PathToken} objects. This
         provides support for the presence of multiple scaffold paths within one
         scaffold path file. Although a C{path} object by definition represents
         the path of a single scaffold, during early design stages it may be
         necessary for a single scaffold path file to define multiple, 
         diconnected paths that will be sewn together by the user into a 
         single path in the final design. For example, the default scaffold path 
         file generated automatically from a domain file will often contain 
         multiple circular scaffold paths, corresponding to the different domains,
         which are intially disconnected by default.
         """
        for row_of_tokens in self.path_array:
            for token in row_of_tokens:
                if not token.assigned_scaffold_path:
                    sub_path = [token]
                    token.assigned_scaffold_path = True
                    downstream_done = False
                    curr_token = token
                    omit_path = False
                    while not downstream_done:
                        if not curr_token.next_token:
                            downstream_done = True
                            omit_path = True
                        elif curr_token.next_token.assigned_scaffold_path:
                            downstream_done = True
                        else:
                            curr_token = curr_token.next_token
                            curr_token.assigned_scaffold_path = True
                            sub_path.append(curr_token)
                    upstream_done = False
                    curr_token = token
                    while not upstream_done:
                        if not curr_token.prev_token:
                            upstream_done = True
                        elif curr_token.prev_token.assigned_scaffold_path:
                            upstream_done = True
                        else:
                            curr_token = curr_token.prev_token
                            curr_token.assigned_scaffold_path = True
                            sub_path.insert(0, curr_token)
                            
                    # remove unwanted beginning pieces to get circular paths
                    core_start_token = sub_path[-1].next_token
                    
                    if (not omit_path) and sub_path.count(core_start_token):
                        index = sub_path.index(core_start_token)
                        self.scaffold_path_list.append(sub_path[index:])

    def get_debug_scaffold_paths(self):
        """Used for debugging.
        """
        raw_path_list = []
        for row_of_tokens in self.path_array:
            for token in row_of_tokens:
                if not token.assigned_debug_scaffold_path:
                    sub_path = [token]
                    token.assigned_debug_scaffold_path = True
                    downstream_done = False
                    curr_token = token
                    while not downstream_done:
                        if not curr_token.next_token:
                            downstream_done = True
                        elif curr_token.next_token.assigned_debug_scaffold_path:
                            downstream_done = True
                        else:
                            curr_token = curr_token.next_token
                            curr_token.assigned_debug_scaffold_path = True
                            sub_path.append(curr_token)
                    upstream_done = False
                    curr_token = token
                    while not upstream_done:
                        if not curr_token.prev_token:
                            upstream_done = True
                        elif curr_token.prev_token.assigned_debug_scaffold_path:
                            upstream_done = True
                        else:
                            curr_token = curr_token.prev_token
                            curr_token.assigned_debug_scaffold_path = True
                            sub_path.insert(0, curr_token)
                    raw_path_list.append(sub_path)
        return raw_path_list

    def write_path_file_from_path_array(self):
        lattice = self.lattice
        domain_width = self.domain.domain_width
        lattice_slices = self.lattice.LatticeSliceList
        num_segments = len(lattice_slices) + 1 
        # there is one more segment than lattice slice
        all_helices = self.lattice.all_helices
        
        xover_offset = {'L':{2: 1, 0: 4, 1: 8}, 'R': {2: 11, 0: 15, 1: 18}}
        r_xover_offset = {'L':{2: 2, 0: 5, 1: 9}, 'R': {2: 12, 0: 16, 1: 19}}
        
        domain_segment_array = []
        for helix in all_helices:
            sub_domain_segment_array = []
            for segment in range(num_segments):
                sub_domain_segment_array.append([])
            domain_segment_array.append(sub_domain_segment_array)
            
        for helix in all_helices:
            row = self.path_array[helix]
            for segment in range(num_segments):
                for j in range(segment*21, segment*21 + 21):
                    helix = row[j].helix
                
                    slice_indices = []
                    left_segment_boundary = j - (j % 21)
                    left_slice_index = left_segment_boundary / 21 - 1
                    right_slice_index = left_slice_index + 1
                
                    # edges only have one slice
                    if left_slice_index >= 0:
                        slice_indices.append(left_slice_index)
                    if right_slice_index < len(lattice_slices):
                        slice_indices.append(right_slice_index) 
                    
                    for neighbor_type in [0, 1, 2]:
                        if (j % 21 == xover_offset['L'][neighbor_type] or\
                         j % 21 == r_xover_offset['L'][neighbor_type])\
                          and row[j].next_token and row[j].helix !=\
                           row[j].next_token.helix:
                            for slice_index in slice_indices:
                                slice = lattice_slices[slice_index]
                                if helix in slice.helix_set:
                                    neighbor = slice.xover_to_neighbor[helix]\
                                                                [neighbor_type]
                                    if neighbor != None:
                                        if not domain_segment_array[helix]\
                                            [segment].count("L%03d" % neighbor):
                                            domain_segment_array[helix]\
                                            [segment].append("L%03d" % neighbor)
                    
                        if (j % 21 == xover_offset['R'][neighbor_type] or\
                         j % 21 == r_xover_offset['R'][neighbor_type])\
                           and row[j].next_token and row[j].helix !=\
                            row[j].next_token.helix:
                            for slice_index in slice_indices:
                                slice = lattice_slices[slice_index]
                                if helix in slice.helix_set:
                                    neighbor = slice.xover_to_neighbor[helix]\
                                                            [neighbor_type]
                                    if neighbor != None:
                                        if not domain_segment_array[helix]\
                                            [segment].count("R%03d" % neighbor):
                                            domain_segment_array[helix]\
                                            [segment].append("R%03d" % neighbor)         

        # construct xy boundary string
        xy_boundary_str = "   |:"
        for i in range(num_segments):
            xy_boundary_str = xy_boundary_str + "--------"
            xy_boundary_str = xy_boundary_str + ":"
        xy_boundary_str = xy_boundary_str + "|"
        
        # write the file
        file = open(self.scaffold_path_file, "w")
        helix_line_strs = {}
        for helix in all_helices:
            helix_line_str = "%03d|:" % helix
            for segment in range(num_segments):
                str = ""
                for xover_str in domain_segment_array[helix][segment]:
                    str = str + xover_str
                seg_str = "        "
                seg_str = str + seg_str[len(str):]
                helix_line_str = helix_line_str + seg_str + ":"
            helix_line_str = helix_line_str + "|"
            helix_line_strs[helix] = helix_line_str
        file.write(xy_boundary_str + "\n")
        for helix in all_helices:
            file.write(helix_line_strs[helix] + "\n")
        file.write(xy_boundary_str + "\n")
        file.close()    
    
    
    def _generate_path(self):
        """This actually generates multiple disconnected paths,
            which the user will modify and seam together.
        """
        lattice = self.lattice
        domain = self.domain
        bdict = domain.boundary_dict
        domain_width = self.domain.domain_width
        lattice_slices = self.lattice.LatticeSliceList
        num_segments = len(lattice_slices) + 1 
        # there is one more segment than lattice slice
        all_helices = self.lattice.all_helices

        # each element of the domain segment array represents a
        # domain segment and stores a list of crossover strings
        # for the corresponding segment in the scaffold path file
        domain_segment_array = []
        for helix in all_helices:
            sub_domain_segment_array = []
            for segment in range(num_segments):
                sub_domain_segment_array.append([])
            domain_segment_array.append(sub_domain_segment_array)
            
        # put in default crossovers
        for helix in all_helices:
            for segment in range(num_segments):  
                left_slice = segment - 1
                right_slice = segment  
                if segment == 0 and lattice_slices[0].helix_set.count(helix):
                    neighbors = lattice_slices[0]\
                        .neighbor_to_xover[helix].keys()
                    if helix % 2 == 1 and (helix - 1) in neighbors:
                        domain_segment_array[helix][segment]\
                            .append("L%03d" % (helix - 1))
                elif segment == num_segments - 1\
                    and lattice_slices[num_segments - 2].helix_set.count(helix):    
                    neighbors = lattice_slices[num_segments - 2]\
                        .neighbor_to_xover[helix].keys()
                    if helix % 2 == 0 and (helix + 1) in neighbors:
                        domain_segment_array[helix][segment]\
                            .append("L%03d" % (helix + 1))

        # construct xy boundary string
        xy_boundary_str = "   |:"
        for i in range(num_segments):
            xy_boundary_str = xy_boundary_str + "--------"
            xy_boundary_str = xy_boundary_str + ":"
        xy_boundary_str = xy_boundary_str + "|"
        
        # write the file
        file = open(self.scaffold_path_file, "w")
        helix_line_strs = {}
        for helix in all_helices:
            helix_line_str = "%03d|:" % helix
            for segment in range(num_segments):
                str = ""
                for xover_str in domain_segment_array[helix][segment]:
                    str = str + xover_str
                seg_str = "        "
                seg_str = str + seg_str[len(str):]
                helix_line_str = helix_line_str + seg_str + ":"
            helix_line_str = helix_line_str + "|"
            helix_line_strs[helix] = helix_line_str
            
        for helix in all_helices:
            print helix_line_strs[helix]
        file.write(xy_boundary_str + "\n")
        for helix in all_helices:
            file.write(helix_line_strs[helix] + "\n")
        file.close()
        print "Generated default scaffold path."
        
    def classify_tokens_by_domain(self):
        pass
        
        