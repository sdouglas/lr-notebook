"""Bookkeeping of external ASCII files."""

import os
import string
import sys
import ConfigParser
import cPickle as pickle
import time

def read_config(configfile):
    """
    Returns dictionaries containing configuration options.
    
    @return: A dictionary of dictionaries.
    """
    try:
        file = _get_files(configfile)
        param = _get_parameters(file['parameters_file'])
        interfaces = _get_interfaces(file, param)
        svg = _get_svg_parameters(configfile)
    except IOError, e:
        print "Error reading configfile %s\n    %s" % (configfile, e)
    # return {'file':file, 'param':param, 'interfaces':interfaces, 'svg':svg}
    return {'file':file, 'param':param, 'interfaces':interfaces, 'svg':svg}
    

def update_config(file, interface):
    """docstring for update_config"""
    print "Design: %s, interface %s" % (file['design'], interface)
    prefix = file['prefix']
    interfacefile = "%si%s_zinterface.txt" % (prefix, interface)
    svgfile = "%si%s_svg_output.svg" % (prefix, interface)
    picklefile = "%si%s.p" % (prefix, interface)
    outfile = "%si%s_oligos.txt" % (prefix, interface)
    picklegeneratorfile = "%si%s_pickle.py" % (prefix, interface)
    timestampfile = "%si%s_timestamp.txt" % (prefix, interface)
    file['zinterface_file'] = interfacefile
    file['svg_output_file'] = svgfile
    file['pickle_file'] = picklefile
    file['pickle_generator_file'] = picklegeneratorfile
    file['oligo_file'] = outfile
    file['timestamp_file'] = timestampfile
    
    return file
    
def refresh(file):
    """The C{refresh()} method carries out two processes that delete
        files from previous runs of cadnano.
        1) Automatic refresh:
                -helix lattice file
                -domain file
                -scaffold path file
                -oligo output file
           These files are deleted and regenerated in the current run
           if and only if they were last modified DURING the previous run
           of cadnano.
       2) User-Determined Refresh:
                -pickle and pickle generator files
                -svg file
          The user is promted to determine whether he/she wants to 
          re-use saved data pertaining to staples and interfaces
          that is contained in saved pickle files (unless there are no saved
          pickle files present). If the user chooses to re-use this data,
          he/she is then given the option of reading additional data from
          a saved svg file (if present).
      
    """
    # some files are automatically refreshed 
    domain = file['domain_file']
    lattice = file['helix_lattice_file']
    path = file['scaffold_path_file']
    oligos = file['oligo_file']
    
    # these are the files that we currently expect the user to
    # generate automatically, then modify...
    # currently other files like scaffold_path will be hand-written...
    # we could also distinguish creation time from modification time
    files = [lattice, domain, oligos]
    last_runtime = read_timestamp(file)
    if last_runtime == None:
        print "NO PREVIOUS RUN FOUND."
    else:
        for f in file.keys():
            if file[f] in files:
                if os.path.isfile(file[f]):
                    mtime =  int(os.path.getmtime(file[f]))
                    (start, end) = read_timestamp(file)
                    if mtime >= start and mtime <= end:
                        print f, "unmodified.... clearing", f
                        os.remove(file[f])
                        
        # other files require user-input
        pickle = file['pickle_file']
        picklegen = file['pickle_generator_file']
        svg = file['svg_output_file']
        if os.path.isfile(pickle) and os.path.isfile(picklegen):
            print "\nFOUND SAVED PICKLE DATA: DO YOU WANT TO RE-USE SAVED PICKLE DATA? (y/n)\n"
            answer = raw_input()
            while not answer in ["y", "n", "Y", "N"]:
                print "\n...FOUND SAVED PICKLE DATA: DO YOU WANT TO RE-USE SAVED PICKLE DATA? (y/n)\n"
                answer = raw_input()
            if answer in ["n", "N"]:
                os.remove(pickle)
                os.remove(picklegen)
                print "Cleared saved pickle and pickle_generator files."
                if os.path.isfile(svg):
                    os.remove(svg)
                    print "Cleared saved svg file."
            else:
                # old svg only makes sense if using old staple pickle data, 
                # at least when we're only updating breakpoints
                if os.path.isfile(svg):
                    print "\nFOUND SAVED SVG DIAGRAM: DO YOU WANT TO RE-USE SAVED SVG DIAGRAM? (y/n)\n"
                    answer = raw_input()
                    while not answer in ["y", "n", "Y", "N"]:
                        print "\n...FOUND SAVED SVG DIAGRAM: DO YOU WANT TO RE-INPUT SAVED SVG DATA? (y/n)\n"
                        answer = raw_input()
                    if answer in ["n", "N"]:
                        os.remove(svg)
                        print "Cleared saved svg file."

def read_timestamp(file):
    """Reads the starting and ending times for previous run of cadnano
       on a given object.
    """
    if not os.path.isfile(file['timestamp_file']):
        return None
    else:
        file = open(file['timestamp_file'], 'r')
        lines = file.readlines()
        start = int(lines[0])
        end = int(lines[1])
        file.close()
        return (start, end)
    
def write_timestamp(file, start_time):
    """Writes the start and end times for the current run of cadnano on 
        a given object.
    """
    file = open(file['timestamp_file'], 'w')
    start = str(int(start_time)) + '\n'
    end = str(int(time.time())) +'\n'
    lines = [start, end]
    file.writelines(lines)
    file.close()

def _get_interfaces(file, param):
    """Returns a list of zinterface filenames.  One filename is included
    for each interface version specified in the parameters.txt"""
    return [s.strip() for s in param['interfaces'].split(',')]

def _get_files(configfile):
    """
    Returns dictionary containing file names::
    
     helix_lattice_file -- helix_lattice filename (for monomeric unit)
     connector_file -- connector filename (for polymerizing units)
     scaffold_path_file -- scaffold path filename
     x3d_file -- x3d model filename
     oligo_file -- oligo output filename
    
    @return: A dictionary containing (file, path) pairs.
    """
    configparser = ConfigParser.ConfigParser()
    fp = open(configfile, 'r') # may raise IOError.
    configparser.readfp(fp, configfile)
    fp.close()
    return dict(configparser.items('files'))

def _get_parameters(configfile):
    """
    Returns dictionary containing configuration parameters::
    
     segments_per_subdomain -- Default number of segments per sub-domain
    
    @return: A dictionary containing all parameters in the config file.
    """
    configparser = ConfigParser.ConfigParser()
    fp = open(configfile, 'r') # may raise IOError.
    configparser.readfp(fp, configfile)
    fp.close()
    return dict(configparser.items('parameters'))

def _get_svg_parameters(configfile):
    """
    Returns dictionary containing parameters for svg graphics output::
    
     output_svg -- Enable output the svg file.
     draw_scaffold -- Render scaffold path.
     draw_staples -- Render staple paths.
     draw_guide_marks -- Render base pair and crossover guide marks.
    
    @return: A dictionary containing all svg graphics parameters in the 
    config file.
    """
    configparser = ConfigParser.ConfigParser()
    fp = open(configfile, 'r') # may raise IOError.
    configparser.readfp(fp, configfile)
    fp.close()
    return dict(configparser.items('svg'))

def get_pickle_data(config):
    """docstring for get_pickle_data"""
    try:
        filename = config['file']['pickle_file']
        (exclude, breakpoint, caps, connectors) = pickle.load(open(filename))
    except IOError, e:
        print "Error reading pickle file:\n    %s" % e
        sys.exit(1)
    return {'exclude':exclude, \
            'breakpoint':breakpoint, \
            'caps':caps, \
            'connectors':connectors}

def get_xover_info(config):
    """
    Unpickles a tuple containing exclude and breakpoint dictionaries, which
    are output by a design's pickle.py script.  Temporary solution while
    we are preparing to automate selection of breakpoints.
    
    @return: A tuple containing exclude and breakpoint dictionaries.
    """
    filename = config['file']['xover_pickle_file']
    return pickle.load(open(filename))

def get_lines(filename):
    """Retrieve contents of file.
    @return: A list of lines in C{filename}
    @raise IOError: If C{filename} is not found.
    """
    try:
        filehandle = open(filename)
    except IOError:
        sys.exit("Error: file \'%s\' not found." % filename)
    lines = filehandle.readlines()
    filehandle.close()
    return [s.rstrip('\n') for s in lines]

def write_lines(filename, lines):
    """Output an array of strings to file."""
    try:
        filehandle = open(filename, "w")
        result = filehandle.writelines(lines)
    except IOError:
        sys.exit("Error: file \'%s\' could not be written." % filename)
    return result
