"""
The domain.py module provides the first-pass processing of scaffold 
domains, which are subsections of the scaffold.

The general idea of the domain module is to enable the user to easily add or 
remove scaffold crossovers that differ from the default arrangement.  By 
default, the scaffold spans most segment boundaries in a virtual strand, and 
thus the scaffold path continues for long stretches in the z-direction. 
Typically there are only two external crossovers in the first and last 
segments that link even virtual strands to odd virtual strands, and a single 
internal crossover linking odd virtual strands to even virtual strands. 

The purpose allowing more precise control of the scaffold path is to 
facilitate the creation of scaffold "domains". Scaffold domains are 
regions of the scaffold strand that are connected via the scaffold to 
neighboring scaffold regions at only two points.  These connection points 
can be in the form of a single internal crossover (in the xy-direction) or 
two helices that continue from neighboring segments (in the z-direciton). 
Domains are still highly connected by oligos.

The hope is that by minimizing the number of connections that impose 
topological constraints on the scaffold, domains should fold independently 
from other domains to some extent and perhaps reduce kinetic traps.

In order to create domains, many additional scaffold crossovers must be 
introduced to prevent the scaffold from spanning segment boundaries that 
mark the edges of the desired domain.  This module allows the definition of 
those boundaries.  The path.py module is subsequently used to precisely 
define the exact locations of crossovers, as well as to connect all domains 
to form a complete scaffold path.


Initialization
==============
When the C{Domain} class is initialized, it checks for the existence of the
domain file specified in the config file.  If the file exists, then it
is parsed.  If the file does not exist, then a default file is generated
based on the C{Lattice} input and the C{segments_per_subdomain} parameter
in the configuration file.


Generating the default input
============================

Consider the following example input, a Lattice object based on with 6 identical LatticeSlices::

       ...   006   004   002   000   ...
    ...   007   005   003   001   ...   

    ...   008   010   012   014   ...   
       ...   009   011   013   015   ...


Assume C{segments_per_subdomain} = 6, as read from the configuration file.  When C{Domain} is instantiated, C{_generate_domain} will output the following to create a new domain file::

       |:--------.--------.--------.--------.--------.--------:|
    000|:        .        .        .        .        .        :|
    001|:        .        .        .        .        .        :|
    002|:        .        .        .        .        .        :|
    003|:        .        .        .        .        .        :|
    004|:        .        .        .        .        .        :|
    005|:        .        .        .        .        .        :|
    006|:        .        .        .        .        .        :|
    007|:        .        .        .        .        .        :|
    008|:        .        .        .        .        .        :|
    009|:        .        .        .        .        .        :|
    010|:        .        .        .        .        .        :|
    011|:        .        .        .        .        .        :|
    012|:        .        .        .        .        .        :|
    013|:        .        .        .        .        .        :|
    014|:        .        .        .        .        .        :|
    015|:        .        .        .        .        .        :|
       |:--------.--------.--------.--------.--------.--------:|


The first 3 columns contain either spaces (indicating xy-boundary lines) or 
a helix number.  The pipe symbol (C{|}) marks the beginning and end of the 
remainder of the line.  Each segment is represented by 8 spaces, and 
segments are separated by a period (C{.}) to indicate continuous connection 
to a neighboring segment, or by a colon (C{:}) to indicate the edge of the 
domain (z-boundary).  The first and last lines contain xy-boundaries::

       |:--------.--------.--------.--------.--------.--------:|

The xy-boundaries indicate whether a particular segment can contain 
a crossover to its natural neighbor (i.e. the virtual helix that 
is named one integer value away from the current helix name).  In this 
example, the natural neighbors of 003 are 002 and 004, but not 012.

Parsing the domain file
=======================
When the domain file is parsed, the result is that the domain boundaries are stored in C{boundary_dict}, a nested dictionary with the format 
C{boundary_dict}[helix][segment][boundary_type] = C{True} or C{False}.  If the 
values is C{True}, it means a boundary was found in the domain file at that 
position and thus a crossover should not be included in the case of an 
xy-boundary, or should be included in the case of a z-boundary.

The C{boundary_type} keys are C{'+xy'}, C{'-xy'}, C{'+z'} and C{'-z'}.  The 
C{'+xy'} and C{'-xy'} keys indicate the subsequent and previous xy-boundaries, 
respectively, for a helix at a particular segment.  The C{'+z'} and C{'-z'} 
keys indicate the subsequent and previous z-boundaries for a segment within 
a particular helix.

Modifying the default file
==========================
The most straightforward way to change domain layout is by changing the 
value of C{segments_per_subdomain} in the configuration file.  (Note: the 
old domain file should be deleted so a new one is generated) This affects 
domains with respect to the z-direction. For example, if the value of 
C{segments_per_subdomain} = 2, the default output changes to this::

       |:--------.--------:--------.--------:--------.--------:|
    000|:        .        :        .        :        .        :|
    001|:        .        :        .        :        .        :|
    002|:        .        :        .        :        .        :|
    003|:        .        :        .        :        .        :|
    004|:        .        :        .        :        .        :|
    005|:        .        :        .        :        .        :|
    006|:        .        :        .        :        .        :|
    007|:        .        :        .        :        .        :|
    008|:        .        :        .        :        .        :|
    009|:        .        :        .        :        .        :|
    010|:        .        :        .        :        .        :|
    011|:        .        :        .        :        .        :|
    012|:        .        :        .        :        .        :|
    013|:        .        :        .        :        .        :|
    014|:        .        :        .        :        .        :|
    015|:        .        :        .        :        .        :|
       |:--------.--------:--------.--------:--------.--------:|

To modify the domain layout in the xy-direction, the actual domain file 
can be edited.  By copying xy-boundary line and pasting it in between 
neighboring helices, new boundaries can be added::

       |:--------.--------:--------.--------:--------.--------:|
    000|:        .        :        .        :        .        :|
    001|:        .        :        .        :        .        :|
    002|:        .        :        .        :        .        :|
    003|:        .        :        .        :        .        :|
       |:--------.--------:--------.--------:--------.--------:|
    004|:        .        :        .        :        .        :|
    005|:        .        :        .        :        .        :|
    006|:        .        :        .        :        .        :|
    007|:        .        :        .        :        .        :|
       |:--------.--------:--------.--------:--------.--------:|
    008|:        .        :        .        :        .        :|
    009|:        .        :        .        :        .        :|
    010|:        .        :        .        :        .        :|
    011|:        .        :        .        :        .        :|
       |:--------.--------:--------.--------:--------.--------:|
    012|:        .        :        .        :        .        :|
    013|:        .        :        .        :        .        :|
    014|:        .        :        .        :        .        :|
    015|:        .        :        .        :        .        :|
       |:--------.--------:--------.--------:--------.--------:|

These boundaries will subsequently be used in the C{path} module to 
determine explicit scaffold crossover locations.

Output & Debugging
==================
@todo: Fix C{Domain} __init__ method so sanity checks raise exceptions rather
than print statements.


"""
import os
import re
import sys
from file import get_lines, write_lines
        
class Domain():
    """The Domain class stores a nested dictionary containing domain
       boundary information.
    """
    def __init__(self, config, lattice):
        self.dom_file = config['file']['domain_file']
        """@ivar: Location of the domain input file.
           @type: C{string}
        """
        self.lattice = lattice
        """@ivar: Link to the lattice object, used for extracting meta data
           such as C{slice_count} and C{all_helices}.
           @type: C{Lattice}
        """
        self.domain_width = int(config['param']['segments_per_subdomain'])
        # generate default domain file if necessary
        if not os.path.isfile(self.dom_file):
            self._generate_domain(self.domain_width)
        self.boundary_dict = self._parse_domain()
        """@ivar: boundary_dict[helix][segment][boundary_type] stores the
           boundary information for each helix segment, as determined from
           the domain file.
           @type: C{dictionary}
        """
        
        # sanity checks (replace with exceptions)
        if len(lattice.all_helices) != len(self.boundary_dict.keys()):
            print "Mismatch in helix count for lattice and domain inputs."
        for key in self.boundary_dict.keys():
            if lattice.slice_count != len(self.boundary_dict[key]):
                print "Mismatch in segments for lattice and domain inputs."
    
    def _parse_domain(self):
        """Extracts domain boundary information from file input and returns
           it in a nested C{dictionary} object.
        """
        dom_dict = {}
        filename = self.dom_file
        lines = get_lines(filename)
        for i in range(len(lines)):
            if lines[i].startswith('   '):  # skip x-boundaries for now
                continue
            else:
                # parse line using multiple splits
                s1 = lines[i].split('|')
                helix = int(s1[0])
                boundary = {}
                s2 = s1[1].split() # split on whitespace to get boundaries
                # when a colon (:) is found, mark that as a z-boundary
                for j in range(self.lattice.slice_count):
                    boundary[j] = {'-xy':False, '+xy':False, \
                                   '-z':False, '+z':False}
                    if s2[j] == ':':
                        boundary[j]['-z'] = True
                    if s2[j+1] == ':':
                        boundary[j]['+z'] = True
                # process x-boundaries
                if lines[i-1].startswith('   '): # previous line
                    s3 = lines[i-1].split('|')
                    s4 = re.split('[:\.]', s3[1])[1:-1]
                    for i in range(self.lattice.slice_count):
                        # when dashes are found, mark as x-boundary
                        if s4[i] == '--------':
                            boundary[i]['-xy'] = True
                if lines[i+1].startswith('   '): # next line
                    s3 = lines[i+1].split('|')
                    s4 = re.split('[:\.]', s3[1])[1:-1]
                    for i in range(self.lattice.slice_count):
                        # when dashes are found, mark as x-boundary
                        if s4[i] == '--------':
                            boundary[i]['+xy'] = True
                dom_dict[helix] = boundary # record parsed results
        return dom_dict

    def _generate_domain(self, domain_width):
        """Outputs a default domain file based on C{Lattice} and parameter
           input.
        """
        lattice = self.lattice
        all_helices = self.lattice.all_helices
        domain_lines = [['%03d|:' % h] for h in all_helices]
        for i in range(lattice.slice_count):
            slice = lattice.LatticeSliceList[i]
            for j in range(len(all_helices)):
                if all_helices[j] in slice.helix_set:
                    domain_lines[j].append('        ')
                else:
                    domain_lines[j].append('XXXXXXXX')
                if (i+1) % domain_width == 0:
                    domain_lines[j].append(':')
                else:
                    domain_lines[j].append('.')
        for i in range(len(all_helices)):
            domain_lines[i].append('|')
        divider = '   |:'
        dash = ''.join(['-' for i in range(8)])
        for i in range(lattice.slice_count):
            divider = divider + dash
            if (i+1) % domain_width == 0:
                divider = divider + ':'
            else:
                divider = divider + '.'
        divider = divider + '|'
        output = divider + '\n'
        for dl in domain_lines:
            output = output + ''.join(dl) + '\n'
        output = output + divider + '\n'
        write_lines(self.dom_file,output)
        print "Generated new domain file: %s" % self.dom_file
        
