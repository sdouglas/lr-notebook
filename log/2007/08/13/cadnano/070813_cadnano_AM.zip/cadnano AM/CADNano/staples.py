"""Generates an internal representation of the staples, based on scaffold input.
@todo: write routines to break staple paths
"""

import string
import re
import os
import cPickle as pickle
from svg import SvgReader
from file import get_pickle_data

class StapleToken():
    """A C{StapleToken} is used to store information about a single
    base of staple oligo.
    While pointers to all C{StapleToken} objects are stored in the 
    C{Staples.staple_tokens} list as entry points, each C{StapleToken}
    actually has internal pointers to its 5' (next_token) and 3' (prev_token)
    neighbors. It is based on the arrangement of these internal pointers
    that actual staple paths and eventually oligo sequences are derived.
    """
    def __init__(self, helix, segment, base, position):
        self.helix = helix
        """@ivar: Helix number of the C{StapleToken}.
           @type: C{int}
        """
        self.position = position
        """@ivar: Position (or index) of C{StapleToken} in the staple_tokens.
           @type: C{int}
        """
        self.segment = segment
        """@ivar: Segment number of the C{StapleToken}.
           @type: C{int}
        """
        self.base = base
        """@ivar: DNA base letter (A, T, C, G) of the C{StapleToken}.
           @type: C{string}
        """
        self.domain = None
        """@ivar: Doman number of the C{StapleToken}.
           @type: C{int}
        """
        self.visited = False
        """@ivar: Records whether or not a C{StapleToken} has been 
           visited when populating the tokens with scaffold sequence.
           @type: C{boolean}
        """
        self.assigned_path = False
        """@ivar: Records whether or not a C{StapleToken} has been assigned
           to a path.
           @type: C{boolean}
        """
        self.in_continuous_path = False
        """@ivar: Records whether or not a C{StapleToken} has been assigned
           to an continuous path.
           @type: C{boolean}
        """
        self.next_token = None
        """@ivar: 5' pointer to next C{StapleToken} in the scaffold path.
           @type: C{PathToken}
        """
        self.prev_token = None
        """@ivar: 3' pointer to previous C{StapleToken} in the scaffold path.
           @type: C{PathToken}
        """
        self.rank = 0
        """@ivar: Stores the order in which a C{StapleToken} was visited or
           generated; used for debugging purposes.
           @type: C{int}
        """
        self.cap = False
        self.connector = False


class StaplePath(object):
    """Stores information about a particular staple."""
    def __init__(self, first_token):
        self.first_token = first_token
        """@ivar: Pointer to 5' C{StapleToken} in a scaffold path.
           @type: C{PathToken}
        """
        self.token_list = []
        """@ivar: An ordered list of C{StapleToken} objects comprising the
           staple path.
           @type: C{List}
        """
        self.sequence = ''
        """@ivar: DNA sequence of the C{PathToken}.
           @type: C{string}
        """
        self.length = 0
        """@ivar: Length of DNA sequence of the C{PathToken}.
           @type: C{int}
        """
        self.cap = False
        self.connector = False
        self._parse_path()
    
    def _parse_path(self):
        """Traverse connected C{StapleToken} path, recording DNA sequence and
        token pointers."""
        seq = ''
        temp_token_list = []
        curr_token = self.first_token
        
        # using the temp to avoid a problem with unintended object persistence
        temp_token_list = []
        while curr_token.next_token != None\
            and not temp_token_list.count(curr_token.next_token):
            seq = seq + curr_token.base
            temp_token_list.append(curr_token)
            curr_token = curr_token.next_token
        # one last time
        seq = seq + curr_token.base
        temp_token_list.append(curr_token)
        self.token_list = temp_token_list
        self.sequence = seq
        self.length = len(seq)

class Staples:
    """Most of the major processing in the C{staples.py} module for
    takes place with the creation of a C{Staples} object.  The process
    works as follows::
    
        1. The C{staple_tokens} list is populated with C{StapleToken} objects
        based on the C{Path.path_array}.
    
        2. The C{StapleToken} pointers to neighboring tokens are rearranged
        to reflect the proper crossover positions of the structure.  This
        information is derived from the C{LatticeSlice} objects.
        Specific user-specified crossover positions that normally would have
        been included are left out based on the contents of the C{exclude}
        dictionary.
    
        4. Staple path breakpoints are inserted.  Right now, these are
        user-specified breakpoints, but we will soon write a function to
        automatically determine breakpoints based on yet-to-be-determined
        rules.
    
        5. Hook up z-interfaces or terminate and cap edges.
    
        6. A list of 5'-most C{StapleToken} pointers is gathered in 
        C{staple_start_pointers}.
    
        7. Each staple path is traversed by looping through
        C{staple_start_pointers}.  Helices, domains, and positions visited
        by that staple are recorded.
    
        8. Based on meta-info recorded in step 5, staples are sorted into
        different groups (core, connectors, etc.).  Actual base sequences are 
        constructed and staples are output to file.
        
        -----
        Note on new initialization procedure: 
        *After a C{Staples} object is constructed, the user must 'set
        its parameters' before it can generate staples. The paramters may
        be set in multiple ways:
        1) parameters can be read from previously pickled data
        2) default parameters can be computed
        *Once the parameters have been 'set', they can be 'updated' using 
        data read from the svg file.
        *After setting, and optional updating of parameters, the user must call the
        C{Staples.init_from_params()} method, which carries out staple generation.
        *At any time, the user can call C{Staples.update_params_from_svg()}, 
        followed by C{Staples.init_from_params()} in order to re-generate
        staples to reflect changes in the svg file.
    """
    
    def __init__(self, config, scaffold):
        self.file = config['file']
        self.scaffold = scaffold
        """@ivar: Internal pointer to C{Scaffold} object.
           @type: C{Scaffold}
        """
        self.path = scaffold.path
        """@ivar: Internal pointer to C{Path} object.
           @type: C{Path}
        """
        self.domain = self.path.domain
        """@ivar: Internal pointer to C{Domain} object.
           @type: C{Path}
        """    
        self.lattice = self.path.lattice
        """@ivar: Pointer to the lattice object, used for extracting 
           metadata such as C{slice_count} and C{all_helices}.
           @type: C{Lattice}
        """
        self.staple_tokens = []
        """@ivar: Stores all C{StapleToken} objects in an array format.
           @type: C{List}
        """
        self.staple_start_pointers = []
        """@ivar: 5' staple pointers for all staple paths.
           @type: C{List}
        """
        self.continuous_staple_path_list = []
        """@ivar: stores the continuous staple paths as a list of 
                  ordered (5'-3') lists of staple tokens
           @type: C{List}
        """
        self.staple_array = []
        """@ivar: Final list of staples, created by breaking up staple paths
           and adding any 5' or 3' modifications. The elements of the list are 
           C{StaplePath} objects.
           @type: C{List}
        """
        self.rank = 0
        """@ivar: debugging variable.
           @type: C{int}
        """
        self.default_pickle_data = None
        """@ivar: 
           @type: 
        """
        self.populate_staple_tokens()
        
        # set staple-generation parameters
        if not os.path.isfile(config['file']['pickle_file']):
            # if there is no pickle file, then use defaults
            self.set_default_params()
            # and write a pickle file from the defaults
            self.write_pickle_data()
        else:
            # otherwise read-in pre-existing pickle data
            pickle_data = get_pickle_data(config)
            self.set_params_from_pickle_data(pickle_data)
        
        svg_reader = SvgReader(config, self.path)
        # optionally update the staple-generation parameters using svg input
        
        if os.path.isfile(config['file']['svg_output_file']):
            self.update_params_from_svg(svg_reader)
            # re-pickle based on svg input
            self.write_pickle_data()
        # now that parameters are set, generate the staples
        self.init_from_params()
        # output/update the svg file
      
    def set_params_from_pickle_data(self, pickle_data):
        """
        """
        if pickle_data != None:
            # read in pickle_data
            self.exclude = pickle_data['exclude']
            """@ivar: Pointer to helix positions where paths should be
               continuous.
               @type: C{dictionary}
            """
            self.breakpoint = pickle_data['breakpoint']
            """@ivar: Pointer to helix positions where paths should be broken.
               @type: C{dictionary}
            """
            self.caps = pickle_data['caps']
            """@ivar: Cap positions.
               @type: C{dictionary}
            """
            self.connectors = pickle_data['connectors']
            """@ivar: Connector positions.
               @type: C{dictionary}
            """
        else:
             # report an error
             pass
             
    def set_default_params(self):
        """
        """
        default_exclude = self.get_default_crossover_excludes(4)
        self.exclude = default_exclude
        
        # we temporarily insert crossovers in order to compute breakpoints
        # these crossovers are cleared in C{Staples.init_from_params()}
        self.insert_crossovers()
        self.get_continuous_staple_paths()
        
        default_breakpoint = self.get_default_breakpoints()
        self.breakpoint = default_breakpoint
        
        default_caps = self.get_default_caps()
        self.caps = default_caps
        
        default_connectors = self.get_default_connectors()
        self.connectors = default_connectors
        
        # we may later want to pickle the default data
        self.default_pickle_data = {'exclude': default_exclude,\
                                    'breakpoint': default_breakpoint,\
                                    'caps': default_caps,\
                                    'connectors': default_connectors}
                                    
    def update_params_from_svg(self, svg_reader):
        svg_breakpoint = svg_reader.read_breakpoints_from_svg()
        print "Updating breakpoints from svg."
        self.breakpoint = svg_breakpoint
        
        print "Updating staple crossovers from svg."
        svg_xover_includes = svg_reader.read_staple_xovers()
        # edit the staple xover excludes based on svg input
        for helix in range(len(self.path.path_array)):
            #don't exclude added xovers
            for ex in self.exclude[helix]:
                if ex in svg_xover_includes[helix]:
                    index = self.exclude[helix].index(ex)
                    self.exclude[helix] = self.exclude[helix][:index]\
                                       + self.exclude[helix][index + 1:]
            #exclude removed xovers
            row = self.path.path_array[helix]
            for j in range(len(row)):
                if j % 7 == 0:
                    if not j in svg_xover_includes[helix]:
                        self.exclude[helix].append(j)     
                        
        print "Updating scaffold crossovers from svg."
        self.path.update_path(svg_reader.read_scaffold_crossovers())
        self.scaffold._populate()  
            
    def init_from_params(self):
        """
        """
        # first clear previously generated data
        self.staple_tokens = []
        """@ivar: Stores all C{StapleToken} objects in an array format.
           @type: C{List}
        """
        self.staple_start_pointers = []
        """@ivar: 5' staple pointers for all staple paths.
           @type: C{List}
        """
        self.continuous_staple_path_list = []
        """@ivar: stores the continuous staple paths as a list of 
                  ordered (5'-3') lists of staple tokens
           @type: C{List}
        """
        self.staple_array = []
        """@ivar: Final list of staples, created by breaking up staple paths
           and adding any 5' or 3' modifications. The elements of the list are 
           C{StaplePath} objects.
           @type: C{List}
        """
        self.populate_staple_tokens()
        self.insert_crossovers()
        self.process_z_interfaces()
        self.get_continuous_staple_paths()
        self.insert_breakpoints()
        self.get_start_pointers() # get 5'staple pointers that begin paths
        self.populate_staple_array()
        self.sort_paths()
        self.output_paths()
        
        
    def write_pickle_file(self):
        """ Write a .p file encoding the current parameters.
        """
        filename = self.file['pickle_file']
        pickle_file = open(filename, 'w')
        print "Writing pickle file.."
        exclude = self.exclude
        breakpoint = self.breakpoint
        caps = self.caps
        connectors = self.connectors
        to_dump = (exclude, breakpoint, caps, connectors)
        pickle.dump(to_dump, pickle_file)
        pickle_file.close()
        print "...done", filename
        
    def write_pickle_generator_file(self):
        """ Write a Python module to generate a .p file
            encoding the current paramaters.
        """
        filename = self.file['pickle_generator_file']
        print "Writing pickle-generator script.."
        pickle_generator_file = open(filename, 'w')
        
        import_lines = '''
#!/usr/bin/env python
# encoding: utf-8
import sys
import os
import cPickle as pickle
'''
        exclude = self.exclude
        breakpoint = self.breakpoint
        caps = self.caps
        connectors = self.connectors
        
        exclude_function = self.get_python_list_function(exclude,\
                                                        "exclude",\
                                                    "get_excluded_xovers")
        breakpoint_function = self.get_python_list_function(breakpoint,\
                                                            "breakpoint",\
                                                     "get_staple_breakpoints")
        caps_function = self.get_python_list_function(caps,\
                                                    "caps",\
                                                    "get_caps")
        connectors_function = self.get_python_list_function(connectors,\
                                                    "connectors",\
                                                    "get_connectors")
        
        main_function = '''
def main():
    exclude = get_excluded_xovers()
    breakpoint = get_staple_breakpoints()
    caps = get_caps()
    connectors = get_connectors()
    info = (exclude, breakpoint, caps, connectors)
    pickle.dump(info, open('%s', 'w'))

if __name__ == '__main__':
    main()
''' % os.path.split(self.file['pickle_file'])[1]
# this gives the relative path of the pickle file

        script = import_lines +\
                exclude_function +\
                breakpoint_function +\
                caps_function +\
                connectors_function +\
                main_function
        pickle_generator_file.write(script)
        pickle_generator_file.close()        
        print "...done", filename

    def write_pickle_data(self):
        # writes a .p file 
        self.write_pickle_file()
        # writes a pickle.py file if there is none already
        self.write_pickle_generator_file()
        
    def populate_staple_tokens(self):
        """Initial blank staple tokens are populated based on the structure
        of the C{Path.path_array}.  Each base position in the
        path_array has a corresponding C{StapleToken} added to the 
        C{staple_tokens} list.  The default C{next_token} and C{prev_token}
        pointers are also assigned, with even strand tokens pointing to
        right to left, and odd strand tokens pointing left to right.  The
        end terminal tokens point to C{None}."""
        for vstrand in self.path.path_array:
            row = []
            position = 0
            for token in vstrand:
                h = token.helix
                s = token.segment
                b = ' '
                p = position
                if token.base in 'ATCG':
                    b = self._comp(token.base)
                row.append(StapleToken(h, s, b, p))
                position = position + 1
            self.staple_tokens.append(row)
        # assign initial staple token pointers
        for i in range(len(self.staple_tokens)):
            row = self.staple_tokens[i]
            if i % 2 == 0:
                row = row[::-1]  # traverse even strands right to left
            for j in range(len(row)-1):
                row[j].next_token = row[j+1]
                row[j].next_token.prev_token = row[j]
    
    def get_default_crossover_excludes(self, min_dist_to_scaf_xover):
        # set min_dist_to_scaf_xover to -1 if you want no exclusion
        # based on proximity to scaffold crossover
        """Generates a default dictionary of staple crossover positions to
           exclude on each helix. Crossovers that are within 5 bases of a
           scaffold crossover, and crossovers that begin or end on a position
           without scaffold are excluded. 
        """
        scaf_xover_positions = [2, 5, 9, 12, 16, 19] + [1, 4, 8, 11, 15, 18]
        
        exclude = {}
        for helix in range(len(self.path.path_array)):
            exclude[helix] = []
        
        slice_list = self.lattice.LatticeSliceList
        slice_count = self.lattice.slice_count
        for helix in range(len(self.path.path_array)):
            row = self.path.path_array[helix]
            for j in range(len(row)):
                xover_pos = j
                if helix % 2 == 1:
                    xover_pos = xover_pos + 1
                if not row[j].base in 'ATCG' and xover_pos % 7 == 0:
                    # exclude if no scaffold at donor
                    if not exclude[helix].count(xover_pos):
                        exclude[helix].append(xover_pos)
                elif row[j].base in 'ATCG' and xover_pos % 7 == 0:  
                    # scaffold is present
                    
                    slice_indices = []
                    left_segment_boundary = j - (j % 21)
                    left_slice_index = left_segment_boundary / 21 - 1
                    right_slice_index = left_slice_index + 1
                    
                    # edges only have one slice
                    if left_slice_index >= 0:
                        slice_indices.append(left_slice_index)
                    if right_slice_index < slice_count:
                        slice_indices.append(right_slice_index)
                    
  
                    # exclude staple crossovers near scaffold crossovers
                    scaf_xovers = [i-21 for i in scaf_xover_positions]\
                                + scaf_xover_positions\
                                + [i + 21 for i in scaf_xover_positions]
                    
                    for curr_slice_index in slice_indices:
                        curr_slice = slice_list[curr_slice_index]
                        xover_to_neighbor = curr_slice.xover_to_neighbor
                        if curr_slice.helix_set.count(helix):
                            pa = self.path.path_array
                            if xover_pos % 21 == 0:
                                p0neighbor = xover_to_neighbor[helix][0]
                                for p in scaf_xovers:
                                    r = (right_slice_index*21) + p
                                    if 0 <= r and r < len(pa[helix]):
                                        dist = abs( (xover_pos - r ) )
                                        if dist <= (min_dist_to_scaf_xover + 1):
                                            token = pa[helix][r]
                                            if token.next_token\
                                                and token.prev_token:
                                                nh = token.next_token.helix
                                                ph = token.prev_token.helix
                                                if p0neighbor != None \
                                                    and (nh == p0neighbor\
                                                        or ph == p0neighbor):
                                                    if not exclude[helix]\
                                                        .count(xover_pos):
                                                        exclude[helix]\
                                                        .append(xover_pos)
                                                    if not exclude[p0neighbor]\
                                                        .count(xover_pos):
                                                        exclude[p0neighbor]\
                                                        .append(xover_pos)
                            elif xover_pos % 21 == 14:
                                p1neighbor = xover_to_neighbor[helix][1]
                                for p in scaf_xovers:
                                    r = (right_slice_index*21) + p
                                    if 0 <= r and r < len(pa[helix]):
                                        dist = abs( (xover_pos - r ) )
                                        if dist <= (min_dist_to_scaf_xover + 1):
                                            token = pa[helix][r]
                                            if token.next_token\
                                                and token.prev_token:
                                                nh = token.next_token.helix
                                                ph = token.prev_token.helix
                                                if p1neighbor != None \
                                                    and (nh == p1neighbor\
                                                        or ph == p1neighbor):
                                                    if not exclude[helix]\
                                                        .count(xover_pos):
                                                        exclude[helix]\
                                                        .append(xover_pos)
                                                    if not exclude[p1neighbor]\
                                                        .count(xover_pos):
                                                        exclude[p1neighbor]\
                                                        .append(xover_pos)  
                            elif xover_pos % 21 == 7:
                                p2neighbor = xover_to_neighbor[helix][2]
                                for p in scaf_xovers:
                                    r = (right_slice_index*21) + p
                                    if 0 <= r and r < len(pa[helix]):
                                        dist = abs( (xover_pos - r ) )
                                        if dist <= (min_dist_to_scaf_xover + 1):
                                            token = pa[helix][r]
                                            if token.next_token\
                                                and token.prev_token:
                                                nh = token.next_token.helix
                                                ph = token.prev_token.helix
                                                if p2neighbor != None\
                                                    and (nh == p2neighbor\
                                                        or ph == p2neighbor):
                                                    if not exclude[helix]\
                                                        .count(xover_pos):
                                                        exclude[helix]\
                                                        .append(xover_pos)
                                                    if not exclude[p2neighbor]\
                                                        .count(xover_pos):
                                                        exclude[p2neighbor]\
                                                        .append(xover_pos) 
                    
                    #exclude crossovers to windows/peripheral regions
                    # get left and right slices for this position
                    slices = []
                    left_segment_boundary = j - (j % 21)
                    left_slice_index = left_segment_boundary / 21 - 1
                    right_slice_index = left_slice_index + 1
                    
                    # edges only have one slice
                    if left_slice_index >= 0:
                        slices.append(slice_list[left_slice_index])
                    if right_slice_index < slice_count:
                        slices.append(slice_list[right_slice_index])
                    
                    for slice in slices:
                        xover_to_neighbor = slice.xover_to_neighbor
                        curr_token = self.staple_tokens[helix][j]
                        if slice.helix_set.count(helix):
                            if xover_pos % 21 == 0: # check for P0 xover
                                p0neighbor = xover_to_neighbor[helix][0]
                                if p0neighbor != None:
                                    b = self.path.path_array[p0neighbor][j].base
                                    if not b in "ATCG":
                                        # exclude if no scaffold at acceptor
                                        if not exclude[helix].count(xover_pos):
                                            exclude[helix].append(xover_pos)
                                
                                else: 
                                    # exclude if no scaffold at acceptor slice
                                    if not exclude[helix].count(xover_pos):
                                        exclude[helix].append(xover_pos)
                                
                            if xover_pos % 21 == 14: # check for P1 xover
                                p1neighbor = xover_to_neighbor[helix][1]
                                if p1neighbor != None:
                                    b = self.path.path_array[p1neighbor][j].base
                                    if not b in "ATCG":
                                        # exclude if no scaffold at acceptor
                                        if not exclude[helix].count(xover_pos):
                                            exclude[helix].append(xover_pos)
                                else: 
                                    # exclude if no scaffold at acceptor slice
                                    if not exclude[helix].count(xover_pos):
                                        exclude[helix].append(xover_pos)
                                  
                            if xover_pos % 21 == 7: # check for P2 xover
                                p2neighbor = xover_to_neighbor[helix][2]
                                if p2neighbor != None:
                                    b = self.path.path_array[p2neighbor][j].base
                                    if not b in "ATCG":
                                        # exclude if no scaffold at acceptor
                                        if not exclude[helix].count(xover_pos):
                                            exclude[helix].append(xover_pos)
                                else: 
                                    # exclude if no scaffold at acceptor slice
                                    if not exclude[helix].count(xover_pos):
                                        exclude[helix].append(xover_pos)
        return exclude

    def insert_crossovers(self):
        """Staple crossovers are inserted as follows:
            1. loop through each helix:
            2.  loop through each base position (token) in a helix:
            3.   if scaffold is present AND if position is not excluded:
            4.    determine neighbor based on left and right slices
            5.    if neighbor scaffold is present at current position:
            6.      insert crossover
        """
        slice_list = self.lattice.LatticeSliceList
        slice_count = self.lattice.slice_count
        exclude = self.exclude
        
        # loop through base positions based on path_array
        for helix in range(len(self.path.path_array)):
            row = self.path.path_array[helix]
            for j in range(len(row)):
                if row[j].base in 'ATCG':  # scaffold is present
                    xover_pos = j
                    if helix % 2 == 1:
                        xover_pos = xover_pos + 1
                
                    if xover_pos in exclude[helix]: # skip excluded positions
                        continue
                    
                    # get left and right slices for this position
                    slices = []
                    left_segment_boundary = j - (j % 21)
                    left_slice_index = left_segment_boundary / 21 - 1
                    right_slice_index = left_slice_index + 1
                
                    # edges only have one slice
                    if left_slice_index >= 0:
                        slices.append(slice_list[left_slice_index])
                    if right_slice_index < slice_count:
                        slices.append(slice_list[right_slice_index])
                
                    # This loop currently sets an xover position and
                    # then overwrites it if the same one is found in
                    # a separate slice.  May want to add a check 
                    # here to see if they match.  A mismatch would 
                    # indicate a problem.
                    for slice in slices:
                        if slice.helix_set.count(helix):
                            xover_to_neighbor = slice.xover_to_neighbor
                            curr_token = self.staple_tokens[helix][j]
                            if xover_pos % 21 == 0: # check for P0 xover
                                p0neighbor = xover_to_neighbor[helix][0]
                                if p0neighbor != None:
                                    #handle peripheral single-crossover
                                    b = self.path.path_array[p0neighbor][j].base
                                    if curr_token.next_token and not b in "ATCG":
                                        curr_token.next_token.prev_token = None                                    
                                    curr_token.next_token = \
                                    self.staple_tokens[p0neighbor][j]
                                    curr_token.next_token.prev_token = curr_token
                            if xover_pos % 21 == 14: # check for P1 xover
                                p1neighbor = xover_to_neighbor[helix][1]
                                if p1neighbor != None:
                                    #handle peripheral single-crossover
                                    b = self.path.path_array[p1neighbor][j].base
                                    if curr_token.next_token and not b in "ATCG":
                                        curr_token.next_token.prev_token = None
                                    curr_token.next_token = \
                                    self.staple_tokens[p1neighbor][j]
                                    curr_token.next_token.prev_token = curr_token
                            if xover_pos % 21 == 7: # check for P2 xover
                                p2neighbor = xover_to_neighbor[helix][2]
                                if p2neighbor != None:
                                    #handle peripheral single-crossover
                                    b = self.path.path_array[p2neighbor][j].base
                                    if curr_token.next_token and not b in "ATCG":
                                        curr_token.next_token.prev_token = None
                                    curr_token.next_token = \
                                    self.staple_tokens[p2neighbor][j]
                                    curr_token.next_token.prev_token = curr_token
                                
    def get_continuous_staple_paths(self):
        """Populate self.continuous_staple_path_list. Must be called
            before C{Staples.insert_breakpoints()}. 
        """
        for row_of_tokens in self.staple_tokens:
            for token in row_of_tokens:
                if not token.in_continuous_path:
                    sub_path = [token]
                    token.in_continuous_path = True
                    downstream_done = False
                    curr_token = token
                    while not downstream_done:
                        if not curr_token.next_token:
                            downstream_done = True
                        elif curr_token.next_token.in_continuous_path:
                            downstream_done = True
                        else:
                            curr_token = curr_token.next_token
                            curr_token.in_continuous_path = True
                            sub_path.append(curr_token)
                    upstream_done = False
                    curr_token = token
                    while not upstream_done:
                        if not curr_token.prev_token:
                            upstream_done = True
                        elif curr_token.prev_token.in_continuous_path:
                            upstream_done = True
                        else:
                            curr_token = curr_token.prev_token
                            curr_token.in_continuous_path = True
                            sub_path.insert(0, curr_token)
                    self.continuous_staple_path_list.append(sub_path)
    
    def get_default_breakpoints(self):
        breakpoint = {}
        # here we start out with a blank breakpoint dictionary
        # this might be easily adaptable to fill in extra breakpoints
        # in a pre-existing breakpoint dictionary
        for helix in range(len(self.path.path_array)):
            breakpoint[helix] = []
        # distinguish paths that are circular vs. linear
        paths = self.continuous_staple_path_list
        circular_path_indices = []
        linear_path_indices = []
        for path in paths:
            index = paths.index(path)
            if path[len(path)-1].next_token == path[0]:
                circular_path_indices.append(index)
            else:
                linear_path_indices.append(index)
                
        # get breakpoints for the circular paths        
        for circ_path_index in circular_path_indices:
            path = paths[circ_path_index][:] 
            path = path[3:] + path[:3]

            num_staples_on_path = len(path)/42
            if len(path) % 42 != 0:
                print "Circular path not a multiple of 42 bases long..."
            else:
                for j in range(num_staples_on_path):
                    token = path[j*42]
                    breakpoint[token.helix].append(token.position)
                    
        # get breakpoints for the non-circular paths
        for lin_path_index in linear_path_indices:
            path = paths[lin_path_index][:]
            num_staples_on_path = len(path)/42
            num_additional_bases = len(path) % 42
            
            # get the first location on the path that touches scaffold
            start_index = None
            for i in range(len(path)):
                h = path[i].helix
                p = path[i].position
                if self.path.path_array[h][p].base in "ATCG":
                    start_index = i
                    break
            if start_index == None:
                continue
            else:
                start_token = path[start_index].prev_token
            
            # get the last location on the path that touches scafold
            end_index = None
            for i in range(len(path)):
                h = path[-i].helix
                p = path[-i].position
                if self.path.path_array[h][p].base in "ATCG":
                    end_index = -i
                    break
            end_token = path[end_index]
            for token in [start_token, end_token]:
                breakpoint[token.helix].append(token.position)
                
            # insert the periodic breakpoints where possible
            for j in range(num_staples_on_path):
                put_one_in = False
                if j*42 + 3 < len(path):
                    token = path[j*42 + 3]
                    # don't insert within 2 bases of a staple crossover
                    valid_token = True
                    # check for a crossover downstream
                    nt = token
                    for ni in range(3):
                        if nt.next_token == None:
                            valid_token = False
                            break
                        if nt.next_token.helix != token.helix:
                            valid_token = False
                        nt = nt.next_token            
                    # check for a crossover upstream
                    pt = token
                    for pi in range(3):
                        if pt.prev_token == None:
                            valid_token = False
                            break
                        if pt.prev_token.helix != token.helix:
                            valid_token = False
                        pt = pt.prev_token   
                    if valid_token:
                        breakpoint[token.helix].append(token.position)
                        put_one_in = True
                if j*42 + 3 < len(path) and not put_one_in:
                    token = path[j*42 + 2]
                    # don't insert within 2 bases of a staple crossover
                    valid_token = True
                    # check for a crossover downstream
                    nt = token
                    for ni in range(3):
                        if nt.next_token == None:
                            valid_token = False
                            break
                        if nt.next_token.helix != token.helix:
                            valid_token = False
                        nt = nt.next_token            
                    # check for a crossover upstream
                    pt = token
                    for pi in range(3):
                        if pt.prev_token == None:
                            valid_token = False
                            break
                        if pt.prev_token.helix != token.helix:
                            valid_token = False
                        pt = pt.prev_token   
                    if valid_token:
                        breakpoint[token.helix].append(token.position)
                        put_one_in = True                                          

        all_path_indices = linear_path_indices + circular_path_indices
        for path in paths:
            # handle windowed-out regions
            window_entrance = None
            window_exit = None
            for i in range(len(path)):
                pa = self.path.path_array
                h = path[i].helix
                p = path[i].position
                if i<(len(path) - 1) and pa[h][p].base in "ATCG"\
                    and not pa[path[i + 1].helix][path[i + 1].position].base\
                    in "ATCG":
                    window_entrance = path[i]
                if i<(len(path) - 1) and not pa[h][p].base in "ATCG"\
                    and pa[path[i + 1].helix][path[i + 1].position].base\
                    in "ATCG":
                    window_exit = path[i]
                if window_entrance != None and window_exit != None:
                    breakpoint[window_entrance.helix]\
                        .append(window_entrance.position)
                    breakpoint[window_exit.helix].append(window_exit.position)
            
        # print user-modifiable Python code to generate these breakpoints
        return breakpoint
        
    def get_python_list_function(self, list, list_name, function_name):
        """A utility for automatic generation of Python source code for use 
           in _pickle.py files for specific nanostrcuture designs. Generates
           the source code defining a Python function named C{function_name}, 
           which returns a nested list called C{list_name}, that is identical
           to the argument C{list}.  
        """
        num_helices = len(self.path.path_array)
        num_row_tokens = len(self.path.path_array[0])
        
        function_definition = '''
def %s():''' 
        
        list_declaration = '''
    %s = [[] for i in range(%s)]''' % (list_name, num_helices)
        
        list_line_template ='''
    for i in %s:
        %s[i].extend(%s)'''
        
        # compact the list
        positions_visited = []
        for i in range(num_helices):
            for j in range(num_row_tokens):
                if list[i].count(j):
                    positions_visited.append(j)
        positions_to_helices = {}
        for position in positions_visited:
            positions_to_helices[position] = []
            for helix in range(num_helices):
                if list[helix].count(position):
                    positions_to_helices[position].append(helix)
        helix_sets = []
        for (position, helix_set) in positions_to_helices.items():
            if not helix_sets.count(helix_set):
                helix_sets.append(helix_set)
        helix_sets_to_position_sets = {}
        for helix_set in helix_sets:
            helix_sets_to_position_sets[str(helix_set)] = []
        for helix_set in helix_sets:
            for position in positions_visited:
                if positions_to_helices[position] == helix_set:
                    if not helix_sets_to_position_sets[str(helix_set)]\
                        .count(position):
                        helix_sets_to_position_sets[str(helix_set)]\
                            .append(position)  
        lines = []
        for helix_set in helix_sets:
            in_string = str(helix_set)
            extend_string = str(helix_sets_to_position_sets[str(helix_set)])
            lines.append(list_line_template % (in_string,\
                                               list_name,\
                                               extend_string))
        
        lines_string = ""
        for line in lines:
            lines_string = lines_string + line
        
        return_line = '''
    return %s
    ''' % list_name
        function_string = function_definition % function_name +\
                          list_declaration +\
                          lines_string +\
                          return_line
        return function_string                    
                    
    def get_longform_python_list_function(self, list, list_name, function_name):
        """A utility for automatic generation of Python source code for use 
           in _pickle.py files for specific nanostrcuture designs. Generates
           the source code defining a Python function named C{function_name}, 
           which returns a nested list called C{list_name}, that is identical
           to the argument C{list}.  
        """
        num_helices = len(self.path.path_array)
        num_row_tokens = len(self.path.path_array[0])
        
        function_definition = '''
def %s():''' 
        
        list_declaration = '''
    %s = [[] for i in range(%s)]''' % (list_name, num_helices)
        
        list_line_template ='''
    %s[%s].extend([%s])'''
        
        lines = []
        for i in range(num_helices):
            extend_string = ""
            for j in range(1, num_row_tokens):
                if list[i].count(j):
                    if extend_string != "":
                        extend_string = extend_string + ", " + str(j)
                    else:
                        extend_string = str(j)
            lines.append(list_line_template % (list_name, str(i), extend_string))
        
        lines_string = ""
        for line in lines:
            lines_string = lines_string + line
        
        return_line = '''
    return %s
    ''' % list_name
        function_string = function_definition % function_name +\
                          list_declaration +\
                          lines_string +\
                          return_line
        return function_string
    
    def insert_breakpoints(self):
        """At staple breakpoints, pointers to None are inserted
           within staple paths.
        """
        # insert breakpoints
        for helix in range(len(self.staple_tokens)):
            row = self.staple_tokens[helix]
            for j in range(len(row)):
                 if row[j].next_token and j in self.breakpoint[helix]:
                    
                     row[j].next_token.prev_token = None
                     row[j].next_token = None
        # for helix in range(len(self.staple_tokens)):
        #     for j in range(len(row)):
        #         if j in self.breakpoint[helix]:
        #             print [helix, j]
    
    def process_z_interfaces(self):
        """docstring for process_z_interfaces"""
        interfacelist = self.lattice.LatticeInterfaceList
        for interface in interfacelist:
            # Extend overhang bases
            if interface.extend_seg != None:
                extend_seg = interface.extend_seg
                seq = interface.extend_sequence
                for helix in interface.helix_set:
                    scaf_row = self.path.path_array[helix]
                    first_pos = scaf_row[extend_seg*21].base
                    # might be problematic
                    last_pos = scaf_row[extend_seg*21+20].base
                    if not first_pos in 'ATCG' and last_pos in 'ATCG':
                        # proceed left to right
                        poslist = range(extend_seg*21,(extend_seg+1)*21)
                        pos = self.find_edgepos(scaf_row, poslist)
                        token = self.staple_tokens[helix][pos]
                        # insert breakpoint
                        if helix % 2 == 0:
                            # even helix, break staple 3' end
                            token.next_token.prev_token = None
                            token.next_token = None
                            token.base = token.base + seq
                            # print "3' extension at %d[%d]: %s" % \
                            #   (token.helix,token.position,seq) 
                        else:
                            # odd helix, break staple 5' end
                            token.prev_token.next_token = None
                            token.prev_token = None
                            token.base = seq + token.base
                            # print "5' extension at %d[%d]: %s" % \
                            #   (token.helix,token.position,seq)
                    elif first_pos in 'ATCG' and not last_pos in 'ATCG':
                        # proceed right to left
                        poslist = range(extend_seg*21,(extend_seg+1)*21)[::-1]
                        pos = self.find_edgepos(scaf_row, poslist)
                        token = self.staple_tokens[helix][pos]
                        # insert breakpoint
                        if helix % 2 == 0:
                            # even helix, break staple 5' end
                            token.prev_token.next_token = None
                            token.prev_token = None
                            token.base = seq + token.base
                            # print "5' extension at %d[%d]: %s" % \
                            #   (token.helix,token.position,seq)
                        else:
                            # odd helix, break staple 3' end
                            token.next_token.prev_token = None
                            token.next_token = None
                            token.base = token.base + seq
                            # print "3' extension at %d[%d]: %s" % \
                            #   (token.helix,token.position,seq)
                    else:
                        print helix, extend_seg, first_pos, last_pos
                        raise Exception, "Problem in interface file. " + \
                        "Scaffold bases present in both first and last " + \
                        "base of segment %d" % extend_seg
            elif interface.cap_seg != None: # Cap (2bp overhang)
                path_array = self.path.path_array
                segment = interface.cap_seg
                offset = interface.cap_offset
                exp = re.compile(r"([ATCG]+)([N]+)([ATCG]+)")
                match = exp.match(interface.cap_sequence)
                upseq = match.group(1)
                nseq = match.group(2)
                downseq = match.group(3)
                for helix in interface.helix_set:
                    midseq = ''
                    # get helix with overhang
                    target = eval(str(helix) + interface.cap_offset)
                    scaf_row = self.path.path_array[target]
                    stpl_row = self.staple_tokens[target]
                    first_pos = scaf_row[segment*21].base
                    last_pos = scaf_row[segment*21+20].base
                    # search for scaf edge proceed left to right
                    if not first_pos in 'ATCG' and last_pos in 'ATCG':
                        # figure out position of overhang
                        poslist = range(len(scaf_row)) # L to R
                        cap_start_pos = self.find_edgepos(scaf_row, poslist)
                        cap_token = self.staple_tokens[helix][cap_start_pos]
                        overhang_pos = cap_start_pos - 1 
                        # figure out position of complementary scaffold 
                        poslist2 = range(len(scaf_row))[::-1] # R to L
                        scaf_pos = self.find_edgepos(scaf_row, poslist2)
                        # print helix, target, cap_start_pos, 
                        # print overhang_pos, scaf_pos
                        for i in range(len(nseq)):
                            # fill in scaffold & staple bases
                            scaf_base = scaf_row[scaf_pos].base
                            midseq = midseq + scaf_base
                            stpl_row[overhang_pos].base = \
                                       self._comp(scaf_base)
                            stpl_base = stpl_row[overhang_pos].base
                            # print scaf_pos, scaf_base, 
                            # print overhang_pos, '|%s|' % stpl_base
                            scaf_pos = scaf_pos - 1
                            overhang_pos = overhang_pos - 1
                        cap_seq = upseq+midseq+downseq
                        h = cap_token.helix
                        s = cap_token.position
                        # print "3' cap at %d[%d]: %s" % (h,s,cap_seq)
                        cap_token.base = cap_token.base + cap_seq
                    # search for scaf edge proceed right to left
                    elif first_pos in 'ATCG' and not last_pos in 'ATCG':
                        # figure out position of overhang
                        poslist = range(len(scaf_row))[::-1] # R to L
                        cap_start_pos = self.find_edgepos(scaf_row, poslist)
                        cap_token = self.staple_tokens[helix][cap_start_pos]
                        overhang_pos = cap_start_pos + 1 
                        # figure out position of complementary scaffold 
                        poslist2 = range(len(scaf_row)) # L to R
                        scaf_pos = self.find_edgepos(scaf_row, poslist2)
                        # print helix, target, cap_start_pos, 
                        # print overhang_pos, scaf_pos
                        for i in range(len(nseq)):
                            # fill in scaffold & staple bases
                            scaf_base = scaf_row[scaf_pos].base
                            midseq = midseq + scaf_base
                            stpl_row[overhang_pos].base = \
                                       self._comp(scaf_base)
                            stpl_base = stpl_row[overhang_pos].base
                            # print scaf_pos, scaf_base, 
                            # print overhang_pos, '|%s|' % stpl_base
                            scaf_pos = scaf_pos + 1
                            overhang_pos = overhang_pos + 1
                        cap_seq = upseq+midseq+downseq
                        h = cap_token.helix
                        s = cap_token.position
                        # print "3' cap at %d[%d]: %s" % (h,s,cap_seq)
                        cap_token.base = cap_token.base + cap_seq
                        # replace N's with scaffold bases
                    else:
                        print "here", helix, segment, first_pos, last_pos
                        raise Exception, "Problem in interface file. " + \
                        "Scaffold bases present in both first and last " + \
                        "base of segment %d" % segment
            elif interface.connect: # add Z-connection
                donor = interface.donor_seg
                acceptor = interface.acceptor_seg
                # print "CONNECT %d %d" % (donor, acceptor)
                acceptor_helices = interface.helix_set
                for ahelix in acceptor_helices:
                    # get its row,col position
                    acceptor_row, acceptor_col = \
                     interface.helix_row_col[ahelix]
                    # get donor helix from row_col_to_helix for donor slice
                    dslice = self.lattice.LatticeSliceList[donor]
                    dhelix = \
                     dslice.row_col_to_helix[acceptor_row][acceptor_col]
                    if isinstance(dhelix, int):
                        # does this make sense?
                        scaf_row = self.path.path_array[ahelix]
                        if donor < acceptor: # 3' ends to left -> even helices
                            if dhelix % 2 == 0:
                                dposlist = range(donor*21,(donor+1)*21)
                                dpos = \
                                 self.find_edgepos(scaf_row,dposlist)
                                aposlist = \
                                 range((acceptor+1)*21,(acceptor+2)*21)[::-1]
                                apos = \
                                 self.find_edgepos(scaf_row,aposlist)
                                dtoken = self.staple_tokens[dhelix][dpos]
                                atoken = self.staple_tokens[ahelix][apos]
                                dtoken.next_token.prev_token = None
                                dtoken.next_token = atoken
                                atoken.prev_token.next_token = None
                                atoken.prev_token = dtoken
                        else: # 3' ends to right -> odd helices
                            if dhelix % 2 == 1:
                                dposlist = range((donor+1)*21, \
                                                (donor+1)*21+21)[::-1]
                                dpos = \
                                 self.find_edgepos(scaf_row,dposlist)
                                aposlist = \
                                 range((acceptor)*21,(acceptor+1)*21)
                                apos = \
                                  self.find_edgepos(scaf_row,aposlist)
                                dtoken = self.staple_tokens[dhelix][dpos]
                                atoken = self.staple_tokens[ahelix][apos]
                                dtoken.next_token.prev_token = None
                                dtoken.next_token = atoken
                                atoken.prev_token.next_token = None
                                atoken.prev_token = dtoken
            elif interface.twobase:
                donor = interface.donor_seg
                acceptor = interface.acceptor_seg
                # print "2BASE %d %d" % (donor, acceptor)
                acceptor_helices = interface.helix_set
                for ahelix in acceptor_helices:
                    # get its row,col position
                    acceptor_row, acceptor_col = \
                     interface.helix_row_col[ahelix]
                    # get donor helix from row_col_to_helix for donor slice
                    dslice = self.lattice.LatticeSliceList[donor]
                    dhelix = \
                     dslice.row_col_to_helix[acceptor_row][acceptor_col]
                    # print "dhelix %d, ahelix %d" % (dhelix, ahelix)
                    if isinstance(dhelix, int):
                        # does this make sense?
                        scaf_row = self.path.path_array[ahelix]
                        if donor < acceptor:
                            if dhelix % 2 == 1: # odd helices
                                dposlist = range(donor*21,(donor+1)*21)
                                dpos = \
                                 self.find_edgepos(scaf_row,dposlist)
                                aposlist = \
                                 range((acceptor+1)*21,(acceptor+2)*21)[::-1]
                                apos = \
                                 self.find_edgepos(scaf_row,aposlist)
                                dtoken = \
                                 self.staple_tokens[dhelix][dpos-2].prev_token
                                atoken = \
                                 self.staple_tokens[ahelix][apos-1]
                                dtoken.next_token = atoken
                                atoken.prev_token = dtoken
                                ctoken = self.staple_tokens[dhelix][dpos]
                                atoken.next_token.next_token = ctoken
                                ctoken.prev_token=atoken.next_token.next_token
                                # print "A", dpos,
                                # print dtoken.helix, dtoken.position,\
                                #  dtoken.base,
                                # print apos,
                                # print atoken.helix, atoken.position,\
                                #  atoken.base
                        else:
                            if dhelix % 2 == 0: # even helices
                                dposlist = range((donor+1)*21, \
                                                (donor+1)*21+21)[::-1]
                                dpos = \
                                 self.find_edgepos(scaf_row,dposlist)
                                aposlist = \
                                 range((acceptor)*21,(acceptor+1)*21)
                                apos = \
                                  self.find_edgepos(scaf_row,aposlist)
                                dtoken = \
                                 self.staple_tokens[dhelix][dpos+2].prev_token
                                atoken = \
                                 self.staple_tokens[ahelix][apos+1]
                                dtoken.next_token = atoken
                                atoken.prev_token = dtoken
                                ctoken = self.staple_tokens[dhelix][dpos]
                                atoken.next_token.next_token = ctoken
                                ctoken.prev_token=atoken.next_token.next_token
                                # print "B", dpos,
                                # print dtoken.helix, dtoken.position,\
                                #  dtoken.base,
                                # print apos,
                                # print atoken.helix, atoken.position,\
                                #  atoken.base
            else:
                raise Exception, "Problem in interface file. " + \
                "Interface does not appear to be a CONNECT, CAP, or EXTEND."
    
    def get_default_caps(self):
        caps = {}
        for helix in range(len(self.path.path_array)):
            caps[helix] = []
        return caps
      
    def get_default_connectors(self):
        connectors = {}
        for helix in range(len(self.path.path_array)):
            connectors[helix] = []
        return connectors
      
    def find_edgepos(self, row, poslist):
        """docstring for find_edgepos"""
        for i in poslist:
            if row[i].base in 'ATCG':
                return i
    
    def get_start_pointers(self):
        """This function populates the C{staple_start_pointers} array by
        looping through all C{staple_tokens}.
        """
        # loop through staple_tokens
        # set StapleToken.assigned_path = True for each token visited
        # go all the way to 3' end and stop
        # go all the way to 5' end and add token to staple_start_pointers list
        # 
        # make sure to leave out paths that are upstream and downstream of
        # actual scaffold. One possible rule to eliminate these paths:
        # if staple starts (5') or ends (3') at far left or far right position
        # then its start token can be eliminated from the list of
        # paths to process.  All other paths that spend time unpaired with
        # scaffold either start or end away from the edges.
        for row_of_tokens in self.staple_tokens:
            for token in row_of_tokens:
                if not token.assigned_path:
                    leave_out_this_path = False
                    # Automatically omit paths that touch L and R diagram edge
                    token.assigned_path = True
                    downstream_done = False
                    curr_token = token
                    while not downstream_done:
                        if not curr_token.next_token:
                            downstream_done = True
                            # the right hand edge of the diagram
                            end = len(row_of_tokens) - 1 
                            pos = curr_token.position
                            if pos == 0 or pos == end:
                                leave_out_this_path = True
                        elif curr_token.next_token.assigned_path:
                            downstream_done = True
                        else:
                            curr_token.next_token.assigned_path = True
                            curr_token = curr_token.next_token
                    upstream_done = False
                    curr_token = token
                    while not upstream_done:
                        if not curr_token.prev_token:
                            upstream_done = True
                            # the right hand edge of the diagram
                            end = len(row_of_tokens) - 1 
                            pos = curr_token.position
                            if pos == 0 or pos == end:
                                leave_out_this_path = True
                            if not leave_out_this_path:
                                self.staple_start_pointers.append(curr_token)
                        elif curr_token.prev_token.assigned_path:
                            upstream_done = True
                        else:
                            curr_token.prev_token.assigned_path = True
                            curr_token = curr_token.prev_token
                            
        # remove staples that don't touch scaffold at all
        for start_token in self.staple_start_pointers:
            curr_token = start_token
            all_N = True
            while curr_token.next_token != None:
                h = curr_token.helix
                p = curr_token.position
                if self.path.path_array[h][p].base in "ATCG":
                    all_N = False
                    break
                curr_token = curr_token.next_token
            if all_N:
                # remove the corresponding start token
                index = self.staple_start_pointers.index(start_token)
                s = self.staple_start_pointers
                if index != len(s) - 1:
                    self.staple_start_pointers = s[:index] + s[index + 1:]
                else:
                    self.staple_start_pointers = s[:index]
    
    def populate_staple_array(self):
        """docstring for populate_staple_array"""
        for staple_start_token in self.staple_start_pointers:
            self.staple_array.append(StaplePath(staple_start_token))
    
    def sort_paths(self):
        """docstring for sort_paths"""
        # need to sort paths based on start_staple memberships
        # certain rules will trump others, e.g. a staple that is both
        # core and connector will go in connector group
        # may need to figure out a way to specify precedence.
        # Assign individual tokens
        caps = self.caps
        connectors = self.connectors
        for staple in self.staple_array:
            for token in staple.token_list:
                if caps[token.helix].count(token.position) != 0:
                    token.cap = True
                elif connectors[token.helix].count(token.position) != 0:
                    token.connector = True
                    
        # Assign oligos
        for staple in self.staple_array:
            for token in staple.token_list:
                if token.cap:
                    staple.cap = True
                elif token.connector:
                    staple.connector = True
    
    def modify_paths(self):
        """docstring for modify_paths"""
        # 5' and 3' mods can be added to classes of paths here.
        # some modifications may need to occur before this step; not sure yet
        pass
    
    def output_paths(self):
        """docstring for output_paths"""
        # here we actually write to file the oligo sequences
        # also construct lists of classes of staples that were written
        # (i.e. in what order they were output, and what indices correspond
        # to what class)
        # pass this information off to output pipetting instructions
        outfile = self.file['oligo_file']
        print "Writing oligo output.."
        out = open(outfile, 'w')
        # Output the core
        core_count = 0
        for sp in self.staple_array:
#            print "%s \t\t %d[%d]" % (sp.sequence, \
#                sp.first_token.helix,sp.first_token.position)
#            if sp.sequence == 'GACGGTCGTTTACCAGAAAATCAAAAATCAGCCTTACGAGAATGACCTTCA':
#                print "%d[%d]" % (sp.first_token.helix,sp.first_token.position)
            if len(sp.sequence) < 18:
                print "%d base staple starts at %d[%d]" % (len(sp.sequence), \
                sp.first_token.helix,sp.first_token.position)
            if len(sp.sequence) > 55:
                print "%d base staple starts at %d[%d]" % (len(sp.sequence), \
                sp.first_token.helix,sp.first_token.position)
            if (not sp.cap) and (not sp.connector):
                out.write(sp.sequence + '\n')
                core_count = core_count + 1
        # Output caps
        cap_count = 0
        for sp in self.staple_array:
            if sp.cap and not sp.connector:
                out.write(sp.sequence + '\n') 
                cap_count = cap_count + 1
        # Output the connectors
        conn_count = 0
        for sp in self.staple_array:
            if sp.connector and not sp.cap:
                out.write(sp.sequence + '\n')
                conn_count = conn_count + 1 
        cap_conn_count = 0
        for sp in self.staple_array:
            if sp.connector and sp.cap:
                out.write(sp.sequence + '\n')
                cap_conn_count = cap_conn_count + 1 
        if core_count:
            print "     core: %d" % core_count
        if cap_count:
            print "      cap: %d" % cap_count
        if conn_count:
            print "connector: %d" % conn_count
        if cap_conn_count:
            print " cap&conn: %d" % cap_conn_count
        print "    total: %d"%(core_count+cap_count+conn_count+cap_conn_count)
        print "...done: %s" % outfile
    
    def touch_staple_path(self, start_helix, start_pos, num):
        """docstring for touch_staple_path"""
        done = False
        curr_token = self.staple_tokens[start_helix][start_pos]
        while not done:
            if not curr_token:
                done = True
            elif curr_token.visited:
                print "circular path", curr_token.helix
                done = True
            elif curr_token.base == ' ':
                print "edge-terminal path", start_helix, start_pos
                done = True
            else:
                curr_token.visited = True
                curr_token.rank = num
                num = num + 1
                if num == 91:
                    num = 65
                curr_token = curr_token.next_token
    
    def print_visited_staple_paths(self):
        for i in range(len(self.staple_tokens)):
            row = self.staple_tokens[i]
            # if i % 2 == 0:
            #     row = row[::-1]  # reverse for even strands
            bases = ''
            for j in range(len(row)):
                if row[j].visited:
                    # bases = bases + row[j].base
                    bases = bases + chr(row[j].rank)
                else:
                    bases = bases + '_'
                if (j+1) % 21 == 0:
                    bases = bases + '|'
                elif (j+1) % 7 == 0:
                    bases = bases + '.'
            print "%02d |%s" % (i, bases)
    
    def print_vstrands_plus_staple_tokens(self):
        """Prints vitrual strands and staple array according to position in 
        array, NOT 5'-to-3' base connectivity."""
        path_array = self.path.path_array
        staple_tokens = self.staple_tokens
        print "Bases printed according to array position, " + \
              "NOT 5' to 3' connectivity!"
        print "V = virtual strand, S = staple complement\n"
        for i in range(len(staple_tokens)):
            prow = path_array[i]
            vs = ''
            for j in range(len(prow)):
                vs = vs + prow[j].base
            print "V%02d |%s|" % (i, vs)
            row = staple_tokens[i]
            bases = ''
            for j in range(len(row)):
                bases = bases + row[j].base
            print "S%02d |%s|" % (i, bases)
    
    def print_staple_tokens(self):
        """Assembles and prints staple bases from C{Staples.staple_tokens}.
        Output is 5'-to-3' for all strands."""
        staple_tokens = self.staple_tokens
        path_array = self.path.path_array
        for i in range(len(staple_tokens)):
            row = staple_tokens[i]
            if i % 2 == 0:
                row = row[::-1]  # reverse for even strands
            bases = ''
            for j in range(len(row)):
                bases = bases + row[j].base
            # print "%02d" % i, bases.strip()
            print "%02d |%s|" % (i, bases)
    
    complement = string.maketrans('ACGTacgt','TGCAtgca')
    def _rev(self, s):
        """Reverses a string."""
        return s[::-1]
    def _comp(self, s):
        """Returns reverse complement of a DNA sequence."""
        return self._rev(s.translate(self.complement))
