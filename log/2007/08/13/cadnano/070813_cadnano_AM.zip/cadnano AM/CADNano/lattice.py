"""
The lattice.py module manages several cross-sectional representations of the 
DNA nanostructure.  These repreesntations are derived from the helix lattice 
file input.  The file is meant to be human readable 
and easy to modify with a text editor.

There are three major classes in this module:

    1. C{LatticeSlice} -- handles single-segment cross-sections.

    2. C{Lattice} -- handles the set of C{LatticeSlice} objects that 
    constitute a complete monomeric nanostructure.

    3. C{SuperLattice} -- handles multiple C{Lattice} objects for
    polymerization of different monomers.


File Input
==========

The lattice file (called I{design}_helix_lattice.txt by default) defines all cross-sections of the folded monomer, and is an ASCII representation approximating a honeycomb lattice. For example::

    ...   ...   ...   ...   ...   
       ...   ...   ...   ...   ...

       ...   AAA   AAA   AA0   ...
    ...   AA1   AAA   AAA   ...   

    ...   AA2   AAA   AAA   ...   
       ...   AAA   AAA   AA3   ...

       ...   ...   ...   ...   ...
    ...   ...   ...   ...   ...   


Each double-helix is represented by a unique 3-digit code.  The first
letter always defines the scaffold identity [A-Z,a-z].  By default,
the second and third positions should also match first letter.  However,
those positions can also be integers used to define ordered waypoints 
through which the scaffold passes as it traverses the structure.

Note that when describing the nanostructure in three dimensions, the
left-to-right direction in the lattice file is the "x direction",
the top-to-bottom direction is the "y direction", and the view into
the screen is the z direction.

The lattice file also has "parity" constraints for where even and odd
helices can be positioned.  The parity of any position is defined as
its row number plus its column number (using zero-based indexing).  
Note that the following is a single row, which takes up 2 separate 
lines in the ASCII file::

    ...   ...   ...   ...   ...   
       ...   ...   ...   ...   ...

The row above has 10 columns. Even-numbered helices must occupy 
even-parity lattice positions, and odd-numbered helices must occupy
odd-parity lattice positions.


Processing Overview
===================

The entry point into the lattice module is the C{Lattice} class.  A 
C{Lattice} object is instantiated by passing the the file dictionary 
containing the helix_lattice.txt location under the key C{helix_lattice_file}.

The file is parsed into sub-groups of lines containing slices by the
C{Lattice.__init__} function, and those groups of lines are passed as
an argument to instantiate C{LatticeSlice} objects.

When each C{LatticeSlice} object is created, it is added to the C{Lattice} 
object.  This continues until all cross-sectional sections have been parsed 
and stored as C{LatticeSlice} objects.


Output & Debugging
==================
C{Lattice.printASCII} is available for outputting an ASCII representation
of helices that have been stored in C{LatticeSlice} objects.


@todo: write a function that will convert the general lattice file input 
with waypoints into an explicitly ordered representation (Adam)

@todo: decide how to handle multiple C{Lattice} objects for polymerizing
structures. Should they be read in one at a time from separate files?
Should we have an option to just read in one C{Lattice}, and then make a 
copy of it and polymerize that?

@todo: write a C{LatticeSlice} function to parse the helix_lattice_array into 
a dictionary of P0, P1, P2 neighbors for each helix to facilitate lookups.

"""
import re
import sys
from exceptions import ParityError, LengthError
from file import get_lines
from sets import Set

class LatticeSlice():
    """
    C{LatticeSlice} objects store single-segment cross-sections of the 
    Lattice.  As the lattice file gets processed, it is chopped up into
    sections that represent individual segments, e.g.::
    
        # 0
           ...   AAA   AAA   AA0   ...
        ...   AA1   AAA   AAA   ...   
    
        ...   AA2   AAA   AAA   ...   
           ...   AAA   AAA   AA3   ...
    
    
    A string containing this representation is passed to this class as input.
    The resulting object will store the following:
    
    segment::
        0
    helix_lattice_arrray::
        [[None, None, None, None, None, None, None, None, None, None],
         [None, None,    5,    4,    3,    2,    1,    0, None, None],
         [None, None,    6,    7,    8,    9,   10,   11, None, None],
         [None, None, None, None, None, None, None, None, None, None]]
    
    Note that buffer rows containing no helices are added before and after
    the populated rows.  This makes downstream processing simpler when
    querying neighboring positions of specific helices.
    """

    def __init__(self, input_lines):
        """@todo: validate segment section of input before parsing."""
        self.segment = int(input_lines[0].split()[1])
        """@ivar: segment number of this instance
           @type: C{int}
        """
        self.helix_lattice_array = None
        """@ivar: list of lists containing array representation of lattice.
           @type: C{list}
        """
        self.helix_set = []
        """@ivar: C{helix_set} contains the set of all helices in this slice.
           @type: C{list}
        """
        self.xover_to_neighbor = {}
        """@ivar: C{xover_to_neighbor} given helix and position, return 
           neighbor helix, if any.
           @type: C{dictionary}
        """
        self.neighbor_to_xover = {}
        """@ivar: C{neighbor_to_xover} given helix and neighbor, return
           crossover position: 0, 1, or 2.
           @type: C{dictionary}
        """
        self.row_col_to_helix = {}
        """@ivar: Given helix_lattice_array row and column, return helix
           number at that position.
           @type: C{dictionary}
        """
        
        try:
            hla = self._parse_slice(input_lines[1:])
            self.helix_lattice_array = hla
        except ParityError, e:
            h = ','.join([str(h) for h in e.helices])
            print "Parity error for helices: %s" % h
            print "found in segment", self.segment
            sys.exit(1)
        except LengthError, e:
            r = ','.join([str(r) for r in e.rows])
            print "Line length error in row(s)", r,
            print "found in segment", self.segment
            sys.exit(1)
        
        # Offset positions of P0, P1, P2 neighbors
        evenpos = [[0, 1], [0, -1], [-1, 0]]
        oddpos = [[0, -1], [0, 1], [1, 0]]
        
        # Index all neighbors in the newly-constructed helix_lattice_array
        for i in range(1,len(hla)-1):
            coldict = {} # for row_col_to_helix
            for j in range(len(hla[i])):
                posdict = {} # for xover_to_neighbor
                helix = hla[i][j]
                coldict[j] = helix
                # print helix, i, j, coldict
                if isinstance(helix, int):
                    if helix % 2 == 0:
                        posdict[0] = hla[i+evenpos[0][0]][j+evenpos[0][1]]
                        posdict[1] = hla[i+evenpos[1][0]][j+evenpos[1][1]]
                        posdict[2] = hla[i+evenpos[2][0]][j+evenpos[2][1]]
                    else:
                        posdict[0] = hla[i+oddpos[0][0]][j+oddpos[0][1]]
                        posdict[1] = hla[i+oddpos[1][0]][j+oddpos[1][1]]
                        posdict[2] = hla[i+oddpos[2][0]][j+oddpos[2][1]]
                    self.xover_to_neighbor[helix] = posdict
            self.row_col_to_helix[i] = coldict
        self.helix_set = list(Set(self.xover_to_neighbor.keys()))
        
        for helix in self.xover_to_neighbor.keys():
            self.neighbor_to_xover[helix] = \
            _swap_dict(self.xover_to_neighbor[helix])
    
    def _parse_slice(self, lines):
        """Parse input into a list representation of the lattice slice."""
        row_ra = lines
        length_violations = [] # Check that lines are equal length
        length = len(row_ra[0])
        for row in row_ra:
            if len(row) != length and len(row) != 0:
                length_violations.append(row_ra.index(row))
        
        # Parse into pre helix array
        pre_helix_lattice_ra = []
        for row in row_ra:
            num_helices = len(row) / 3
            sub_pre_helix_lattice_ra = []
            for row_helix_num in range(num_helices):
                sub_pre_helix_lattice_ra.append(row[row_helix_num*3: \
                                            row_helix_num*3 + 3])
            if sub_pre_helix_lattice_ra != []:
                pre_helix_lattice_ra.append(sub_pre_helix_lattice_ra)
        
        # Parse pre helix array into helix array
        num_rows = len(pre_helix_lattice_ra)/2
        num_helices = len(pre_helix_lattice_ra[0])
        
        helix_lattice_ra = [[None for row_helix_num in range(num_helices + 
                                                    num_helices % 2 + 2)]]
        exp = re.compile(r"(\d+)")
        for row_num in range(num_rows):
            sub_helix_lattice_ra = [None]
            for row_helix_num in range(num_helices):
                pre_helix_string = pre_helix_lattice_ra[row_num*2 + \
                        (row_helix_num + row_num) % 2][row_helix_num]
                if pre_helix_string == '...':
                    helix = None
                else:
                    # match = exp.match(pre_helix_string[1:])
                    match = exp.search(pre_helix_string)
                    if match:
                        helix = int(match.group(0))
                    # helix = int(pre_helix_string[1:])
                sub_helix_lattice_ra.append(helix)
            sub_helix_lattice_ra.append(None)
            if num_helices % 2 == 1:
                sub_helix_lattice_ra.append(None)
            helix_lattice_ra.append(sub_helix_lattice_ra)
        
        helix_lattice_ra.append([None for row_helix_num in \
                         range(num_helices + num_helices % 2 + 2)])
        
        # Check for parity violations
        parity_violation_helices = []
        for row_num in range(num_rows):
            for row_helix_num in range(num_helices):
                helix = helix_lattice_ra[row_num][row_helix_num]
                if helix != None:
                    if (helix + row_num + row_helix_num) % 2 == 1:
                        parity_violation_helices.append(helix)
        if len(length_violations):
            raise LengthError, length_violations
        if len(parity_violation_helices):
            raise ParityError, parity_violation_helices
        else:
            return helix_lattice_ra

class LatticeInterface(LatticeSlice):
    """docstring for LatticeInterface"""
    def __init__(self, input_lines):
        """@todo: validate segment section of input before parsing."""
        self.donor_seg = None
        """@ivar: The segment from which the 3' overhang is donated at the
           interface.
           @type: C{int}
        """
        self.acceptor_seg = None
        """@ivar: The segment to which the 3' overhang is accepted at the
           interface.
           @type: C{int}
        """
        self.helix_row_col = {}
        """@ivar: Stores the row and column of a helix.
           @type: C{dictionary}
        """
        self.extend_seg = None
        """@ivar: The segment to which 5' and 3' overhangs are added
           @type: C{int}
        """
        self.extend_sequence = ''
        """@ivar: Stores the DNA sequence of the overhang.
           @type: C{string}
        """
        self.cap_seg = None
        """@ivar: The segment to which 5' and 3' caps are added
           @type: C{int}
        """
        self.cap_offset = None
        """@ivar: The helix number offset where the cap reconnects to
           unpaired bases.
           @type: C{int}
        """
        self.cap_sequence = ''
        """@ivar: Stores the DNA sequence of the cap, with N's as
           placeholders.
           @type: C{string}
        """

        self.connect = False
        """@ivar: Stores True if this is a CONNECT interface.
           @type: C{boolean}
        """
        
        self.twobase = False
        """@ivar: Stores True if this is a internal 2-base overhang interface.
           @type: C{boolean}
        """
        
        if len(input_lines) == 0:
            print "Empty interface file."
            return
        
        # connector
        conn_exp = re.compile(r"(# CONNECT) (\d+)(:)(\d+)")
        conn_match = conn_exp.match(input_lines[0])
        extend_exp = re.compile(r"(# EXTEND) (\d+)(:)(\w+)")
        extend_match = extend_exp.match(input_lines[0])
        cap_exp = re.compile(r"(# CAP) (\d+)(:) ([+-]\d+) (\w+)")
        cap_match = cap_exp.match(input_lines[0])
        twobase_exp = re.compile(r"(# 2BASE) (\d+)(:)(\d+)")
        twobase_match = twobase_exp.match(input_lines[0])
        
        # sticky end connector
        if conn_match:
            self.connect = True
            self.donor_seg = int(conn_match.group(2))
            self.acceptor_seg = int(conn_match.group(4))
        # extension
        elif extend_match:
            self.extend_seg = int(extend_match.group(2))
            self.extend_sequence = extend_match.group(4)
        # cap: # CAP 0: +1 ATGAAATNNA
        elif cap_match:
            self.cap_seg = int(cap_match.group(2))
            self.cap_offset = cap_match.group(4)
            self.cap_sequence = cap_match.group(5)
        # 2base internal overhang connector
        elif twobase_match:
            self.twobase = True
            self.donor_seg = int(twobase_match.group(2))
            self.acceptor_seg = int(twobase_match.group(4))
        else:
            "Problem in interface file", input_lines[0]
            sys.exit(1)
            
        try:
            self.helix_lattice_array = self._parse_slice(input_lines[1:])
        except ParityError, e:
            h = ','.join([str(h) for h in e.helices])
            print "Parity error for helices: %s" % h
            print "found in segment", self.segment
            sys.exit(1)
        except LengthError, e:
            r = ','.join([str(r) for r in e.rows])
            print "Line length error in row(s)", r,
            print "found in segment", self.segment
            sys.exit(1)
        
        # Index all helices in the newly-constructed interface lattice
        hset = Set()
        for i in range(1,len(self.helix_lattice_array)-1):
            for j in range(len(self.helix_lattice_array[i])):
                helix = self.helix_lattice_array[i][j]
                if isinstance(helix, int):
                    hset.add(helix)
        self.helix_set = list(hset)
        self.helix_set.sort()
        
        # Store helix positions
        for i in range(1,len(self.helix_lattice_array)-1):
            for j in range(len(self.helix_lattice_array[i])):
                posdict = {}
                helix = self.helix_lattice_array[i][j]
                self.helix_row_col[helix] = [i, j]

class Lattice():
    """
    C{Lattice} objects are constructed by parsing a helix lattice file
    into slices (i.e. lists of lines from the file), and using each slice 
    to instantiate C{LatticeSlice} objects.
    
    The boundaries of a lattice slice are delineated by a line containing 
    a hash symbol (#) and segment number.
    
    Example file input::
    
        # 0
           ...   AAA   AAA   AA0   ...
        ...   AA1   AAA   AAA   ...   
    
        ...   AA2   AAA   AAA   ...   
           ...   AAA   AAA   AA3   ...
        # 1
           ...   AAA   AAA   AA0   ...
        ...   AA1   AAA   AAA   ...   
    
        ...   AA2   AAA   AAA   ...   
           ...   AAA   AAA   AA3   ...
    
    Instantiating a C{Lattice} with this example content in the file input
    will result in the C{LatticeSliceList} variable containing a list of
    C{LatticeSlice} objects.
    """
    def __init__(self, config):
        self.LatticeSliceList = []
        """@ivar: C{LatticeSlice} objects that comprise a complete monomer
           lattice.
           @type: C{list}
        """
        self.LatticeInterfaceList = []
        """@ivar: C{LatticeInterface} objects that define self z-connections.
           @type: C{list}
        """
        self.seg_helix_neighbor = {}
        """@ivar: C{seg_helix_neighbor[segment][helix][position]} gives the
            identity of the neighboring helix at position P0, P1, or P2.
           @type: C{dictonary}
        """
        self.all_helices = [] 
        """@ivar: C{all_helices} contains the set of all helices found across
           all C{LatticeSlice} objects.
           @type: C{list}
        """
        self.slice_count = 0
        """@ivar: C{slice_count} is the total number of C{LatticeSlice}
           objects in the C{Lattice} object.
           @type: C{int}
        """
        self.file_dict = config['file']
        """@ivar: Internal pointer to file_dict
           @type: C{dictionary}
        """
        self.read_slices_from_helix_lattice_file()
        self.read_interfaces()
        
        # Collect meta info
        helix_set = Set()
        for slice in self.LatticeSliceList:
            helix_set.update(slice.helix_set)
        self.all_helices = list(helix_set)
        self.slice_count = len(self.LatticeSliceList)

    
    def read_slices_from_helix_lattice_file(self):
        """Break helix lattice file into slices, and then instantiate
        and store C{LatticeSlice} objects for each of those.
        """
        input_file = self.file_dict['helix_lattice_file']
        lines = get_lines(input_file)
        
        # Parse through file to construct LatticeSlices
        line_group = []
        for line in lines:
            # print "in Lattice.__init__: line '%s'" % line
            # print line, line_group
            if line == '':
                pass
            elif line[0] == '#':
                if line_group:
                    new_ls = LatticeSlice(line_group)
                    self.LatticeSliceList.append(new_ls)
                    line_group = [line]
                else:
                    line_group.append(line)
            else:
                line_group.append(line)
        # Throw away the '#' lines
        self.LatticeSliceList.append(LatticeSlice(line_group))
    
    def read_interfaces(self):
        """docstring for C{read_interfaces}"""
        input_file = self.file_dict['zinterface_file']
        lines = get_lines(input_file)
        line_group = []
        interfaces = []
        for line in lines:
            if line == '':
                pass
            elif line[0] == '#':
                if line_group:
                    interfaces.append(line_group)
                    line_group = [line]
                else:
                    line_group.append(line)
            else:
                line_group.append(line)
        interfaces.append(line_group)
        for intgroup in interfaces:
            self.LatticeInterfaceList.append(LatticeInterface(intgroup))
    
    def printSliceASCII(self):
        """docstring for printSliceASCII"""
        self._printASCII(self.LatticeSliceList)
    
    def printInterfaceASCII(self):
        """docstring for printInterfaceASCII"""
        self._printASCII(self.LatticeInterfaceList)
    
    def _printASCII(self, latticelist, seglist=[]):
        """
        Output ASCII representation of lattice.  Optionally include a
        list of segments to have only those printed.
        """
        for ls in latticelist:
            hla = ls.helix_lattice_array
            
            # print ls.xover_to_neighbor
            
            # if seglist is empty, print for all segments
            if seglist == []:
                pass
            elif not segment in seglist:
                continue
            
            if ls.segment != None:
                print "# %d" % ls.segment
            elif ls.donor_seg != None:
                print "# %d:%d" % (ls.donor_seg, ls.acceptor_seg)
            
            for y in range(1,len(hla)-1):
                even_row_string = ''
                odd_row_string = '   '
                for x in range(len(hla[0])):
                    element = hla[y][x]
                    if isinstance(element, int):
                        element = "%03d" % (element)
                    else:
                        element = '...'
                    if x % 2 == 0:
                        even_row_string += element + '   '
                    else:
                        odd_row_string += element + '   '
                if y % 2 == 0:
                    print even_row_string
                    print odd_row_string
                else:
                    print odd_row_string
                    print even_row_string
                print ''
            print '\n'

"""Swap key and value pairs, eliminating pairs where the value is C{None}."""
def _swap_dict(d):
    new = {}
    for key, value in d.items():
        if value == None:
            continue
        else:
            new[value] = key
    return new
