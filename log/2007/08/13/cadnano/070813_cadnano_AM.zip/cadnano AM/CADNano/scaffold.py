"""Generates an internal representation of the scaffold ("virtual strands"), based on lattice and path inputs.

@todo: write documentation

@todo: write routine to determine circular permutation of scaffold that
places hairpins ('GGCGGGTGTGGTGGTTACGCGCAGCGTGACCGCTACACTTGCC', 'GGGTGATGGTTCACGTAGTGGGCCATCGCCC') away from crossovers.

@todo: might make sense to create a scaffold object similar to the path_array
with single-base resolution.
"""
from sequences import Sequences

class Scaffold:
    """Converts C{Path} and sequence into virtual strands"""
    hairpins = ['GGCGGGTGTGGTGGTTACGCGCAGCGTGACCGCTACACTTGCC', \
                'GGGTGATGGTTCACGTAGTGGGCCATCGCCC']
    def __init__(self, path, seq):
        self.path = path
        """@ivar: Internal pointer to C{Path} object.
           @type: C{Path}
        """
        self.sequence = seq
        """@ivar: Full scaffold DNA sequence.
           @type: C{string}
        """
        self.virtual_strands = []
        """@ivar: Array of strings, where index corresponds to helix number.
           @type: C{list}
        """
        self._populate()
        # self._mark_hairpins()
    
    def _populate(self):
        """
        Assigns scaffold sequence to C{PathToken} objects in the
        path_array.  Starting at path.first_token, C{_populate} traverses
        through the path_array via next_token pointers. Each C{PathToken}
        is marked as visited, and the loop terminates once a previously
        visited token is encountered.
        Note: The population of multiple scaffold paths here is only for the
        purpose of generatating default staple paths before the user has 
        connected the various domains of a *monomer* nanostructure into 
        a single scaffold path. This is *not* support for multiple separate
        physical scaffolds. For this reason, the staple oligonucleotide sequences 
        should *not* be interpreted as correct unless there is a single, continuous 
        scaffold path.
        """
        path_array = self.path.path_array
        seq = self.sequence
        
        for path in self.path.scaffold_path_list:
            curr_token = path[0]
            done = False
            while not done:
                length = curr_token.length
                curr_token.base = seq[:length]
                seq = seq[length:]
                curr_token.visited = True
                curr_token = curr_token.next_token
                done = curr_token.visited
    
    def _mark_hairpins(self):
        """docstring for _mark_hairpins"""
        for hairpin in self.hairpins:
            if hairpin == None:
                return
            start_pos = self.sequence.index(hairpin)
            curr_token = self.path.first_token
            for i in range(start_pos):
                curr_token = curr_token.next_token
            for i in range(len(hairpin)):
                curr_token.hairpin = True
                curr_token = curr_token.next_token
    
    def print_vstrands(self):
        """Assembles and prints virtual strands from C{Path.path_array}."""
        path_array = self.path.path_array
        for i in range(len(path_array)):
            row = path_array[i]
##            if i % 2 == 1:
##                row = row[::-1]  # reverse for odd strands
            vs = ''
            for j in range(len(row)):
                vs = vs + row[j].base
            print "%02d" % i, vs.strip()
    
    def print_hairpins(self):
        """Assembles and prints virtual strands from C{Path.path_array}. 
        Sequence is output only if the scaffold is part of a hairpin."""
        path_array = self.path.path_array
        for i in range(len(path_array)):
            row = path_array[i]
            # if i % 2 == 1:
            #     row = row[::-1]  # reverse for odd strands
            vs = ''
            for j in range(len(row)):
                if j % 21 == 0:
                    vs = vs + '|'
                if row[j].hairpin:
                    vs = vs + row[j].base
                else:
                    vs = vs + ' '
            print "%02d%s|" % (i, vs)

