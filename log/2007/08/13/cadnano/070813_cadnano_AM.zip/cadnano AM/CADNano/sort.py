"""Includes functions for sorting of staples."""

class Sort(object):
    """docstring for Sort"""
    staples = None
    """@ivar: Internal pointer to C{Staples} object.
       @type: C{Scaffold}
    """
    def __init__(self, staples):
        self.staples = staples
        self.read_sorting_rules()
        self.classify_staple_paths()
        self.write_sorted_staples()
        self.write_pipetting_instructions()
    
    def classify_staple_paths(self):
        """C{classify_staple_paths} traverses each staple path starting
        from the 5' pointers found in C{staple_start_pointers}.  Based on
        user-defined positions, a path
        """
        
        #This is just to illustrate the framework...
        #We classify staples as to whether they spend the majority of
        #their time on helices in the top ply or helices in the bottom ply...
        top_ply = MajorityHelixSetRule(range(30))
        top_ply.rule_name = "TOP PLY"
        bottom_ply = MajorityHelixSetRule(range(30,60))
        bottom_ply.rule_name = "BOTTOM PLY"
        
        rules = [top_ply, bottom_ply]
        
        for staple in self.staple_array:
            for rule in rules:
                if rule.satisfies(staple):
                    staple.add_rule_satisfied(rule)
        

class StapleTokenRule:
    """An abstract class that defines an interface for classifiers of
       staple tokens. Derived classes should be created to represent specific
       modes of classification. 
       Interface definition: ALL METHODS AND FIELDS IN 
       THIS CLASS SHOULD BE OVERWRITTEN IN ITS DESCENDENTS. 
    """
    rule_name = ""
    def __init__(self):
        pass
    def satisfies(self, staple_token):
        """Returns a C{boolean} indicating whether or not 
           staple_token satisfies this staple token classification rule.
        """
        pass
        
class HelixListRule(StapleTokenRule):
    """This rule is satisfied only by tokens on specific helices.
    """
    helix_list = []
    rule_name = "Helix List Rule"
    def __init__(self, helix_list):
        self.helix_list = helix_list
    def satisfies(self, staple_token):
        if self.helix_list.count(staple_token.helix):
            return True
        else:
            return False
            
class SegmentListRule(StapleTokenRule):
    """This rule is satisfied only by tokens on specific segments.
    """
    segment_list = []
    
    def __init__(self, segment_list):
        self.segment_list = segment_list
        self.rule_name = "Segment List Rule"
    def satisfies(self, staple_token):
        if self.segment_list.count(staple_token.segment):
            return True
        else:
            return False
            
class PositionListRule(StapleTokenRule):
    """This rule is satisfied only by tokens at certain base positions.
    """
       
    def __init__(self, position_list):
        self.position_list = position_list
        self.rule_name = "Position List Rule"

    def satisfies(self, staple_token):
        if self.position_list.count(staple_token.position):
            return True
        else:
            return False
            
class StapleRule:
    """An abstract class that defines an interface for classifiers
       of staples. Derived classes should be created to represent 
       specific modes of classification. 
       Interface definition: ALL METHODS AND FIELDS IN 
       THIS CLASS SHOULD BE OVERWRITTEN IN ITS DESCENDENTS.
    """
    rule_name = ""
    def __init__(self):
        pass
    def satisfies(self, staple):
        """Returns a C{boolean} indicating whether or not
           the staple satisfies this
           staple classification rule.
        """
        pass

class CoreRule(StapleRule):
    pass

class ConnectorRule(StapleRule):
    pass

class MajorityHelixSetRule(StapleRule):
    """PrimaryHelixRule(j) tests if a staple spends most of its time
       among the helices in a user-specified list. 
    """
    group_rules = None
    
    group_counts = None
    
    def init(self, helix_list, total_num_helices):
        rule = HelixListRule(helix_list)
        complement = [a for a in range(total_num_helices) if not helix_list.count(a)]
        self.helix_rules = [rule, complement]
        self.group_counts = [0,0]
    def satisfies(self, staple):
        for token in staple.token_path:
            for i in [0,1]:
                if group_rules[i].satisfies(token):
                    group_counts[i] = group_counts[i] + 1
        return (group_counts[0] >= group_counts[1])