"""
Collection of modules for generating DNA nanostructures.

Inputs
======
    1. Helix lattice file
    2. Scaffold domain file (optional, default will be generated)
    3. Scaffold path file (optional, default will be generated)
    4. Interface files (used for polymerization)
    5. Paramaters file (used for design-specific paramters)

Outputs
=======
    0. Inputs 2-4, if necessary.
    1. SVG diagram
    2. X3D model (not implemented)
    3. Oligo file
    4. Pipetting instructions

Config Files
============
A configuration file (named C{cadnano.config}) is read from the current 
directory and used to determine file paths and parameters at several steps 
of the program execution.  Example config file::

    [files]
    design: xtps_c2
    dir: designs/%(design)s
    prefix: %(dir)s/%(design)s
    parameters_file: %(prefix)s_parameters.txt
    xover_pickle_file: %(prefix)s_xovers.p
    pre_helix_lattice_file: %(prefix)s_pre_helix_lattice.txt
    helix_lattice_file: %(prefix)s_helix_lattice.txt
    domain_file: %(prefix)s_domain.txt
    scaffold_path_file: %(prefix)s_scaffold_path.txt
    zinterface_file: %(prefix)s_zinterface-1.txt
    svg_output_file: %(prefix)s_svg_output.svg
    x3d_file: %(prefix)s_scaffold_model.x3d

    [epydoc]
    name: CADNano
    modules: run.py, CADNano
    output: html
    target: apidocs/
    graph: all
    dotpath: /usr/local/graphviz-2.12/bin/dot

    [svg]
    output_svg: True
    draw_grid_squares: False
    draw_scaffold: True
    draw_staples: True
    draw_guide_marks: True
    draw_text_labels:True

Main classes
============
    1. C{Lattice}: Cross-sectional representation of a monomeric structure.

    2. C{Domain}: Helix and segment boundaries of domains.

    3. C{Path}: Precise layout of scaffold path (crossover positions, etc.).

    4. C{Scaffold}: Virtual strand representation, derived from C{Path}.

    5. C{Staples}: Oligonucleotides


Outline of runtime execution
============================
    1. Read in a pre- helix lattice file and output a helix lattice file.

    2. Read in helix lattice file input and parse into C{Lattice} object(s).

    3. Generate a C{Domain} object for each C{Lattice} object.

    4. Generate a C{Path} object for each C{Lattice}/C{Domain} pair.

    5. Generate a C{Scaffold} object for each C{Path} object.

    6. Generate a C{Staples} object based on all C{Scaffold} objects.

"""

from domain import Domain
from exceptions import ParityError, LengthError
from file import read_config, get_lines
from lattice import Lattice
from path import Path
from scaffold import Scaffold
from sequences import Sequences
from staples import Staples
from svg import SVG, SvgReader, BreakpointReader
