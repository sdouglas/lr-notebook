"""Common location for all exceptions."""

class ParityError(Exception):
    """Raised for parity violations in lattice input.
    
    Attributes:
    helices -- list of helices that are causing violations
    """
    def __init__(self, helices):
        self.helices = helices

class LengthError(Exception):
    """Raised when lattice input file has lines of unequal length.
    
    Attributes:
    rows -- line numbers for each length violation
    """
    def __init__(self, rows):
        self.rows = rows
