"""The svg.py modules generates graphical representations of the scaffold
and staple paths in the form of a Scalable Vector Graphics (SVG) file.
@todo: rewrite to incorporate tokens that know their own positions, etc.
"""

import sys
from xml.sax import ContentHandler
from xml.sax import make_parser
from xml.sax.handler import feature_namespaces

even_scaf_xover_positions = [2-1,2+3-1,2+3+4-1,2+3+4+3-1,2+3+4+3+4-1,2+3+4+3+4+3-1]
odd_scaf_xover_positions = [2,2+3,2+3+4,2+3+4+3,2+3+4+3+4,2+3+4+3+4+3]
scaf_xover_positions = even_scaf_xover_positions + odd_scaf_xover_positions

# SVG string templates go here
scaffold_path_group_template = '''
    <g id="Scaffold Path" stroke-width="2" fill="none">
        %s
    </g>'''

staple_path_template = '''
    <g id = "Staple Paths" stroke-width="1" fill="none">
        %s
    </g>'''

breakpoints_template = '''
    <g id = "Breakpoints">
        %s
    </g>
'''

staple_crossover_markers_template = '''



'''

# Note: each <g> tags creates a nested group in the svg.
svg_output_template = '''
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" baseProfile="full">
<g id="%s" transform="translate(44.5,38.5) scale(9) ">
%s
</g>
</svg>'''

class SVG():
    """docstring for C{SVG}"""
    
    scaffold_domain_color_set = []
    
    # STAPLE COLOR SET:
    # blue
    # green
    # orange
    # turquoise
    # red
    # purple
    # brown
    # blue
    # green
    staple_color_set = ["#0068B3",\
                        "#2FAB04",\
                        "#F7931E",\
                        "#03B6A2",\
                        "#F74308",\
                        "#7300DE",\
                        "#C36A02",\
                        "#1700DE",\
                        "#459200"]
    # until we find another good one
    scaffold_color_set = staple_color_set
    
    def __init__(self, config, path, domain, staples):
        self.design_name = config['file']['design']
        """@ivar: Name of design, used for SVG group ids.
           @type: C{string}
        """
        self.svg_output_file = config['file']['svg_output_file']
        """@ivar: Location of the svg output file.
           @type: C{string}
        """
        self.svg_params = config['svg']
        """@ivar: Dictionary containing parameters for svg output.
           Parameters are set under the [svg] heading in the file 
           C{nanocad.config}. Call the method C{Svg_Output.get_svg_params()} 
           to print a list of supported parameters.
           @type: C{dictionary}
        """
        self.path = path
        """@ivar: Internal pointer to C{Path} object.
           @type: C{Path}
        """
        self.domain = domain
        """@ivar: Internal pointer to C{Domain} object.
           @type: C{Path}
        """    
        self.staples = staples
        """@ivar: Internal pointer to C{Staples} object.
           @type: C{Path}
        """
    
    # SCAFFOLD
    
    def get_first_token_horiz_position(self, helix):
        """docstring for C{get_first_token_horiz_position}"""
        for i in range(len(self.path.path_array[helix])):
            if self.path.path_array[helix][i] != None:
                return i
        # if the whole strand consists of null tokens (shouldn't happen)
        return len(self.path_path_array[helix]) - 1
    
    def get_max_horizontal_scaf_extent(self):
        """docstring for C{get_max_horizontal_scaf_extent}"""
        max_extent = 0
        for i in self.path.path_array:
            extent = len(i) + self.get_first_token_horiz_position(i[0].helix)
            if extent > max_extent:
                max_extent = extent
        return max_extent
    
    def get_helix_height(self, helix):
        """docstring for C{get_helix_height}"""
        # get the helix height on the diagram
        y_coord = 2
        for pre_helix in range(helix):
            if pre_helix%2 == 0:
                y_coord = y_coord + 8
            else:
                y_coord = y_coord + 4
        return y_coord
    
    def get_token_offset(self, path_token):
        """docstring for C{get_token_offset}
        """
        helix = path_token.helix
        segment = path_token.segment
        offset = "?"
        for ofs in range(21):
            if self.path.path_array[helix][21*segment + ofs] == path_token:
                offset = ofs
        return offset
    
    def token_coords(self, path_token):
        spacing = 2.0/9.0
        """docstring for C{token_coords}"""
        helix = path_token.helix
        segment = path_token.segment
        offset = self.get_token_offset(path_token)
        # go to the beginning of this token's segment
        x_coord = 21 * segment + offset
        if scaf_xover_positions.count(offset) != 0:
            # create initial blank space for crossover
            if even_scaf_xover_positions.count(offset):
                x_coord = x_coord + 1 - spacing
            if odd_scaf_xover_positions.count(offset):
                x_coord = x_coord + spacing
        # initial y-displacement
        y_coord = 2
        for helix_num in range(helix):
            if helix_num % 2 == 0:
                y_coord = y_coord + 8
            else:
                y_coord = y_coord + 4
        return (x_coord, y_coord)
    
    def cont_scaf_crossover_template(self, path_token):
        """docstring for C{cont_scaf_crossover_template}
        """
        donor = path_token
        acceptor = donor.next_token
        if acceptor:
            start_x_coord = self.token_coords(donor)[0]
            start_y_coord = self.token_coords(donor)[1]
            end_x_coord = self.token_coords(acceptor)[0]
            end_y_coord = self.token_coords(acceptor)[1]
            # if there is a crossover
            if donor.helix != acceptor.helix: # make a quadratic bezier spline
                # determine if it is a left or right crossover
                if donor.helix % 2 == 0:
                    control_x = start_x_coord - \
                                0.01 * abs(end_y_coord - start_y_coord)
                    control_y = (start_y_coord + end_y_coord) / 2
                else:
                    control_x = start_x_coord + \
                                0.01 * abs(end_y_coord - start_y_coord)
                    control_y = (start_y_coord + end_y_coord) / 2
                spline_template = '''L %s %s Q %s,%s %s,%s'''\
                                    % (str(start_x_coord), \
                                       str(start_y_coord), \
                                       str(control_x), \
                                       str(control_y), \
                                       str(end_x_coord), \
                                       str(end_y_coord))
                return spline_template
            else: # if there is no crossover
                return ""
        else:
            return ""
            
    def draw_scaffold_paths(self):
        all_scaffolds_string = ""
        color_index = 0
        for path in self.path.scaffold_path_list:
            start_token = path[0]
            # if we start at a crossover, rotate the path
            if start_token.next_token.helix != start_token.helix:
                path = path[1:] + path[:1]
                start_token = path[0]
            
            
            scaffold_path_string = ""
            path_token = start_token
            scaffold_path_string = scaffold_path_string + " M %s %s " %\
                (self.token_coords(start_token)[0],\
                 self.token_coords(start_token)[1])
            while path_token.next_token != start_token:
                donor = path_token
                acceptor = donor.next_token
                if acceptor:
                # if there is a crossover
                    if donor.helix != acceptor.helix:
                        scaffold_path_string = scaffold_path_string +\
                            self.cont_scaf_crossover_template(path_token)
                path_token = path_token.next_token
            # do it one more time
            donor = path_token
            acceptor = donor.next_token
            if acceptor:
            # if there is a crossover
                if donor.helix != acceptor.helix:
                    scaffold_path_string = scaffold_path_string +\
                        self.cont_scaf_crossover_template(path_token)

                
            cont_scaffold_path_string = '''
                <path d="%s"  id="scaffold_path" fill = "none" stroke = "%s"/>'''\
                    % (scaffold_path_string,\
                       self.scaffold_color_set[color_index])
            all_scaffolds_string = all_scaffolds_string \
                + cont_scaffold_path_string
            color_index = (color_index + 1) % len(self.scaffold_color_set)
        all_scaffolds_group_string = '''
<g id="Scaffold Paths" stroke-width="2" fill="none">
     %s
</g>''' % all_scaffolds_string 
        return all_scaffolds_group_string
            

    def draw_debug_scaffold_path(self):
        print "DRAWING DEBUG SCAFFOLD PATH"
        all_scaffolds_string = ""
        color_index = 0
        for path in self.path.get_debug_scaffold_paths():
            start_token = path[0]
            scaffold_path_string = ""
            path_token = start_token
            scaffold_path_string = scaffold_path_string + " M %s %s " %\
                (self.token_coords(start_token)[0],\
                 self.token_coords(start_token)[1])
            for i in range(len(path) - 1):
                donor = path_token
                if donor == None:
                    continue
                acceptor = donor.next_token
                if acceptor:
                # if there is a crossover
                    if donor.helix != acceptor.helix:
                        scaffold_path_string = scaffold_path_string +\
                            self.cont_scaf_crossover_template(path_token)
                path_token = path_token.next_token
            # do it one more time
            donor = path_token
            if donor == None:
                continue
            acceptor = donor.next_token
            if acceptor:
            # if there is a crossover
                if donor.helix != acceptor.helix:
                    scaffold_path_string = scaffold_path_string +\
                        self.cont_scaf_crossover_template(path_token)
                
            cont_scaffold_path_string = '''
                <path d="%s" id = "Debug scaffold_path" fill = "none" stroke="%s"/>'''\
                    % (scaffold_path_string,\
                      self.scaffold_color_set[color_index])
            all_scaffolds_string = all_scaffolds_string\
                + cont_scaffold_path_string
            all_scaffolds_group_string = '''
<g id="Debug Scaffold Paths" stroke-width="2" fill="none">
     %s
</g>''' % all_scaffolds_string
            color_index = (color_index + 1) % len(self.scaffold_color_set)
        return all_scaffolds_group_string
    
    # STAPLES
    def get_staple_height(self, staple_token):
        """docstring for C{get_staple_height}"""
        helix = staple_token.helix
        helix_height = self.get_helix_height(helix)
        if helix % 2 == 0:
            staple_height = helix_height + 3
        else:
            staple_height = helix_height - 3
        return staple_height
    
    def get_staple_token_offset(self, staple_token):
        """docstring for C{get_staple_token_offset}
        """
        helix = staple_token.helix
        segment = staple_token.segment
        offset="?"
        for ofs in range(21):
            if self.staples.staple_tokens[helix][21*segment + ofs]\
               == staple_token:
                offset = ofs
        return offset
    
    def get_staple_token_base_num(self, token):
        """docstring for C{get_staple_token_base_num}"""
        return self.get_staple_token_offset(token)+(21*token.segment)
     
    def staple_token_coords(self, staple_token):
        """docstring for C{staple_token_coords}
        """ 
        spacing = 2.0/9.0
        helix = staple_token.helix
        segment = staple_token.segment
        offset = self.get_staple_token_offset(staple_token)
        # ending coords
        # go to the beginning of this token's segment
        x_coord = 21*segment + offset
        if staple_token.next_token and staple_token.prev_token:
            if staple_token.next_token.helix != staple_token.helix\
               or staple_token.prev_token.helix != staple_token.helix:
                # create terminal blank space for crossover
                if x_coord % 7 == 6:
                    x_coord = x_coord + 1 - spacing
                if x_coord % 7 == 0:
                    x_coord = x_coord + spacing
        # initial y-displacement
        y_coord = self.get_staple_height(staple_token)
        return (x_coord, y_coord)

    def cont_staple_crossover_template(self, staple_token):
        """docstring for C{cont_staple_crossover_template}
        """
        donor = staple_token
        acceptor = staple_token.next_token
        if acceptor: # if there is a crossover
            start_x_coord = self.staple_token_coords(donor)[0]
            start_y_coord = self.staple_token_coords(donor)[1]
            end_x_coord = self.staple_token_coords(acceptor)[0]
            end_y_coord = self.staple_token_coords(acceptor)[1]
            if donor.helix != acceptor.helix: # make a quadratic bezier spline
                # determine if it is a left or right crossover
                if donor.helix % 2 == 1: #left
                    control_x = start_x_coord -\
                                0.01*abs(end_y_coord-start_y_coord)
                    control_y = (start_y_coord +\
                                 end_y_coord)/2
                else: #right
                    control_x = start_x_coord +\
                                0.01*abs(end_y_coord-start_y_coord)
                    control_y = (start_y_coord + end_y_coord)/2
                spline_template = '''L %s %s Q %s,%s %s,%s'''\
                                    % (str(start_x_coord), \
                                       str(start_y_coord), \
                                       str(control_x), \
                                       str(control_y), \
                                       str(end_x_coord), \
                                       str(end_y_coord))
                return spline_template
            else: # there is no crossover
                diff = (start_x_coord - end_x_coord)
                if abs(diff) > 2:
                    if donor.helix % 2 ==0:
                        coeff = -1
                    else:
                        coeff = 1
                    control_y = start_y_coord +\
                                coeff*0.02*abs(end_x_coord-start_x_coord)
                    control_x = (start_x_coord + end_x_coord)/2
                    if donor.helix %2 == 1:
                        donor_shift = 1
                    else:
                        donor_shift = 0
                    if acceptor.helix % 2 == 0:
                        shift = 1
                    else:
                        shift = 0
                    spline_template = '''L %s %s Q %s,%s %s,%s'''\
                                    % (str(start_x_coord + donor_shift), \
                                       str(start_y_coord), \
                                       str(control_x), \
                                       str(control_y), \
                                       str(end_x_coord + shift), \
                                       str(end_y_coord))
                    return spline_template
                elif acceptor.next_token == None:
                    if acceptor.helix % 2 == 1:
                        shift = 1
                    else:
                        shift = 0
                    line_template = '''L %s %s''' % \
                       (str(end_x_coord + shift), str(end_y_coord))
                    return line_template
                else:    
                    return ""
        else:
            return ""

    def get_left_arrow(self, x, y):
        #leftward facing arrow
        #<g>
        #   <rect x="760" y="400" fill="#FFFFFF" width="9" height="9"/>
        # <polygon fill="#FC0303" points="760,409 769,404 760,400   "/>
        #</g>
        #</svg>
        left_arrow_template = '''
<g name = "staple breakpoint">
  <rect x="%s" y="%s" fill="#FFFFFF" width="1" height="1"/>
  <polygon fill="#FC0303" points="%s, %s %s %s %s %s"/>
</g>''' 
        return left_arrow_template % (x,\
                                    y-0.5,\
                                    x+1,\
                                    y-0.5,\
                                    x,\
                                    y+0.5-0.5,\
                                    x+1,\
                                    y+1-0.5)
        
    def get_right_arrow(self, x, y):
        #leftward facing arrow
        #<g>
        #   <rect x="760" y="400" fill="#FFFFFF" width="9" height="9"/>
        # <polygon fill="#FC0303" points="760,409 769,404 760,400   "/>
        #</g>
        #</svg>
        right_arrow_template = '''
<g name = "staple breakpoint">
  <rect x="%s" y="%s" fill="#FFFFFF" width="1" height="1"/>
  <polygon fill="#FC0303" points="%s, %s %s %s %s %s"/>
</g>''' 
        return right_arrow_template % (x-1,\
                                       y-0.5,\
                                       x-1,\
                                       y-0.5,\
                                       x,\
                                       y+0.5-0.5,\
                                       x-1,\
                                       y+1-0.5)

    def get_staple_paths(self):
        paths = []
        for staple in self.staples.staple_array:
            paths.append(staple)
        return paths

                 
    def draw_staple_paths(self):
    
        """docstring for C{draw_staple_paths}"""
        staple_paths = self.get_staple_paths()
        staple_string = ""
        color_index = 0
        staple_number = 0
        for staple_path in staple_paths:

            color = self.staple_color_set[color_index]
            color_index = (color_index + 1) % (len(self.staple_color_set))
            token = staple_path.token_list[0]
            if token.helix % 2 == 0:
                shift = 1
            else:
                shift = 0
            staple_path_string = " M %s %s " \
              % (self.staple_token_coords(token)[0] + shift,\
                 self.staple_token_coords(token)[1])
            for i in range(len(staple_path.token_list)-1):
                # staple_path_string = staple_path_string +\
                #     self.cont_horiz_staple_line_template(token)
                staple_path_string = staple_path_string +\
                    self.cont_staple_crossover_template(token)
                token = token.next_token
                if token.next_token== None:
                    break
                    
            # Color cap and connector staples
            if staple_path.cap:
                color = "blue"
            if staple_path.connector:
                color = "red"
            cont_staple_path_string = '''
                <path d="%s" id="staple_path_%s_" stroke="%s"/>'''\
                    % (staple_path_string,staple_number, color)
#            staple_path_group_string = '''
#        <g>
#            %s
#        </g>''' % cont_staple_path_string
#            staple_string = staple_string + staple_path_group_string
            staple_string = staple_string + cont_staple_path_string
            staple_number +=1
        # add in staple breakpoints:
        breakpoint_string = ""
        for staple_path in staple_paths:
            token = staple_path.token_list[0]
            for i in range(len(staple_path.token_list)):
                if token.helix % 2 == 0:
                    coords = [self.staple_token_coords(token)[0],\
                              self.staple_token_coords(token)[1]]
                else:
                    coords = [self.staple_token_coords(token)[0]+1,\
                              self.staple_token_coords(token)[1]]
                # draw a breakpoint to seal upstream edge-crossing paths
                if (not token.prev_token):
                    if token.helix % 2 == 0:
                        natural_prev_token_pos = token.position + 1
                    else:
                        natural_prev_token_pos = token.position - 1
                    if  not (self.path.path_array[token.helix]\
                                                [natural_prev_token_pos].base\
                                                 in "ATCG"):
                        if token.helix % 2 == 0:
                            coords = [self.staple_token_coords(token)[0] + 1,\
                              self.staple_token_coords(token)[1]]
                        else:
                            coords = [self.staple_token_coords(token)[0] + 1 - 1,\
                              self.staple_token_coords(token)[1]]
                        if token.helix % 2 == 0:
                            breakpoint_string = breakpoint_string\
                            + self.get_left_arrow(coords[0], coords[1])
                        else:
                            breakpoint_string = breakpoint_string\
                            + self.get_right_arrow(coords[0], coords[1])
                            
                # put a breakpoint at the ends of staple paths
                if not token.next_token:
#                    breakpoint_string = breakpoint_string + '''
#        <circle cx="%s" cy="%s" r="0.25" fill="red"/> 
#''' % (coords[0],\
#       coords[1])
                    if token.helix % 2 == 0:
                        breakpoint_string = breakpoint_string\
                          + self.get_left_arrow(coords[0], coords[1])
                    else:
                        breakpoint_string = breakpoint_string\
                          + self.get_right_arrow(coords[0], coords[1])                      
                    break
                token = token.next_token
        return (staple_path_template % staple_string) \
            + breakpoints_template % breakpoint_string
    
    # OTHER MARKINGS
    def draw_neighbor_ptrs_layer(self):
        """doctring for C{draw_neighbor_ptrs_layer}"""
        all_helices = self.path.lattice.all_helices
        num_horiz_ticks =self.get_max_horizontal_scaf_extent()
        neighbor_ptrs_string = ""
        for helix in all_helices:
            for x_coord in range(21):
                p2_lengths = [2, 12]
                p0_lengths = [5, 16]
                p1_lengths = [9, 19]           
                
                # get slices in which to search for neighbors
                slice_indices = []
                left_segment_boundary = x_coord - (x_coord % 21)
                left_slice_index = left_segment_boundary / 21 - 1
                right_slice_index = left_slice_index + 1
            
                # edges only have one slice
                if left_slice_index >= 0:
                    slice_indices.append(left_slice_index)
                if right_slice_index < len(self.path.lattice.LatticeSliceList):
                    slice_indices.append(right_slice_index)
                lattice_slices = self.path.lattice.LatticeSliceList
                
                # we don't want to write text twice here
                neighbors_written = [] 
            
                for slice in slice_indices:                             
                    if not helix in lattice_slices[slice].helix_set:
                        continue
                        
                    neighbors = lattice_slices[slice]\
                        .xover_to_neighbor[helix].keys() 
            
                    if x_coord % 21 in p0_lengths \
                    and 0 in neighbors\
                    and not neighbors_written.count(0):
                        neighbors_written.append(0)
                        neighbor_ptrs_string += '''
    <text x="%s" y="%s">%s</text>''' % (str(x_coord),\
                                        str(self.get_helix_height(helix)),\
                                        str(lattice_slices[slice]\
                                            .xover_to_neighbor[helix][0]))
                
                    if x_coord % 21 in p1_lengths\
                    and 1 in neighbors\
                    and not neighbors_written.count(1):
                        neighbors_written.append(1)
                        neighbor_ptrs_string += '''
    <text x="%s" y="%s">%s</text>''' % (str(x_coord),\
                                        str(self.get_helix_height(helix)),\
                                        str(lattice_slices[slice]\
                                            .xover_to_neighbor[helix][1]))
                
                    if x_coord % 21 in p2_lengths\
                    and 2 in neighbors\
                    and not neighbors_written.count(2):
                        neighbors_written.append(2)
                        neighbor_ptrs_string += '''
    <text x="%s" y="%s">%s</text>''' % (str(x_coord),\
                  str(self.get_helix_height(helix)),\
                  str(lattice_slices[slice].xover_to_neighbor[helix][2]))
        
        neighbor_ptr_group_string ='''
        <g id="Neighbor Pointers" font-size = "1">
            %s
        </g>''' % neighbor_ptrs_string
        
        return neighbor_ptr_group_string
        
    def draw_tick_marks(self):
        """docstring for C{draw_tick_marks}"""
        num_helices = len(self.path.path_array)
        num_horiz_ticks =self.get_max_horizontal_scaf_extent()
        tick_mark_string=""
        start_y_coord = 2
        end_y_coord = 2
        for helix_num in range(num_helices):
            if helix_num%2 == 0:
                end_y_coord = end_y_coord + 8
            else:
                end_y_coord = end_y_coord + 4
        end_y_coord = end_y_coord + 2
        
        for tick_num in range(num_horiz_ticks):
            x_coord = tick_num
            # staple ticks every seven base pairs
            if x_coord % 7 == 0:
                 line_template ='''
        <line x1=\"%s\" y1=\"%s\"  x2=\"%s\" y2=\"%s\" stroke="blue" stroke-dasharray="9,36,9,72"/>
''' % ( str(x_coord), \
        str(start_y_coord),\
        str(x_coord), \
        str(end_y_coord))
            else:
                lengths = [2,2+3,2+3+4,2+3+4+3,2+3+4+3+4,2+3+4+3+4+3]
                for length in lengths:
                    if x_coord % 21 == length:
                        line_template ='''
        <line x1=\"%s\" y1=\"%s\"  x2=\"%s\" y2=\"%s\" stroke="green" stroke-dasharray="9,36,9,72"/>
''' % (str(x_coord), \
       str(start_y_coord),\
       str(x_coord), \
       str(end_y_coord))
                                
            tick_mark_string = tick_mark_string\
                               + line_template
        tick_mark_group_string = '''
    <g id="Tick Marks" stroke-width="0.2" opacity="1">
        %s
    </g>''' % tick_mark_string
        return tick_mark_group_string
    
    def draw_domain_boundaries(self):
        """docstring for C{draw_domain_boundaries}
        """
        domain_boundary_string = ""
        # Z-boundaries for 21bp subdomains
        num_helices = len(self.path.path_array)
        num_horiz_ticks = self.get_max_horizontal_scaf_extent()
        y_displacement = 0
        for helix_num in range(num_helices):
            if helix_num%2 == 0:
                y_displacement = y_displacement + 8
            else:
                y_displacement = y_displacement + 4
        for x in range(num_horiz_ticks+1):
            if x % 21 == 0:
                line_template ='''
        <line x1=\"%s\" y1=\"%s\"  x2=\"%s\" y2=\"%s\" />
                ''' % ( str(x), str(0),\
                    str(x), str(y_displacement))
                domain_boundary_string = domain_boundary_string + \
                                         line_template
        # X-boundaries
        domain_dict = self.domain.boundary_dict
        for helix_num in range(num_helices):
            # get the helix height on the diagram
            y_coord = self.get_helix_height(helix_num)
            # this should give the number of segments
            for segment_num in range(len(domain_dict[helix_num])):
                if domain_dict[helix_num][segment_num]['+xy'] \
                   or  domain_dict[helix_num][segment_num]['+xy']:
                        line_template ='''
        <line x1=\"%s\" y1=\"%s\"  x2=\"%s\" y2=\"%s\" />
                        ''' % ( str(0), str(y_coord),\
                        str(num_horiz_ticks), str(y_coord))
                        domain_boundary_string = domain_boundary_string + \
                                                 line_template
        domain_boundary_group_string ='''
        <g id="Domain Boundary Lines" stroke = "orange" stroke-width="0.2" opacity="0.8">
        %s
        </g>
''' % domain_boundary_string
        return domain_boundary_group_string
    
    def draw_grid(self):
        """docstring for C{draw_grid}"""
        grid_string = ""
        num_helices = len(self.path.path_array)
        num_horiz_ticks = self.get_max_horizontal_scaf_extent()
        y_displacement = 0
        for helix_num in range(num_helices):
            if helix_num%2 == 0:
                y_displacement = y_displacement + 8
            else:
                y_displacement = y_displacement + 4
        for x in range(num_horiz_ticks+1):
            line_template ='''
        <line x1=\"%s\" y1=\"%s\"  x2=\"%s\" y2=\"%s\" />
            ''' % ( str(x), str(0),\
                str(x), str(y_displacement))
            grid_string = grid_string + line_template
        for y in range(y_displacement+1):
            line_template = '''
        <line x1=\"%s\" y1=\"%s\"  x2=\"%s\" y2=\"%s\" />
                    ''' % ( str(0), str(y),\
                        str(num_horiz_ticks), str(y))
            grid_string = grid_string + line_template
        grid_group_string = '''
        <g id="Grid Lines" stroke="black" stroke-width="0.2" opacity="0.2">
        %s
        </g>
''' % grid_string
        return grid_group_string
    
    def draw_text(self):
        """docstring for C{draw_text}"""
        
        # helix numbers
        helix_text_string = ""
        for helix in range(len(self.path.path_array)):
            helix_text_string = helix_text_string +'''
            <text x="0" y="%s">
            %s
            </text>''' % (str(self.get_helix_height(helix)), str(helix))
            
        # subzone numbers
        subzone_text_string = ""
        for base_num in range(7, self.get_max_horizontal_scaf_extent()):
            if base_num % 7 ==0:
                subzone_text_string = subzone_text_string + '''
            <text x="%s" y="0">
            %s
            </text>''' % (str(base_num), str(base_num))
        
        text_string = helix_text_string + subzone_text_string
        text_group_string = '''
        <g id="Text" stroke="black" font-size = "2">
        %s
        </g>''' % text_string
        return text_group_string
        
    def draw_staple_xover_markers(self):
        pass
    def draw_scaffold_xover_markers(self):
        pass
    def write_svg_file(self):
        """docstring for output_svg"""
        print "Writing SVG output.."
        
        content_string = ''
        name = self.design_name
        
        # get rendering parameters
        draw_grid = self.svg_params['draw_grid_squares']
        draw_scaffold = self.svg_params['draw_scaffold']
        draw_staples = self.svg_params['draw_staples']
        draw_ticks = self.svg_params['draw_guide_marks']
        draw_text = self.svg_params['draw_text_labels']
        draw_debug_scaffold = self.svg_params['draw_debug_scaffold']
        draw_neighbors_key = self.svg_params['draw_neighbors_key']
        
        # build up output string
        
        # this is for debugging initial scaffold path
        if draw_neighbors_key == 'True':
            content_string = content_string + self.draw_neighbor_ptrs_layer()
        if draw_debug_scaffold == 'True':
            content_string = content_string + self.draw_debug_scaffold_path()
        if draw_grid == 'True':
            content_string = content_string + self.draw_grid()
        content_string = content_string + self.draw_domain_boundaries()
        if draw_scaffold == 'True':
            content_string = content_string + self.draw_scaffold_paths()
        if draw_ticks == 'True':
            content_string = content_string + self.draw_tick_marks()
        if draw_staples == 'True':
            content_string = content_string + self.draw_staple_paths()
        if draw_text == 'True':
            content_string = content_string + self.draw_text()
        out_file = file(self.svg_output_file, "w")
        out_file.write(svg_output_template % (name, content_string))
        out_file.close()
        print "...done: %s" % self.svg_output_file
                
class SvgReader():
    def __init__(self, config, path):
        self.svg_input_file = config['file']['svg_output_file']
        self.path = path
    
    def snap_to_horizontal_grid(self, position):
        return int(position)
    
    # scaffold
    def get_helix_height(self, helix):
        """docstring for C{get_helix_height}"""
        # get the helix height on the diagram
        y_coord = 2
        for pre_helix in range(helix):
            if pre_helix%2 == 0:
                y_coord = y_coord + 8
            else:
                y_coord = y_coord + 4
        return y_coord
        
    def get_scaf_helix_num(self, helix_height):
        num_helices = len(self.path.path_array)
        for i in range(num_helices):
            if self.get_helix_height(i) == helix_height:
                return i        
    def snap_to_scaffold_height(self, height):
        height0 = int(height)
        height1 = int(height) - 1
        height2 = int(height) + 1
        height3 = int(height) - 2
        height4 = int(height) + 2
        for h in [height0, height1, height2, height3, height4]:
            if self.get_scaf_helix_num(h) != None:
                return h
                
        return None
    # staples 
    def get_staple_height(self, helix_num):
        """docstring for C{get_staple_height}"""
        helix = helix_num
        helix_height = self.get_helix_height(helix)
        if helix % 2 == 0:
            staple_height = helix_height + 3
        else:
            staple_height = helix_height - 3
        return staple_height
    
    
    def snap_to_staple_height(self, height):
        height0 = int(height)
        height1 = int(height) - 1
        height2 = int(height) + 1
        height3 = int(height) - 2
        height4 = int(height) + 2
        for h in [height0, height1, height2, height3, height4]:
            if self.get_helix_num(h) != None:
                return h
        return None
    def get_helix_num(self, helix_height):
        num_helices = len(self.path.path_array)
        for i in range(num_helices):
            if self.get_staple_height(i) == helix_height:
                return i
                
    def read_breakpoints_from_svg(self):
        file = open(self.svg_input_file, 'r')
        # Create a parser
        parser = make_parser()

        # Tell the parser we are not interested in XML namespaces
        parser.setFeature(feature_namespaces, 0)
    
        # Create the handler
        h = BreakpointReader(self)

        # Tell the parser to use our handler
        parser.setContentHandler(h)

        # Parse the input
        parser.parse(file)
        file.close()
    
        return h.get_breakpoints()
    
    def read_staple_xovers(self):
        file = open(self.svg_input_file, 'r')
        # Create a parser
        parser = make_parser()

        # Tell the parser we are not interested in XML namespaces
        parser.setFeature(feature_namespaces, 0)
    
        # Create the handler
        h = StapleXoverReader(self)

        # Tell the parser to use our handler
        parser.setContentHandler(h)

        # Parse the input
        parser.parse(file)
        
        file.close()
        
        return h.get_staple_xovers()
        
    def read_scaffold_crossovers(self):
        file = open(self.svg_input_file, 'r')
        # Create a parser
        parser = make_parser()

        # Tell the parser we are not interested in XML namespaces
        parser.setFeature(feature_namespaces, 0)
    
        # Create the handler
        h = ScaffoldPathReader(self)

        # Tell the parser to use our handler
        parser.setContentHandler(h)

        # Parse the input
        parser.parse(file)
        
        file.close()
    
        return h.get_scaffold_crossover_pointers()
        

class BreakpointReader(ContentHandler):
    def __init__(self, svg_reader):
        self.svg_reader = svg_reader
        self.breakpoints = {}
        for i in range(len(svg_reader.path.path_array)):
            self.breakpoints[i] = []
    def startElement(self, name, attrs):
        if name == "rect":  
            raw_height = int(1 + float(attrs.get('y', "")))
            height = self.svg_reader.snap_to_staple_height(raw_height)
            if height == None:
                return
            y = self.svg_reader.get_helix_num(height)
            if y%2 == 1:
                offset = 0.5
            else: 
                offset = 0
            x = int(float(attrs.get('x', "")) + offset)
            self.breakpoints[y].append(x)
    def get_breakpoints(self):
        b = self.breakpoints
        return b
        
class ScaffoldPathReader(ContentHandler):
    def __init__(self, svg_reader):
        self.svg_reader = svg_reader
        
        """A list of scaffold xover token pointer pairs, 
           of the form: [[prev_helix, prev_pos], [next_helix, next_pos]].
        """
        self.xover_pointers = []
        self.xovers = []
        
    def startElement(self, name, attrs):
    # find an xml tag called path
        if name == "path":
            for attr in attrs.items():
                if attr[0] == "id" and attr[1].find("scaffold_path") >= 0:
                    for a in attrs.items():
                        if a[0] == 'd':
                            # found the path coordinate string
                            coord_string = a[1]
                            
                            if coord_string[-1] == "z":
                                coord_string = coord_string[:-1]
                            
                            # initialize lists for parsing
                            H_indices = []
                            for i in range(len(coord_string)):
                                if coord_string[i] == "h" \
                                    or coord_string[i] == "H":
                                    H_indices.append(i)
                            H_indices.sort()
                            
                            C_indices = []
                            for i in range(len(coord_string)):
                                if coord_string[i] == "c"\
                                    or coord_string[i] == "C":
                                    C_indices.append(i)
                            C_indices.sort()
                            
                            xover_coords = []
                            

                            if len(C_indices) != 0:
                                C_index = C_indices[0]
                            else:
                                C_index = len(coord_string)
                                
                            if H_indices != [] and H_indices[0] < C_index:
                                # if path starts with horizontal line    
                                curr_H_list_index = 0
                                # get the start coordinates
                                H_index = H_indices[curr_H_list_index]
                                initial_move_string = coord_string[1: H_index]
                                coords = initial_move_string.split(",")
                                # initial moveto coords
                                curr_coords = [float(coords[0]),\
                                                float(coords[1])]
                                # traverse the first horizontal line
                                if coord_string[H_index] == "h":
                                    # relative coords
                                    # the initial horizontal line after the moveto
                                    horiz_line_str = coord_string\
                                        [H_index + 1: C_index] 
                                    horiz_offset = float(horiz_line_str)
                                    curr_coords[0] += horiz_offset
                                elif coord_string[H_index] == "H":
                                    # absolute coords
                                    # the initial horizontal line after the moveto
                                    horiz_line_str = coord_string\
                                        [H_index + 1: C_index]
                                    curr_coords[0] = float(horiz_line_str)
                                else:
                                    print "Problem with horizontal line string"
                            else:
                                curr_H_list_index = -1
                                initial_move_string = coord_string[1: C_index]
                                coords = initial_move_string.split(",")
                                # initial moveto coords
                                curr_coords = [float(coords[0]),\
                                                float(coords[1])]
                                
                            for i in range(len(C_indices)):
                                C_index = C_indices[i]
                                curr_H_list_index += 1
                                if curr_H_list_index == len(H_indices):
                                    # a special case where Illustrator
                                    # ends the path after an xover
                                    # with a "z" after modification
                                    # (we removed this "z" above...)
                                    H_index = len(coord_string)
                                else:
                                    H_index = H_indices[curr_H_list_index]
                                # including the first C or c for checking
                                c_string = coord_string[C_index: H_index]    
                                
                                # append the near side of the crossover
                                near_xover = [curr_coords[0], curr_coords[1]]
                                self.xovers.append(near_xover)
                                
                                # append the far side of the crossover
                                far_xover = self.get_coords_from_c_string(\
                                                c_string, curr_coords)
                                self.xovers.append(far_xover)
                                
                                ptr = [near_xover, far_xover]
                                self.xover_pointers.append(ptr)
                                
                                if int(far_xover[0]) != int(near_xover[0]):
                                    print "Possible Non-vertical Crossover"
                                    
                                # do the vertical move
                                curr_coords[1] = far_xover[1]
                                
                                if C_index != C_indices[-1]:
                                    C_index = C_indices[i + 1]
                                else:
                                    C_index = len(coord_string)
                                    
                                if H_index != len(coord_string):
                                    # do the horizontal move
                                    if coord_string[H_index] == "h":
                                        # relative coords
                                        # the initial horizontal line after the moveto
                                        horiz_line_str = coord_string\
                                            [H_index + 1: C_index] 
                                        horiz_offset = float(horiz_line_str)
                                        curr_coords[0] += horiz_offset
                                    elif coord_string[H_index] == "H":
                                        # absolute coords
                                        # the initial horizontal line after the moveto
                                        horiz_line_str = coord_string\
                                            [H_index + 1: C_index]
                                        curr_coords[0] = float(horiz_line_str)
                                    else:
                                        print "Problem with horizontal line string"
                            break
                            
    def get_coords_from_c_string(self, c_string, curr_coords):
        if not c_string[0] in ["C", "c"]:
            print "Problem with a c_string"
        else:
            marker_indices = []
            for i in range(len(c_string)):
                if c_string[i] == "-" or c_string[i] == ",":
                    marker_indices.append(i)
                
            marker_indices.sort()
            
            if len(marker_indices) == 6:
                first_index = marker_indices[4]
                second_index = marker_indices[5]
            else:
                first_index = marker_indices[3]
                second_index = marker_indices[4]
                
            first_coord = float(c_string[first_index + 1: second_index])
            
            if c_string[first_index] == "-":
                first_coord = -1*first_coord
            second_coord = float(c_string[second_index + 1:])
            if c_string[second_index] == "-":
                second_coord = -1*second_coord
            if c_string[0] == "c":
                return [curr_coords[0] + first_coord, curr_coords[1] \
                    + second_coord]
            if c_string[0] == "C":
                return [first_coord, second_coord]                            
        
    def get_scaffold_crossover_pointers(self):
        """Returns a dictionary of INCLUDED staple crossovers.
        """
        xovers_dict = {}
        for helix in range(len(self.svg_reader.path.path_array)):
            xovers_dict[helix] = []
        for i in self.xovers:
            diffs = [0 for j in scaf_xover_positions]
            x = i[0]
            y = i[1]
            
            x = self.svg_reader.snap_to_horizontal_grid(x) 
            y = self.svg_reader.get_scaf_helix_num(\
                self.svg_reader.snap_to_scaffold_height(y))
            
            left_boundary = 21*(x/21)
            offset = x % 21
            min_dist = 21
            chosen_pos = 0
            for pos in scaf_xover_positions:
                if abs(offset - pos) < min_dist:
                    chosen_pos = pos
                    min_dist = abs(offset - pos)
            if not xovers_dict[y].count(chosen_pos + left_boundary):        
                xovers_dict[y].append(chosen_pos + left_boundary)
                
        for key in xovers_dict.keys():
            xovers_dict[key].sort()                              
        
        for ptr in self.xover_pointers:
            
            x = self.svg_reader.snap_to_horizontal_grid(ptr[0][0])
            left_boundary = 21*(x/21)
            offset = x % 21
            min_dist = 21
            chosen_pos = 0
            for pos in scaf_xover_positions:
                if abs(offset - pos) < min_dist:
                    chosen_pos = pos
                    min_dist = abs(offset - pos)
                    
            x = chosen_pos + left_boundary
            
            position = x
            helix = self.svg_reader.get_scaf_helix_num(\
                self.svg_reader.snap_to_scaffold_height(ptr[0][1]))
                
            ptr[0][0] = helix
            ptr[0][1] = position
            
            x = self.svg_reader.snap_to_horizontal_grid(ptr[1][0])
            left_boundary = 21*(x/21)
            offset = x % 21
            min_dist = 21
            chosen_pos = 0
            for pos in scaf_xover_positions:
                if abs(offset - pos) < min_dist:
                    chosen_pos = pos
                    min_dist = abs(offset - pos)
                    
            x = chosen_pos + left_boundary
            position = x
            helix = self.svg_reader.get_scaf_helix_num(\
                self.svg_reader.snap_to_scaffold_height(ptr[1][1]))
             
            ptr[1][0] = helix
            ptr[1][1] = position
                       
        return self.xover_pointers
                 
    
class StapleXoverReader(ContentHandler):
    """For this to work:
        -horizontal staple lines have to be strictly horizontal
        -all crossover must be represented with curved cubic splines,
         NOT straight lines
        -there can be no anchor points on paths except where horizontal
         lines meet the cubic spline vertical crossovers
    """
    def __init__(self, svg_reader):
        self.level = 0
        self.svg_reader = svg_reader
        
        """A list of included staple xovers positions."
        """
        self.xovers = []
    def startElement(self, name, attrs):
        # find an xml tag called path
        if name == "path":
            for attr in attrs.items():
                if attr[0] == "id" and attr[1].find("staple_path") >= 0:
                    for a in attrs.items():
                        if a[0] == 'd':
                            # found the path coordinate string
                            coord_string = a[1]
                            
                            if coord_string[-1] == "z":
                                coord_string = coord_string[:-1]
                            
                            # initialize lists for parsing
                            H_indices = []
                            for i in range(len(coord_string)):
                                if coord_string[i] == "h" \
                                    or coord_string[i] == "H":
                                    H_indices.append(i)
                            H_indices.sort()
                            
                            C_indices = []
                            for i in range(len(coord_string)):
                                if coord_string[i] == "c" \
                                    or coord_string[i] == "C":
                                    C_indices.append(i)
                            C_indices.sort()
                            
                            xover_coords = []
                            

                            if len(C_indices) != 0:
                                C_index = C_indices[0]
                            else:
                                C_index = len(coord_string)
                                
                            if H_indices != [] and H_indices[0] < C_index:
                                # if path starts with horizontal line    
                                curr_H_list_index = 0
                                # get the start coordinates
                                H_index = H_indices[curr_H_list_index]
                                initial_move_string = coord_string\
                                    [1: H_index]
                                coords = initial_move_string.split(",")
                                # initial moveto coords
                                curr_coords = [float(coords[0]),\
                                                float(coords[1])]
                                # traverse the first horizontal line
                                if coord_string[H_index] == "h":
                                    # relative coords
                                    # the initial horizontal line after the moveto
                                    horiz_line_str = coord_string\
                                        [H_index + 1: C_index] 
                                    horiz_offset = float(horiz_line_str)
                                    curr_coords[0] += horiz_offset
                                elif coord_string[H_index] == "H":
                                    # absolute coords
                                    # the initial horizontal line after the moveto
                                    horiz_line_str = coord_string\
                                        [H_index + 1: C_index]
                                    curr_coords[0] = float(horiz_line_str)
                                else:
                                    print "Problem with horizontal line string"
                            else:
                                curr_H_list_index = -1
                                initial_move_string = coord_string[1: C_index]
                                coords = initial_move_string.split(",")
                                # initial moveto coords
                                curr_coords = [float(coords[0]),\
                                                float(coords[1])]
                                
                            for i in range(len(C_indices)):
                                C_index = C_indices[i]
                                curr_H_list_index += 1
                                if curr_H_list_index == len(H_indices):
                                    # a special case where Illustrator
                                    # ends the path after an xover
                                    # with a "z" after modification
                                    # (we removed this "z" above...)
                                    H_index = len(coord_string)
                                else:
                                    H_index = H_indices[curr_H_list_index]
                                # including the first C or c for checking
                                c_string = coord_string[C_index: H_index]    
                                
                                # append the near side of the crossover
                                near_xover = [curr_coords[0], curr_coords[1]]
                                if not self.xovers.count(near_xover):
                                    self.xovers.append(near_xover)
                                
                                # append the far side of the crossover
                                far_xover = self.get_coords_from_c_string(\
                                    c_string, curr_coords)
                                if not self.xovers.count(far_xover):
                                    self.xovers.append(far_xover)
                                
                                if int(far_xover[0]) != int(near_xover[0]):
                                    print "Possible Non-vertical Crossover"
                                    
                                # do the vertical move
                                curr_coords[1] = far_xover[1]
                                
                                if C_index != C_indices[-1]:
                                    C_index = C_indices[i + 1]
                                else:
                                    C_index = len(coord_string)
                                
                                if H_index < len(coord_string):    
                                    # do the horizontal move
                                    if coord_string[H_index] == "h":
                                        # relative coords
                                        # the initial horizontal line after the moveto
                                        horiz_line_str = coord_string\
                                            [H_index + 1: C_index] 
                                        horiz_offset = float(horiz_line_str)
                                        curr_coords[0] += horiz_offset
                                    elif coord_string[H_index] == "H":
                                        # absolute coords
                                        # the initial horizontal line after the moveto
                                        horiz_line_str = coord_string\
                                            [H_index + 1: C_index]
                                        curr_coords[0] = float(horiz_line_str)
                                    else:
                                        print "Problem with horizontal line string"    
                            break
                            
    def get_coords_from_c_string(self, c_string, curr_coords):
        if not c_string[0] in ["C", "c"]:
            print "Problem with a c_string"
        else:
            marker_indices = []
            for i in range(len(c_string)):
                if c_string[i] == "-" or c_string[i] == ",":
                    marker_indices.append(i)
                
            marker_indices.sort()
            
            if len(marker_indices) == 6:
                first_index = marker_indices[4]
                second_index = marker_indices[5]
            else:
                first_index = marker_indices[3]
                second_index = marker_indices[4]
                
            first_coord = float(c_string[first_index + 1: second_index])
            
            if c_string[first_index] == "-":
                first_coord = -1*first_coord
            second_coord = float(c_string[second_index + 1:])
            if c_string[second_index] == "-":
                second_coord = -1*second_coord
                
            if c_string[0] == "c":
                return [curr_coords[0] + first_coord, curr_coords[1]\
                    + second_coord]
            if c_string[0] == "C":
                return [first_coord, second_coord]
    def get_staple_xovers(self):
        """Returns a dictionary of INCLUDED staple crossovers.
        """
        breakpoints = self.svg_reader.read_breakpoints_from_svg()
        xovers_dict = {}
        for helix in range(len(self.svg_reader.path.path_array)):
            xovers_dict[helix] = []
        for i in self.xovers:
            x = i[0]
            y = i[1]
            x = self.svg_reader.snap_to_horizontal_grid(x) 
            y = self.svg_reader.get_helix_num(\
                self.svg_reader.snap_to_staple_height(y))
            
            # the breakpoints are getting included for some reason
            if (not x in breakpoints[y]) and (not x-1 in breakpoints[y]):
                # round to nearest multiple of 7
                if x % 7 >= 4:
                    x = 7 + (7*(x/7))
                else:
                    x = (7*(x/7))
                xovers_dict[y].append(x)
                
#        print "Staple crossover position dictionary:"
#        for (key, value) in xovers_dict.items():
#            print key, ":", value
        for key in xovers_dict.keys():
            xovers_dict[key].sort()
        return xovers_dict