
#!/usr/bin/env python
# encoding: utf-8
import sys
import os
import cPickle as pickle

def get_excluded_xovers():
    exclude = [[] for i in range(64)]
    for i in [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62]:
        exclude[i].extend([0])
    for i in [4, 7, 12, 15, 20, 23, 28, 31, 36, 39, 44, 47, 52, 55, 60, 63]:
        exclude[i].extend([35, 56, 98, 119])
    for i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63]:
        exclude[i].extend([7, 133, 140])
    for i in [0, 2, 61, 63]:
        exclude[i].extend([28, 49, 70, 112])
    for i in [0, 3, 8, 11, 16, 19, 24, 27, 32, 35, 40, 43, 48, 51, 56, 59]:
        exclude[i].extend([21, 42, 63, 105])
    for i in [4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31, 36, 37, 38, 39, 44, 45, 46, 47, 52, 53, 54, 55, 60, 61, 62, 63]:
        exclude[i].extend([77])
    for i in [0, 1, 2, 3, 4, 7, 8, 9, 10, 11, 12, 15, 16, 17, 18, 19, 20, 23, 24, 25, 26, 27, 28, 31, 32, 33, 34, 35, 36, 39, 40, 41, 42, 43, 44, 47, 48, 49, 50, 51, 52, 55, 56, 57, 58, 59, 60, 63]:
        exclude[i].extend([14])
    for i in [0, 1, 2, 3, 8, 9, 10, 11, 16, 17, 18, 19, 24, 25, 26, 27, 32, 33, 34, 35, 40, 41, 42, 43, 48, 49, 50, 51, 56, 57, 58, 59]:
        exclude[i].extend([84])
    for i in [0, 2, 3, 4, 7, 8, 11, 12, 15, 16, 19, 20, 23, 24, 27, 28, 31, 32, 35, 36, 39, 40, 43, 44, 47, 48, 51, 52, 55, 56, 59, 60, 61, 63]:
        exclude[i].extend([91])
    for i in [0, 3, 4, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 27, 28, 29, 30, 31, 32, 35, 36, 37, 38, 39, 40, 43, 44, 45, 46, 47, 48, 51, 52, 53, 54, 55, 56, 59, 60, 61, 62, 63]:
        exclude[i].extend([126])
    return exclude
    
def get_staple_breakpoints():
    breakpoint = [[] for i in range(64)]
    for i in [5, 7, 13, 15, 21, 23, 29, 31, 37, 39, 45, 47, 53, 55, 61, 63]:
        breakpoint[i].extend([4, 130])
    for i in [1, 3, 7, 9, 11, 15, 17, 19, 23, 25, 27, 31, 33, 35, 39, 41, 43, 47, 49, 51, 55, 57, 59, 63]:
        breakpoint[i].extend([3])
    for i in [4, 6, 12, 14, 20, 22, 28, 30, 36, 38, 44, 46, 52, 54, 60, 62]:
        breakpoint[i].extend([5, 131])
    for i in [1, 3, 9, 11, 17, 19, 25, 27, 33, 35, 41, 43, 49, 51, 57, 59]:
        breakpoint[i].extend([8, 134])
    for i in [0, 2, 8, 10, 16, 18, 24, 26, 32, 34, 40, 42, 48, 50, 56, 58]:
        breakpoint[i].extend([9, 135])
    for i in [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62]:
        breakpoint[i].extend([143])
    for i in [2, 10, 18, 26, 34, 42, 50, 58]:
        breakpoint[i].extend([24, 115])
    for i in [5, 13, 21, 29, 37, 45, 53, 61]:
        breakpoint[i].extend([31, 80, 93, 108])
    for i in [1, 17, 33, 49]:
        breakpoint[i].extend([37, 45, 58, 66])
    for i in [6, 10, 14, 22, 26, 30, 38, 42, 46, 54, 58, 62]:
        breakpoint[i].extend([38])
    for i in [10, 26, 42, 58]:
        breakpoint[i].extend([46, 67])
    for i in [5, 21, 37, 53]:
        breakpoint[i].extend([51])
    for i in [14, 30, 46, 62]:
        breakpoint[i].extend([52, 60])
    for i in [5, 10, 21, 26, 37, 42, 53, 58]:
        breakpoint[i].extend([59])
    for i in [1, 3, 9, 17, 25, 33, 41, 49, 57]:
        breakpoint[i].extend([79])
    for i in [6, 14, 22, 30, 38, 46, 54, 62]:
        breakpoint[i].extend([81, 102])
    for i in [10, 18, 26, 34, 42, 50, 58]:
        breakpoint[i].extend([88])
    for i in [0, 8, 16, 24, 32, 40, 48, 56]:
        breakpoint[i].extend([101])
    return breakpoint
    
def get_caps():
    caps = [[] for i in range(64)]
    return caps
    
def get_connectors():
    connectors = [[] for i in range(64)]
    return connectors
    
def main():
    exclude = get_excluded_xovers()
    breakpoint = get_staple_breakpoints()
    caps = get_caps()
    connectors = get_connectors()
    info = (exclude, breakpoint, caps, connectors)
    pickle.dump(info, open('ytps_v2i0.p', 'w'))

if __name__ == '__main__':
    main()
