#!/usr/bin/env python
# encoding: utf-8
"""docstring for xtps_c2_pickle.py"""

import sys
import os
import cPickle as pickle

def get_excluded_xovers():
    """docstring for get_excluded_xovers"""
    exclude = {}
    """@ivar: Given helix number, return list of positions where
       crossovers should not be included.
       @type: C{dictionary}
    """
    # remove all crossovers for specific positions
    for i in range(0, 30):
        exclude[i] = [14, 42, 56, 84, 98, 126, 133, 140]
    for i in range(30,60):
        exclude[i] = [21, 35, 63, 77, 105, 119, 133, 140]
    for i in [9, 19, 29, 30,40, 50]:
        exclude[i].extend([28, 28+42, 28+84])
    # put back select crossovers
    for i in [14,15]:
        exclude[i].remove(56)
        exclude[i].remove(98)
    for i in [39,40,49,50]:
        exclude[i].remove(35)
        exclude[i].remove(77)
        exclude[i].remove(119)
    return exclude

def get_staple_breakpoints():
    """docstring for get_staple_breakpoints"""
    breakpoint = {}
    """@ivar: Given helix number, return list of 3' positions of staples.
       @type: C{dictionary}
    """
    for i in range(60):
        breakpoint[i] = []
    
    # TOP PLY working from left to right
    
    #extra breakpoints for the left and right edges (...do we want these?)
    for i in range(0, 29, 2):
        breakpoint[i].extend([133])
    for i in [12, 14, 16]:
        breakpoint[i].remove(133)
    for i in range(1, 30, 2):
        breakpoint[i].extend([10])
    for i in [13, 15, 17]:
        breakpoint[i].remove(10)
        
    # top ply position 31 breakpoints on odd strands
    for i in range(3,30,2):
        breakpoint[i].extend([31])
    for i in [11, 21]: # remove exceptions
        breakpoint[i].remove(31)
    
    # top ply stray breakpoints at 38, 41, 45
    breakpoint[16].extend([38])
    breakpoint[29].extend([41])
    breakpoint[15].extend([45])
    
    # top ply position 49 breakpoints on even strands
    for i in range(0,27,2):
        breakpoint[i].extend([49])
    for i in [14, 16]: # remove exceptions
        breakpoint[i].remove(49)
    
    # top ply stray breakpoints at 55 and 66
    breakpoint[27].extend([55])
    breakpoint[13].extend([59])
    breakpoint[7].extend([66])
    breakpoint[20].extend([66])
    
    # top ply position 70 breakpoints on even strands
    for i in range(2,29,2):
        breakpoint[i].extend([70])
    for i in [8,10,18,20]: # remove exceptions
        breakpoint[i].remove(70)
    # top ply stray breakpoints at 73, 80
    breakpoint[10].extend([73])
    breakpoint[16].extend([80])
    
    # top ply position 83 breakpoints on odd strands
    for i in range(3,30,2):
        breakpoint[i].extend([83])
    for i in [15,17,19]: # remove exceptions
        breakpoint[i].remove(83)
    # top ply stray breakpoints at 87, 91
    breakpoint[15].extend([87])
    breakpoint[0].extend([91])
    breakpoint[18].extend([91])
    
    # top ply position 97 breakpoints on odd strands
    for i in range(1,28,2):
        breakpoint[i].extend([97])
    for i in [13,15,17]: # remove exceptions
        breakpoint[i].remove(97)
    
    # top ply stray breakpoints at 101, 108
    breakpoint[13].extend([101])
    breakpoint[7].extend([108])
    breakpoint[20].extend([108])
    
    # top ply position 112 breakpoints on even strands
    for i in range(2,29,2):
        breakpoint[i].extend([112])
    for i in [8,10,18,20]: # remove exceptions
        breakpoint[i].remove(112)
    
    # top ply stray breakpoints at 115
    breakpoint[10].extend([115])
    
    # BOTTOM PLY working from left to right
    for i in range(31, 60, 2):
        breakpoint[i].extend([17])
    for i in [43, 45, 47]:
        breakpoint[i].remove(17)
    
    for i in [30, 58]:
        breakpoint[i].extend([35])
    for i in [38,48]:
        breakpoint[i].extend([38])
    for i in [33,35,37,39,41,47,49,51,53,55,57,59]:
        breakpoint[i].extend([48])
    for i in [44]:
        breakpoint[i].extend([52])
    for i in [30]:
        breakpoint[i].extend([56])
    for i in [49]:
        breakpoint[i].extend([62])
    for i in [40]:
        breakpoint[i].extend([63])
    for i in [42]:
        breakpoint[i].extend([66])
    for i in [31,33,35,37,43,45,47,53,55, 57]:
        breakpoint[i].extend([69])
    for i in [58]:
        breakpoint[i].extend([77])
    for i in [40, 51]:
        breakpoint[i].extend([80])
    for i in [41, 59]:
        breakpoint[i].extend([90])
    for i in [44]:
        breakpoint[i].extend([94])
    for i in [30]:
        breakpoint[i].extend([98])
    for i in [49]:
        breakpoint[i].extend([104])
    for i in [40]:
        breakpoint[i].extend([105])
    for i in [42]:
        breakpoint[i].extend([108])
    for i in [31,33,35,37,43,45,47,53,55,57]:
        breakpoint[i].extend([111])
    for i in [58]:
        breakpoint[i].extend([119])
    for i in [40, 51]:
        breakpoint[i].extend([122])
    for i in range(30,60,2):
        breakpoint[i].extend([140])
    for i in [42, 44, 46]:
        breakpoint[i].remove(140)
    
    # print " BREAKPOINTS: "
    # for helix_num in range(len(breakpoint)):
    #     for position in breakpoint[helix_num]:
    #         print helix_num, position
    return breakpoint
    
def get_caps():
    caps = {}
    for i in range(60):
        caps[i] = []
    for i in [13,15,17]:
        caps[i].extend([9, 134])
    for i in [12,14, 16]:
        caps[i].extend([9, 134])
    for i in [42,44,46]:
        caps[i].extend([16, 141])
    for i in [43, 45, 47]:
        caps[i].extend([16, 141])
    return caps
        
def get_connectors():
    connectors = {}
    for i in range(60):
        connectors[i] = []
    for i in range(0,30,2):
        connectors[i].extend([9])
    for i in range(1, 30, 2):
        connectors[i].extend([134])
    for i in range(30, 60, 2):
        connectors[i].extend([16])
    for i in range(31, 60, 2):
        connectors[i].extend([141])

    for i in [12, 13,14,15,16,17,42, 43,44,45,46,47]:
        connectors[i] = []
        
    return connectors

def main():
    exclude = get_excluded_xovers()
    breakpoint = get_staple_breakpoints()
    xover_info = (exclude, breakpoint)
    pickle.dump(xover_info, open('xtps_c2i2_xovers.p', 'w'))

    caps = get_caps()
    connectors = get_connectors()
    sort_info = (caps, connectors)
    pickle.dump(sort_info, open('xtps_c2i2_sort_info.p', 'w'))

if __name__ == '__main__':
    main()
