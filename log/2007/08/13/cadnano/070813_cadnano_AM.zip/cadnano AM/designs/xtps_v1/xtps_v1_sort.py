#!/usr/bin/python

import os.path
import sys
import string
from sets import Set


design_name = 'xtps_v1'

# V1i0
#      core: 150
#       cap: 47
#     total: 197

# V1i1
#      core: 154
# connector: 43
#     total: 197

# V1i2
#      core: 153
#       cap: 8
# connector: 35
#  cap&conn: 1
#     total: 197

# old_order_file = open("xtps_V1i0_oligos.txt", "r")
# old_order_lines = old_order_file.readlines()
# old_order_file.close()
old_order_lines = []

V1i0core = []
V1i0cap = []

V1i1core = []
V1i1conn = []

V1i2core = []
V1i2cap = []
V1i2conn = []
V1i2capconn = []

V1i0_file = open("xtps_V1i0_oligos.txt", "r")
V1i0lines = V1i0_file.readlines()
V1i0_file.close()

V1i0core = Set(V1i0lines[:150])
V1i0lines = V1i0lines[150:]
V1i0cap = Set(V1i0lines[:47])
V1i0lines = V1i0lines[47:]

V1i1_file = open("xtps_V1i1_oligos.txt", "r")
V1i1lines = V1i1_file.readlines()
V1i1_file.close()

V1i1core = Set(V1i1lines[:154])
V1i1lines = V1i1lines[154:]
V1i1conn = Set(V1i1lines[:43])
V1i1lines = V1i1lines[43:]

V1i2_file = open("xtps_V1i2_oligos.txt", "r")
V1i2lines = V1i2_file.readlines()
V1i2_file.close()

V1i2core = Set(V1i2lines[:153])
V1i2lines = V1i2lines[153:]
V1i2cap = Set(V1i2lines[:8])
V1i2lines = V1i2lines[8:]
V1i2conn = Set(V1i2lines[:35])
V1i2lines = V1i2lines[35:]
V1i2capconn = Set(V1i2lines[:1])
V1i2lines = V1i2lines[1:]

plate1 = 310
plate_ra = range(plate1, plate1 + 5)
old_well_ra = [''.join([p,a,b]) \
    for p in ['P'+"%03d"%m for m in plate_ra] \
    for a in 'ABCDEFGH' \
    for b in ["%02d" % n for n in range(1,13)]]

plate1 = 404
plate_ra = range(plate1, plate1 + 4)
new_well_ra = [''.join([p,a,b]) \
    for p in ['P'+"%03d"%m for m in plate_ra] \
    for a in 'ABCDEFGH' \
    for b in ["%02d" % n for n in range(1,13)]]

oligo_ra = [] # list of novel oligos to be ordered

Z_type_ra = [V1i0core, V1i0cap]
Z_well_ra1 = [[] for i in range(5)]
Z_well_ra2 = [[] for i in range(5)]

for i in range(len(Z_type_ra)):
    for oligo in Z_type_ra[i]:
        if oligo in old_order_lines:
            Z_well_ra1[i].append(old_well_ra[old_order_lines.index(oligo)])
        else:
            oligo_ra.append(oligo)
            Z_well_ra2[i].append(new_well_ra[oligo_ra.index(oligo)])

A_type_ra = [V1i1core, V1i1conn]
A_well_ra1 = [[] for i in range(5)]
A_well_ra2 = [[] for i in range(5)]

for i in range(len(A_type_ra)):
    for oligo in A_type_ra[i]:
        if oligo in old_order_lines:
            A_well_ra1[i].append(old_well_ra[old_order_lines.index(oligo)])
        elif oligo in oligo_ra:
            A_well_ra2[i].append(new_well_ra[oligo_ra.index(oligo)])
        else:
            oligo_ra.append(oligo)
            A_well_ra2[i].append(new_well_ra[oligo_ra.index(oligo)])

B_type_ra = [V1i2core, V1i2cap, V1i2conn, V1i2capconn]
B_well_ra1 = [[] for i in range(5)]
B_well_ra2 = [[] for i in range(5)]

for i in range(len(B_type_ra)):
    for oligo in B_type_ra[i]:
        if oligo in old_order_lines:
            B_well_ra1[i].append(old_well_ra[old_order_lines.index(oligo)])
        elif oligo in oligo_ra:
            B_well_ra2[i].append(new_well_ra[oligo_ra.index(oligo)])
        else:
            oligo_ra.append(oligo)
            B_well_ra2[i].append(new_well_ra[oligo_ra.index(oligo)])


# Print notebook-friendly pipetting instructions
oligo_types = [ \
    'V1i0core', \
    'V1i0cap', \
    'V1i1core', \
    'V1i1conn', \
    'V1i2core', \
    'V1i2cap', \
    'V1i2conn', \
    'V1i2capconn']
    
oligo_filename = 'xtps_v1_oligos_final.txt'
output_file = file(oligo_filename, 'w')
for oligo in oligo_ra:
	output_file.write(oligo)
output_file.close()

# for type in oligo_types:
#     print "well_lists['%s'] = len(%s)" % (type, type)

well_lists = {}
well_lists['V1i0core'] = Z_well_ra1[0] + Z_well_ra2[0]
well_lists['V1i0cap'] = Z_well_ra1[1] + Z_well_ra2[1]

well_lists['V1i1core'] = A_well_ra1[0] + A_well_ra2[0]
well_lists['V1i1conn'] = A_well_ra1[1] + A_well_ra2[1]

well_lists['V1i2core'] = B_well_ra1[0] + B_well_ra2[0]
well_lists['V1i2cap'] = B_well_ra1[1] + B_well_ra2[1]
well_lists['V1i2conn'] = B_well_ra1[2] + B_well_ra2[2]
well_lists['V1i2capconn'] = B_well_ra1[3] + B_well_ra2[3]

for oligo_type in oligo_types:
    well_lists[oligo_type].sort()
    
# for oligo_type in oligo_types:
#   print "Total %s: %d" % (oligo_type, len(well_lists[oligo_type]))
# print 'Total oligos:', len(oligo_ra)

pre_stock = ''

col = ["%02d" % n for n in range(1,13)]

for i in range(len(oligo_types)):
    c = [char for char in string.uppercase][i]
    type_name = oligo_types[i]
    type_count = len(well_lists[oligo_types[i]])
    start_plate = new_well_ra[0]
    end_plate = new_well_ra[type_count-1] 
    wells = well_lists[oligo_types[i]]

    formatted_wells = ''
    current_column = col[0]
    nbsp = '' #''.join(['&nbsp;' for n in range(4)])

    for i in range(len(wells)):
        well = wells[i]
        plate = well[:4]
        row = well[4:5]
        column = well[5:]

        prev_well = prev_plate = prev_row = prev_column = ''

        if i == 0:
            formatted_wells = formatted_wells + \
                '{| {{oligo_plate|plate=' + plate[1:] + '}}\n|'
            formatted_wells = formatted_wells + \
                nbsp + "'''" + row + "'''||"

        if not i == 0:
            prev_well = wells[i-1]
            prev_plate = prev_well[:4]
            prev_row = prev_well[4:5]
            prev_column = prev_well
            if not plate == prev_plate or \
                not row == prev_row:
                while not current_column == col[0]:
                    formatted_wells = formatted_wells + '||' + '       '
                    current_column = col[(col.index(current_column)+1) % 12]

                if not plate == prev_plate:
                    # formatted_wells = formatted_wells[:-4]
                    formatted_wells = formatted_wells + \
                        '\n|}\n{| {{oligo_plate|plate=' + plate[1:] + '}}\n'
                    formatted_wells = formatted_wells + \
                        "|" + nbsp + "'''" + row + "'''||"
                else:
                    formatted_wells = formatted_wells + \
                        "\n|-\n|" + nbsp + "'''" + row + "'''||"


        # first match up the column
        while not current_column == column:
            if not current_column == '01':
                formatted_wells = formatted_wells + '||'
            formatted_wells = formatted_wells + '       '
            current_column = col[(col.index(current_column)+1) % 12]

        if not current_column == '01':
            formatted_wells = formatted_wells + '||'

        # if row == 'A' and column == '01':
        #     print well, row, column
        #     formatted_wells = formatted_wells + '|'

        # print the well
        # formatted_wells = formatted_wells + '<code>'+ well + '</code>'
        formatted_wells = formatted_wells + well
        current_column = col[(col.index(current_column)+1) % 12]

        # add newline if appropriate
        if row == col[-1]:
            formatted_wells = formatted_wells + '\n'
        
    # add trailing blanks 
    while not current_column == col[0]:
        formatted_wells = formatted_wells + '||' + '       '
        current_column = col[(col.index(current_column)+1) % 12]

    formatted_wells = formatted_wells + '\n|}\n'

    pre_stock = pre_stock + \
        "*%s.%s (%s: 6 {{ul}} each, %d total):\n%s\n\n" % \
        (design_name, c, type_name, type_count, formatted_wells)

# stamp
V1i01 = ['V1i0core'] 
# capped
V1i02 = ['V1i0core', 'V1i0cap']

# stamp
V1i11 = ['V1i1core'] 
# z-only
V1i12 = ['V1i1core', 'V1i1conn']

# stamp
V1i21 = ['V1i2core']
# cap only
V1i22 = ['V1i2core', 'V1i2cap']
# cap and conn
V1i23 = ['V1i2core', 'V1i2cap', 'V1i2conn', 'V1i2capconn']

wstock_list = [V1i01, V1i02, V1i11, V1i12, V1i21, V1i22, V1i23]
working_stock = ''
for i in range(len(wstock_list)):
    working_stock = working_stock + "**%s.%d:" % (design_name, i+1)
    for j in range(len(wstock_list[i])):
        c = [char for char in string.uppercase][oligo_types.index(wstock_list[i][j])]
        working_stock = working_stock + " %s.%s (%d {{ul}}) +" % \
            (design_name, c, len(well_lists[wstock_list[i][j]])  )
    vols = []
    for k in range(len(wstock_list[i])):
        vols.append(len(well_lists[wstock_list[i][k]]))
    water_vol = 200 - sum([vol for vol in vols])
    working_stock = working_stock + " d{{h2o}} (%d {{ul}})\n" % water_vol


pipette_template = '''
\'\'\'%s\'\'\'
*Mix contents of plates %s to make pre- and working- stocks of %s
*Make pre-stocks: 6 {{ul}} each oligo
%s
*Make working stocks: 250 nM each oligo: 1 {{ul}} each oligo, 200 {{ul}} final volume
%s
*Folding reaction for each working stock
**2 {{ul}} 10x folding buffer (final concentration: 50 mM HEPES pH 7.5, 50 mM NaCl, 30 mM {{mgcl2}})
**8 {{ul}} working stock (final concentration: 100 nM each staple)
**10 {{ul}} p7392, 2 nM stock (final concentration: 1 nM scaffold)

*Annealing program
**1. 80.0{{c}} for 5:00
**2. 80.0{{c}} for 1:00
***-1{{c}} per cycle
**3. Goto 2, 60 times
**4. End
'''
 
print pipette_template % (design_name, ', '.join([str(p) for p in plate_ra]), design_name, pre_stock, working_stock)
