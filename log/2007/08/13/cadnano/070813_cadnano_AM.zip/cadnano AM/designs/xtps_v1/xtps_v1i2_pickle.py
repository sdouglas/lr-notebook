
#!/usr/bin/env python
# encoding: utf-8
import sys
import os
import cPickle as pickle

def get_excluded_xovers():
    exclude = [[] for i in range(60)]
    for i in [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58]:
        exclude[i].extend([0])
    for i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 59]:
        exclude[i].extend([56, 98])
    for i in [30, 31, 32, 33, 34, 35, 36, 37, 38, 41, 42, 43, 44, 45, 46, 47, 48, 51, 52, 53, 54, 55, 56, 57, 58, 59]:
        exclude[i].extend([35, 77, 119])
    for i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]:
        exclude[i].extend([7, 21, 42, 63, 84, 105, 126, 133, 140])
    for i in [0, 2, 4, 6, 8, 9, 10, 12, 14, 16, 18, 19, 20, 22, 24, 26, 28, 29, 30, 31, 33, 35, 37, 39, 40, 41, 43, 45, 47, 49, 50, 51, 53, 55, 57, 59]:
        exclude[i].extend([28, 70, 112])
    for i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 59]:
        exclude[i].extend([14])
    for i in [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59]:
        exclude[i].extend([49, 91])
    return exclude
    
def get_staple_breakpoints():
    breakpoint = [[] for i in range(60)]
    for i in [31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59]:
        breakpoint[i].extend([130])
    for i in [30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58]:
        breakpoint[i].extend([5, 131])
    for i in [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59]:
        breakpoint[i].extend([4])
    for i in [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29]:
        breakpoint[i].extend([8, 134])
    for i in [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28]:
        breakpoint[i].extend([9, 135])
    for i in [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58]:
        breakpoint[i].extend([142])
    for i in [40, 50]:
        breakpoint[i].extend([17, 59, 101])
    for i in [31, 33, 35, 37, 41, 43, 45, 47, 51, 53, 55, 57]:
        breakpoint[i].extend([18])
    for i in [1, 3, 5, 7, 8, 11, 13, 17, 18, 21, 23, 25, 27, 29]:
        breakpoint[i].extend([39, 81])
    for i in [39, 49]:
        breakpoint[i].extend([44, 86])
    for i in [15, 59]:
        breakpoint[i].extend([46])
    for i in [32, 34, 36, 38, 42, 44, 46, 48, 52, 54, 56, 58]:
        breakpoint[i].extend([51])
    for i in [30]:
        breakpoint[i].extend([58])
    for i in [14, 31, 33, 35, 37, 41, 45, 47, 51, 53, 55, 57]:
        breakpoint[i].extend([60])
    for i in [43]:
        breakpoint[i].extend([65])
    for i in [0, 2, 4, 6, 9, 10, 12, 16, 19, 20, 22, 24, 26, 28]:
        breakpoint[i].extend([72])
    for i in [44, 59]:
        breakpoint[i].extend([88])
    for i in [15, 32, 34, 36, 38, 42, 46, 48, 52, 54, 56, 58]:
        breakpoint[i].extend([93])
    for i in [30, 44]:
        breakpoint[i].extend([100])
    for i in [31, 33, 35, 37, 41, 45, 47, 51, 53, 55, 57]:
        breakpoint[i].extend([102])
    for i in [0, 2, 4, 6, 9, 10, 12, 14, 16, 19, 20, 22, 24, 26, 28]:
        breakpoint[i].extend([114])
    return breakpoint
    
def get_caps():
    caps = [[] for i in range(60)]
    return caps
    
def get_connectors():
    connectors = [[] for i in range(60)]
    return connectors
    
def main():
exclude = get_excluded_xovers()
breakpoint = get_staple_breakpoints()
caps = get_caps()
connectors = get_connectors()
info = (exclude, breakpoint, caps, connectors)
pickle.dump(info, open('xtps_v1i2.p', 'w'))

if __name__ == '__main__':
main()
