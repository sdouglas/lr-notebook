#!/bin/sh
cd ~/Desktop/cadnano
epydoc -v --config cadnano.config
