#!/usr/bin/env python
# encoding: utf-8

"""
Root-level module containing main() function, currently intended to be called
from the command line.
"""

import sys
import os
from CADNano.file import read_config, update_config, write_timestamp, refresh
from CADNano.file import get_pickle_data
from CADNano.prelattice import write_helix_lattice_file
from CADNano import Lattice
from CADNano import Domain
from CADNano import Path
from CADNano import Sequences
from CADNano import Scaffold
from CADNano import Staples
from CADNano import SVG
import time

def main():
    print "----------c a D N A n o----------"
    start_time = time.time()
    config = read_config('cadnano.config')
    for interface in config['interfaces']:
        print '---config'
        config['file'] = update_config(config['file'], interface)
        refresh(config['file'])
        write_helix_lattice_file(config)
        print '---lattice'
        lattice = Lattice(config)
        print '---domain'
        domain = Domain(config, lattice)
        print '---path'
        path = Path(config, lattice, domain)
        offset = int(config['param']['scaffold_offset'])
        seq = Sequences().p8064(offset)
        print '---scaffold'
        scaffold = Scaffold(path, seq)
        print '---staples'
        staples = Staples(config, scaffold)
        print '---svg'
        svg = SVG(config, path, domain, staples) 
        svg.write_svg_file()
        write_timestamp(config['file'], start_time)
    print "---------------------------------"

if __name__ == '__main__':
    main()
