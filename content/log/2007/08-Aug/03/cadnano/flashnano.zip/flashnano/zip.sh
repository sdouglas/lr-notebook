#!/bin/sh
cd /Users/shawn/Desktop
zip -r flashnano flashnano
