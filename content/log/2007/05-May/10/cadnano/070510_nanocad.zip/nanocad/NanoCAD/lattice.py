"""Handles a cross-sectional representation of DNA nanostructure helices.

The Lattice class manages the cross-sectional representation of the 
DNA nanostructure.  It requires two inputs: a lattice file and
a connector file.  These files are meant to be human readable and 
easy to quickly modify with a text editor.

The lattice file defines the cross-section of the folded monomer, and
is an ASCII representation approximating a honeycomb lattice. For example::

    ...   ...   ...   ...   ...   
       ...   ...   ...   ...   ...

       ...   AAA   AAA   AA0   ...
    ...   AA1   AAA   AAA   ...   

    ...   AA2   AAA   AAA   ...   
       ...   AAA   AAA   AA3   ...

       ...   ...   ...   ...   ...
    ...   ...   ...   ...   ...   

Each double-helix is represented by a unique 3-digit code.  The first
letter always defines the scaffold identity [A-Z,a-z].  By default,
the second and third positions should 

Note that when describing the nanostructure in three dimensions, the
left-to-right direction in the lattice file is the "x direction",
the top-to-bottom direction is the "y direction", and the view into
the screen is the z direction.

The lattice file also has "parity" constraints for where even and odd
helices can be positioned.  The parity of any position is defined as
its row number plus its column number (using zero-based indexing).  
Note that the following is a single row, which takes up 2 separate 
lines in the ASCII file::

    ...   ...   ...   ...   ...   
       ...   ...   ...   ...   ...

The row above has 10 columns. Even-numbered helices must occupy 
even-parity lattice positions, and odd-numbered helices must occupy
odd-parity lattice positions.

The connector file format is identical to that of the lattice file, but 
allows helices to appear multiple times so as to indicate adjacency of
otherwise distance helices in the monomer.  This allows for x- and y-
polymerization.  To achieve x-polymerization in the above example,
the following connector file would be used::

    ...   ...   ...   ...   ...   
       ...   ...   ...   ...   ...

       AA0   AAA   AAA   AA0   ...
    ...   AA1   AAA   AAA   AA1   

    ...   AA2   AAA   AAA   AA2   
       AA3   AAA   AAA   AA3   ...

       ...   ...   ...   ...   ...
    ...   ...   ...   ...   ...   

While connector helieces only need to appear next to each other once to
indicate adjacency, they can be included multiple times in the connector
file for better readability.  Note that the first waypoint "AA0" was 
uniquely represented in the original lattice file, so it should not be
problematic for it to occur multiple times in the connector file.

"""

import sys
from exceptions import ParityError, LengthError
from file import File, get_lines

class _Sentinel:
    """
    A unique value that won't compare equal to any other value.  This
    class is used to create L{UNKNOWN}.
    """
    def __init__(self, name):
        self.name = name
    def __repr__(self):
        return '<%s>' % self.name
    def __nonzero__(self):
        raise ValueError('Sentinel value <%s> can not be used as a boolean' %
                         self.name)

UNKNOWN = _Sentinel('UNKNOWN')
"""A special value used to indicate that a given piece of
information about an object is unknown.  This is used as the
default value for all instance variables."""


class Helix:
    """Helix objects are each a unique cross-sectional segment (21 or 32 
    bases in length).
    """

    id = UNKNOWN
    """@ivar: The unique identifier of the helix instance.
       @type: C{string}
    """
    
    segment = UNKNOWN
    """@ivar: Segment number of the helix instance.
       @type: C{int}
    """
    
    scaffold_id = UNKNOWN
    """@ivar: The scaffold of which the helix instance is a member.
       @type: C{string}
    """
    
    parity = UNKNOWN
    """@ivar: 5' to 3' scaffold orientation along the z-axis.
       @type: C{int} (0 or 1)
    """

    p0 = UNKNOWN
    """@ivar: pointer to neighboring C{Helix} object in the P0 position
       @type: C{Helix}
    """
    
    p1 = UNKNOWN
    """@ivar: pointer to neighboring C{Helix} object in the P1 position
       @type: C{Helix}
    """
    
    p2 = UNKNOWN
    """@ivar: pointer to neighboring C{Helix} object in the P2 position
       @type: C{Helix}
    """    
    
    def __init__(self, id, segment, scaffold_id, parity):
        super(Helix, self).__init__()
        self.id = id
        self.segment = segment
        self.scaffold_id = scaffold_id
        self.parity = parity
        

class Lattice:
    """
    Lattice 
    Attributes:
    helix_lattice_ra -- list representation of helices (main lattice file)
    connector_ra -- list representation of helices (connector file)
    numhelics -- number of helices determined by parsing lattice file
    scaffold_name -- first character of 4-digit helix code (A-Z,a-z)
    
    Functions:
    parse_input -- convert ASCII input to list representation
    print_lattice -- given a lattice list, print ASCII representation
    print_helix_lattice -- call print_lattice for core helix lattice
    print_connector_lattice -- call print_lattice for connector lattice
    
    """
    def __init__(self, helix_lattice_file, connector_file):
        self.helix_lattice_ra = []
        self.connector_ra = []
        self.numhelices = 0
        self.scaffold_prefix = []

        # Read and parse lattice file
        try:
            lines = get_lines(helix_lattice_file)
            sub_lattice = []
            for line in lines:
                if line == '#\n':
                    result = self.parse_input(sub_lattice)
                    self.helix_lattice_ra.append(result)
                    sub_lattice = []
                else:
                    sub_lattice.append(line)
            self.helix_lattice_ra.append(self.parse_input(sub_lattice))
            print "Read lattice file:", 
            print ' '.join(self.scaffold_prefix)
        except ParityError, e:
            h = ','.join([str(h) for h in e.helices])
            print "Parity error for helices: %s" % h
            print "Found in ", helix_lattice_file
            sys.exit(1)
        except LengthError, e:
            r = ','.join([str(r) for r in e.rows])
            print "Line length error in row(s)", r,
            print "found in ", helix_lattice_file
            sys.exit(1)

        # Read and parse connector file
        try:
            lines = get_lines(connector_file)
            sub_lattice = []
            for line in lines:
                if line == '#\n':
                    result = self.parse_input(sub_lattice)
                    self.connector_ra.append(result)
                    sub_lattice = []
                else:
                    sub_lattice.append(line)
            self.connector_ra.append(self.parse_input(sub_lattice))
            print "Read connector file:", 
            print ' '.join(self.scaffold_prefix)
        except ParityError, e:
            h = ','.join([str(h) for h in e.helices])
            print "Parity error for helices: %s" % h
            print "Found in", self.connector_file
            sys.exit(1)
        except LengthError, e:
            r = ','.join([str(r) for r in e.rows])
            print "Line length error in row(s)", r,
            print "found in", self.connector_file
            sys.exit(1)

    def parse_input(self, lines):
        """Parse input file into a list representation of the lattice"""

        row_ra = [line[:-1] for line in lines]

        # Check to make sure each line is the same length
        length_violations = []
        length = len(row_ra[0])
        for row in row_ra:
            if len(row) != length and len(row) != 0:
                length_violations.append(row_ra.index(row))

        # Parse into pre helix array
        pre_helix_lattice_ra = []
        for row in row_ra:
            num_helices = len(row)/3
            sub_pre_helix_lattice_ra = []
            for row_helix_num in range(num_helices):
                sub_pre_helix_lattice_ra.append(row[row_helix_num*3: \
                                            row_helix_num*3 + 3])
            if sub_pre_helix_lattice_ra != []:
                pre_helix_lattice_ra.append(sub_pre_helix_lattice_ra)

        # Parse pre helix array into helix array
        num_rows = len(pre_helix_lattice_ra)/2
        num_helices = len(pre_helix_lattice_ra[0])

        helix_lattice_ra = [['.' for row_helix_num in range(num_helices + 
                                                    num_helices % 2 + 2)]]
        for row_num in range(num_rows):
            sub_helix_lattice_ra = ['.']
            for row_helix_num in range(num_helices):
                pre_helix_string = pre_helix_lattice_ra[row_num*2 + \
                        (row_helix_num + row_num) % 2][row_helix_num]
                if pre_helix_string == '...':
                    helix = '.'
                else:
                    if not pre_helix_string[0] in self.scaffold_prefix:
                        self.scaffold_prefix.append(pre_helix_string[0])
                    helix = int(pre_helix_string[1:])
                sub_helix_lattice_ra.append(helix)
            sub_helix_lattice_ra.append('.')
            if num_helices % 2 == 1:
                sub_helix_lattice_ra.append('.')
            helix_lattice_ra.append(sub_helix_lattice_ra)

        helix_lattice_ra.append(['.' for row_helix_num in \
                         range(num_helices + num_helices % 2 + 2)])

        # Check for parity violations
        parity_violation_helices = []
        for row_num in range(num_rows):
            for row_helix_num in range(num_helices):
                helix = helix_lattice_ra[row_num][row_helix_num]
                if helix != '.':
                    if (helix + row_num + row_helix_num) % 2 == 1:
                        parity_violation_helices.append(helix)

        if not len(length_violations) == 0:
            raise LengthError, length_violations
        if not len(parity_violation_helices) == 0:
            raise ParityError, parity_violation_helices
        else:
            return helix_lattice_ra

    def print_lattice(self, helix_lattice_ra, scaffold_prefix):
        """Output ASCII representation of lattice."""
        for y in range(len(helix_lattice_ra)):
            even_row_string = ''
            odd_row_string = '   '
            for x in range(len(helix_lattice_ra[0])):
                element = helix_lattice_ra[y][x]
                if element == '.':
                    element = '...'
                else:
                    element = "%s%02d" % (scaffold_prefix, element)
                if x % 2 == 0:
                    even_row_string += element + '   '
                else:
                    odd_row_string += element + '   '
            if y % 2 == 0:
                print even_row_string
                print odd_row_string
            else:
                print odd_row_string
                print even_row_string
            print ''
        print '\n'
        return

    def print_helix_lattice(self):
        """Output ASCII representation of helix lattice."""
        h = self.helix_lattice_ra
        for i in range(len(h)):
            prefix = self.scaffold_prefix[i]
            print "Reconstructed helix lattice %s:" % prefix
            self.print_lattice(h[i], prefix)
        return

    def print_connector_lattice(self):
        """Output ASCII representation of connector helix lattice."""
        c = self.connector_ra
        for i in range(len(c)):
            prefix = self.scaffold_prefix[i]
            print "Reconstructed connector lattice %s:" % prefix
            self.print_lattice(c[i],prefix)
        return

    def xover_position(self, helix1, helix2):
        """Return crossover position (P0, P1, P2) for a pair of helices."""
        even_offset_ra = [[0,  1], [0, -1], [-1, 0]]
        odd_offset_ra = [[0, -1], [0,  1], [1, 0]]
        offset_ra = [even_offset_ra, odd_offset_ra]
        for y in range(len(self.helix_lattice_ra)):
            for x in range(len(self.helix_lattice_ra[0])):
                helix = self.helix_lattice_ra[y][x]
                if helix == helix1:
                    for pos in range(3):
                        parity = (y + x) % 2
                        next_y = y + offset_ra[parity][pos][0]
                        next_x = x + offset_ra[parity][pos][1]
                        if helix2 == self.helix_lattice_ra[next_y][next_x]:
                            return pos
