#!/usr/bin/env python
# encoding: utf-8

import sys, os

from NanoCAD import File, Lattice, Sequences

design = 'tps_v15'
numzones = 3

def main():

    # create file object based on design name
    file = File(design)

    # determine honeycomb lattice arrangement of helices
    lattice = Lattice(file.helix_lattice, file.connector)

    lattice.print_helix_lattice()
    lattice.print_connector_lattice()
    
    # read in sequence
    seq = Sequences().p7560()

    # path = 

    # construct scaffold object from lattice 
    # parse_input(lattice, file.path)

if __name__ == '__main__':
    main()
