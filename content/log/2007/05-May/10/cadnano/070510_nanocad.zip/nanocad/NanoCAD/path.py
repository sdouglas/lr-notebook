"""Parses the scaffold path file to determine appropriate crossover locations.
"""

from file import File, get_lines
        
class Path:
    """The Path class converts the path file to a path_pointer array.
    
    Attributes:
    pathfile -- name of file containing path information
    numzones -- number of sub-zones
    """
    def __init__(self, pathfile, numzones):
        self.pathfile = pathfile
        self.numzones = numzones

        try:
            self.path_pointer_ra = self.parse_input(pathfile)
        except Exception, e:
            pass
    
    # parse_input reads in the path file and lattice and 
    def parse_input(lattice, pathfile):
        """docstring for parse_input"""

        lines = get_lines(pathfile)
        path_pointer_ra = [[[] for j in range((numzones+1)*7)] \
                               for i in range(60)]

        for i in range(len(lines)):
            s0 = lines[i].split(':')
            s1 = s0[0].split('-')
            helix1 = int(s1[0])
            helix2 = int(s1[1])
            s2 = s0[1].split('|')
            zones = ''.join(s2[1].split('.'))

            xover = lattice.xover_position(helix1, helix2)


            # L = left, R = right
            # P* = position 0,1,2
            # [5] LP1 [4] LP2 [10] RP2 [4] LP0 [10] RP0 [4] RP1 [5]
            #  0       1        2       3        4       5       6   

            # example: LP1 xover
            # even strand position 0 points to position 0 on odd strand
            # odd strand position 1 point to position 1 on even strand

            even_left = [3, 0, 1]
            even_right = [4, 5, 2]
            odd_left = [4, 1, 2]
            odd_right = [5, 6, 3]

            for j in range(len(zones)):
                if zones[j] == ']' and j % 4 == 0: # left
                    pass
                elif zones[j] == '[' and j % 4 == 1: # left
                    pass
                elif zones[j] == ']' and j % 4 == 2: # right
                    pass
                elif zones[j] == '[' and j % 4 == 3: # right
                    pass
                else:
                    print "Error: unexpected path crossover in pathfile:", s1

            for j in range(len(zones)):
                if zones[j] == '[' and helix1 % 2 == 1: # from odd to even
                    if path_pointer_ra[helix1][j]:
                        print "error", path_pointer_ra[helix1][j]
                    path_pointer_ra[helix1][j] = [helix2, j]
                if zones[j] == '[' and helix2 % 2 == 1: # from odd to even
                    if path_pointer_ra[helix2][j]:
                        print "error", path_pointer_ra[helix2][j]
                    path_pointer_ra[helix2][j] = [helix1, j]
                if zones[j] == ']' and helix1 % 2 == 0: # from even to odd
                    if path_pointer_ra[helix1][j]:
                        print "error", path_pointer_ra[helix1][j]
                    path_pointer_ra[helix1][j] = [helix2, j]
                if zones[j] == ']' and helix2 % 2 == 0: # from even to odd
                    if path_pointer_ra[helix2][j]:
                        print "error", path_pointer_ra[helix2][j]
                    path_pointer_ra[helix2][j] = [helix1, j]

        # print '\n'
        # for i in range(60):
        #     print path_pointer_ra[i]

        pos = []
        for pointer in path_pointer_ra[0]:
            if pointer:
                pos = pointer
                break

        visited = []

        while not pos in visited:
            visited.append(pos)
            helix = pos[0]
            segment = pos[1]
        
            next = path_pointer_ra[helix][segment]
            if not next:
                if helix % 2 == 0:
                    next = [helix, segment+1]
                else:
                    next = [helix, segment-1]
            path_pointer_ra[helix][segment] = next
            pos = next
        

        # print '\n'
        # for i in range(60):
        #     print i, path_pointer_ra[i]

        print '\n'
        print len(visited)
        # for i in range(0,len(visited),10):
        #     print visited[i:i+10]
