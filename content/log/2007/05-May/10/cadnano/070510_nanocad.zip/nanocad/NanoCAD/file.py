"""Bookkeeping of external ASCII files."""

import sys

class File():
    """The File class is used for bookkeeping of external ASCII files."""
    
    helix_lattice = ''
    """@ivar: honeycomb helix_lattice filename (for monomeric unit)
       @type: C{string}
    """

    connector = ''
    """@ivar: honeycomb helix_lattice filename (for polymerizing units)
       @type: C{string}
    """

    path = ''
    """@ivar: scaffold path filename
       @type: C{string}
    """

    model = ''
    """@ivar: x3d model filename
       @type: C{string}
    """

    oligo = ''
    """@ivar: oligo output filename
       @type: C{string}
    """

    def __init__(self, design):
        prefix = 'designs/%s/%s_' % (design, design)
        self.helix_lattice = prefix + 'helix_lattice.txt'
        self.connector = prefix + 'connector.txt'
        self.path =  prefix + 'path.txt'
        self.x3d = prefix + 'model.x3d'
        self.oligo = prefix + 'oligo.txt'
    
def get_lines(filename):
    """Retrieve contents of file.
    
    @return: A list of lines in C{filename}
    @raise IOError: If C{filename} is not found.
    """
    try:
        filehandle = open(filename)
    except IOError:
        sys.exit("Error: file \'%s\' not found." % filename)

    lines = filehandle.readlines()

    filehandle.close()
    return lines
