"""Generates an internal representation of the scaffold, based on lattice and path inputs.
"""

class Scaffold:
    """docstring for Scaffold"""
    def __init__(self, lattice, path, sequence):
        self.lattice = lattice
        self.path = path
        self.sequence = sequence